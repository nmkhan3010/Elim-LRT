#!/usr/bin/env python3
"""
build_mirror_docx.py -- turn the agent's on-screen mirror into the deliverable.

The agent produces the English mirror as Markdown. This converts it to .docx
while preserving the things the mirror rules care about:

  * spanned headers become REAL merged cells (a label printed once stays once)
  * blank cells stay blank -- nothing is filled, defaulted or padded
  * running headers/footers go into the Word header/footer, never the body
  * printed page numbers are written as STATIC text, never a field
  * no highlight, no flag, no annotation is ever written

Usage
    python3 build_mirror_docx.py mirror.md out.docx \
        [--header "Alpha Company"] [--footer "Page 3"] [--landscape]

Input format (exactly what the agent prints):
    ## optional heading
    normal paragraph text
    | Assets   |          | Equity   |          |     <- blank = spanned cell
    | 2025     | 2024     | 2025     | 2024     |
    | 12,480   | 11,204   |          | 9,100    |     <- blank stays blank

Requires: python-docx  (pip install python-docx --break-system-packages)
"""
from __future__ import annotations

import argparse
import re
import sys

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Inches

ARABIC = re.compile(r"[\u0600-\u06FF\u0750-\u077F]")


def _merge_horizontally(row, start, count):
    """Merge `count` cells from `start` into one -- how a span is reproduced."""
    if count < 2:
        return
    a = row.cells[start]
    for i in range(start + 1, start + count):
        a = a.merge(row.cells[i])
    # merging concatenates each cell's paragraph; drop the empties it leaves
    keep = a.paragraphs[0]
    for extra in a.paragraphs[1:]:
        if not extra.text.strip():
            extra._p.getparent().remove(extra._p)
    if not keep.text.strip() and len(a.paragraphs) > 1:
        keep._p.getparent().remove(keep._p)


def _repeat_header(row):
    tr = row._tr
    pr = tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    pr.append(el)


def split_row(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def add_table(doc, rows):
    """
    rows: list of lists of cell strings. A blank cell in a HEADER row means the
    column above is covered by the label to its left, so it is merged into it.
    A blank cell in a BODY row is real, deliberate emptiness and stays empty.
    """
    cols = max(len(r) for r in rows)
    rows = [r + [""] * (cols - len(r)) for r in rows]
    t = doc.add_table(rows=len(rows), cols=cols)
    t.style = "Table Grid"
    t.autofit = True

    # header rows are those before the first row that carries a number
    first_body = next((i for i, r in enumerate(rows)
                       if any(re.search(r"\d", c) and not re.fullmatch(r"\D*\d{4}\D*", c)
                              for c in r)), 1)

    for ri, r in enumerate(rows):
        for ci, val in enumerate(r):
            cell = t.cell(ri, ci)
            cell.text = ""
            p = cell.paragraphs[0]
            run = p.add_run(val)
            run.font.size = Pt(9)
            if ri < first_body:
                run.font.bold = True
            if ARABIC.search(val):
                run.font.name = "Arial"
            if re.fullmatch(r"[\d.,()\-\u2013 ]+", val or "") and val:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    # merge spanned header labels: a run of blanks after a label belongs to it
    for ri in range(first_body):
        ci = 0
        while ci < cols:
            if rows[ri][ci]:
                span = 1
                while ci + span < cols and not rows[ri][ci + span]:
                    span += 1
                if span > 1:
                    _merge_horizontally(t.rows[ri], ci, span)
                ci += span
            else:
                ci += 1
    for ri in range(first_body):
        _repeat_header(t.rows[ri])
    return t


def build(md_path, out_path, header=None, footer=None, landscape=False):
    text = open(md_path, encoding="utf-8").read()
    doc = Document()

    sec = doc.sections[0]
    if landscape:
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width, sec.page_height = sec.page_height, sec.page_width
    for m in ("top", "bottom", "left", "right"):
        setattr(sec, f"{m}_margin", Inches(0.75))

    # Running furniture goes in the header/footer, never the body. The page
    # number is written as static text: a field would regenerate and could
    # diverge from the number the source PDF prints.
    if header:
        hp = sec.header.paragraphs[0]
        hp.text = header
        hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if footer:
        fp = sec.footer.paragraphs[0]
        fp.text = footer
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER

    lines = text.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if s.startswith("|"):
            buf = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                buf.append(lines[i])
                i += 1
            rows = [split_row(b) for b in buf
                    if not all(re.fullmatch(r":?-{2,}:?", c) or c == "" for c in split_row(b))]
            if rows:
                add_table(doc, rows)
                doc.add_paragraph()
            continue
        if s.startswith("#"):
            doc.add_heading(s.lstrip("#").strip(), level=min(s.count("#"), 4))
            i += 1
            continue
        p = doc.add_paragraph(s)
        if ARABIC.search(s):
            for r in p.runs:
                r.font.name = "Arial"
        i += 1

    doc.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mirror")
    ap.add_argument("out")
    ap.add_argument("--header")
    ap.add_argument("--footer")
    ap.add_argument("--landscape", action="store_true")
    a = ap.parse_args()
    print(build(a.mirror, a.out, a.header, a.footer, a.landscape))


if __name__ == "__main__":
    sys.exit(main())
