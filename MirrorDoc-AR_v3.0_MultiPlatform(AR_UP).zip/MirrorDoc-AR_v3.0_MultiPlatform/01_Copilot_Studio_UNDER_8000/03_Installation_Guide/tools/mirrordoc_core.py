# -*- coding: utf-8 -*-
"""
MirrorDoc-AR v2.0 -- Deterministic core engine.

This module contains every rule that MUST NOT be left to model judgement.
It is used in two places:
  1. Power Automate / Azure Function pre- and post-processing (authoritative).
  2. The UAT harness (run_uat.py) that proves the rules behave as specified.

Design principle: the LLM translates and transcribes. Arithmetic, numeral
conversion, glossary lookup, header flattening and parity counting are
deterministic code. A model that is *asked* to be deterministic is not
a control; code is.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Dict, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# SECTION 1 -- ARABIC TEXT NORMALISATION (glossary lookup key builder)
# ---------------------------------------------------------------------------

# Tashkeel / harakat (diacritics) and Quranic marks.
_TASHKEEL = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]")
# Tatweel / kashida -- pure decoration, never semantic.
_TATWEEL = re.compile(r"\u0640")
# Zero-width and bidi control characters that survive OCR and break equality.
_INVISIBLE = re.compile(r"[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]")

_ALEF_FORMS = "\u0622\u0623\u0625\u0671\u0672\u0673\u0675"   # آ أ إ ٱ ...
_ALEF_PLAIN = "\u0627"                                        # ا

_LETTER_MAP = {
    "\u0649": "\u064A",   # ى (alef maqsura) -> ي
    "\u0629": "\u0647",   # ة (ta marbuta)   -> ه
    "\u0624": "\u0648",   # ؤ                -> و
    "\u0626": "\u064A",   # ئ                -> ي
    "\u06A9": "\u0643",   # ک (Persian kaf)  -> ك
    "\u06CC": "\u064A",   # ی (Persian yeh)  -> ي
}

# Arabic-Indic (Mashriq: Egypt, Levant, Gulf) and Extended (Persian/Urdu).
_DIGIT_MAP = {}
for _i in range(10):
    _DIGIT_MAP[chr(0x0660 + _i)] = str(_i)   # ٠..٩
    _DIGIT_MAP[chr(0x06F0 + _i)] = str(_i)   # ۰..۹

# Arabic decimal / thousands / percent punctuation. These are the characters
# most commonly dropped by naive pipelines, silently changing magnitude.
ARABIC_DECIMAL_SEP = "\u066B"      # ٫
ARABIC_THOUSANDS_SEP = "\u066C"    # ٬
ARABIC_PERCENT = "\u066A"          # ٪
ARABIC_COMMA = "\u060C"            # ،


def strip_diacritics(text: str) -> str:
    """Remove tashkeel, tatweel and invisible control characters."""
    text = _INVISIBLE.sub("", text)
    text = _TASHKEEL.sub("", text)
    text = _TATWEEL.sub("", text)
    return text


def convert_numerals(text: str) -> str:
    """
    Convert Arabic-Indic / Extended-Arabic digits to Western digits AND
    normalise Arabic numeric punctuation.

    Order matters: the decimal separator must be converted before the
    thousands separator, otherwise U+066C and U+066B are indistinguishable
    once both become ASCII.
    """
    out = []
    for ch in text:
        if ch in _DIGIT_MAP:
            out.append(_DIGIT_MAP[ch])
        elif ch == ARABIC_DECIMAL_SEP:
            out.append(".")
        elif ch == ARABIC_THOUSANDS_SEP:
            out.append(",")
        elif ch == ARABIC_PERCENT:
            out.append("%")
        else:
            out.append(ch)
    return "".join(out)


def normalise_arabic(text: str, strip_al: bool = False) -> str:
    """
    Build the canonical lookup key for TMS/glossary matching.

    strip_al=True additionally removes the definite article, used only as a
    SECOND-PASS fallback -- never as the primary key, because 'الأصول'
    (the assets) and 'أصول' (assets/origins) are not always interchangeable.
    """
    text = unicodedata.normalize("NFKC", text)
    text = strip_diacritics(text)
    for src in _ALEF_FORMS:
        text = text.replace(src, _ALEF_PLAIN)
    for src, dst in _LETTER_MAP.items():
        text = text.replace(src, dst)
    text = convert_numerals(text)
    text = text.replace(ARABIC_COMMA, ",")
    text = re.sub(r"\s+", " ", text).strip().lower()
    if strip_al:
        text = re.sub(r"(^|\s)ال(?=\S)", r"\1", text)
        text = re.sub(r"\s+", " ", text).strip()
    return text


# ---------------------------------------------------------------------------
# SECTION 2 -- TMS / GLOSSARY RESOLVER (glossary-first, deterministic)
# ---------------------------------------------------------------------------

TIER_TMS_EXACT = "TMS-EXACT"
TIER_TMS_NORM = "TMS-NORMALISED"
TIER_TMS_DIALECT = "TMS-DIALECT-VARIANT"
TIER_IFRS = "IFRS-FALLBACK"
TIER_UNMAPPED = "UNMAPPED-FLAG"


@dataclass
class GlossaryEntry:
    arabic: str
    english: str
    domain: str = "GENERAL"
    jurisdiction: str = "ALL"      # ALL | EG | JO | SA | AE | KW | QA | BH | OM
    do_not_translate: bool = False
    note: str = ""


@dataclass
class TermResolution:
    source: str
    english: Optional[str]
    tier: str
    jurisdiction: str = "ALL"
    flag: Optional[str] = None


class GlossaryResolver:
    """
    Enforces the GLOSSARY-FIRST contract:
        TMS exact -> TMS normalised -> TMS dialect variant -> IFRS termbase
        -> flag [TERM-UNMAPPED]. The model NEVER supplies a term silently.

    Also enforces one-term -> one-English for the whole session via a ledger,
    so the same Arabic term cannot be rendered two ways across 200 pages.
    """

    def __init__(
        self,
        tms: Sequence[GlossaryEntry],
        ifrs: Optional[Sequence[GlossaryEntry]] = None,
        jurisdiction: str = "ALL",
    ) -> None:
        self.jurisdiction = jurisdiction
        self._exact: Dict[str, GlossaryEntry] = {}
        self._norm: Dict[str, GlossaryEntry] = {}
        self._noal: Dict[str, GlossaryEntry] = {}
        self._ifrs_norm: Dict[str, GlossaryEntry] = {}
        self.ledger: Dict[str, str] = {}
        self.conflicts: List[Tuple[str, str, str]] = []

        for e in tms:
            self._exact.setdefault(e.arabic.strip(), e)
            self._norm.setdefault(normalise_arabic(e.arabic), e)
            self._noal.setdefault(normalise_arabic(e.arabic, strip_al=True), e)
        for e in (ifrs or []):
            self._ifrs_norm.setdefault(normalise_arabic(e.arabic), e)

        # Longest-first ordering so multi-word terms win over their components.
        self._ordered = sorted(self._norm.keys(), key=len, reverse=True)

    def resolve(self, term: str) -> TermResolution:
        raw = term.strip()

        hit = self._exact.get(raw)
        tier = TIER_TMS_EXACT
        if hit is None:
            hit, tier = self._norm.get(normalise_arabic(raw)), TIER_TMS_NORM
        if hit is None:
            hit, tier = self._noal.get(normalise_arabic(raw, strip_al=True)), TIER_TMS_DIALECT
        if hit is None:
            hit, tier = self._ifrs_norm.get(normalise_arabic(raw)), TIER_IFRS

        if hit is None:
            return TermResolution(raw, None, TIER_UNMAPPED, flag="TERM-UNMAPPED")

        if hit.do_not_translate:
            return TermResolution(raw, raw, tier, hit.jurisdiction, flag="DO-NOT-TRANSLATE")

        # Jurisdiction guard: an EG-only rendering must not be applied to a JO file.
        if hit.jurisdiction not in ("ALL", self.jurisdiction) and self.jurisdiction != "ALL":
            return TermResolution(
                raw, hit.english, tier, hit.jurisdiction, flag="JURISDICTION-MISMATCH"
            )

        key = normalise_arabic(raw)
        prior = self.ledger.get(key)
        if prior is not None and prior != hit.english:
            self.conflicts.append((raw, prior, hit.english))
            return TermResolution(raw, prior, tier, hit.jurisdiction, flag="TERM-CONFLICT-LOCKED")
        self.ledger[key] = hit.english
        return TermResolution(raw, hit.english, tier, hit.jurisdiction)

    def scan_untranslated(self, text: str) -> List[str]:
        """Return Arabic runs left in the English mirror (proper nouns excluded upstream)."""
        return re.findall(r"[\u0600-\u06FF\u0750-\u077F]+(?:\s+[\u0600-\u06FF\u0750-\u077F]+)*", text)


# ---------------------------------------------------------------------------
# SECTION 3 -- NUMBER-QC
# ---------------------------------------------------------------------------

# Currencies with THREE decimal places. A generic "comma before last two
# digits = decimal" rule silently divides these by 10 or multiplies by 10.
THREE_DECIMAL_CCY = {"JOD", "KWD", "BHD", "OMR", "TND", "LYD", "IQD"}
TWO_DECIMAL_CCY = {"EGP", "SAR", "AED", "QAR", "USD", "EUR", "MAD", "LBP", "SYP", "YER"}

# Bidi bracket mirroring: an RTL run can emit the visually mirrored bracket.
_MIRROR = {"\uFD3E": "(", "\uFD3F": ")"}


@dataclass
class NumberQC:
    raw: str
    value: Optional[Decimal]
    normalised: str
    negative: bool = False
    flags: List[str] = field(default_factory=list)
    severity: str = "OK"          # OK | MAJOR | CRITICAL


def _set_severity(qc: NumberQC, level: str) -> None:
    rank = {"OK": 0, "MAJOR": 1, "CRITICAL": 2}
    if rank[level] > rank[qc.severity]:
        qc.severity = level


def parse_number(raw: str, currency: str = "SAR", decimals: Optional[int] = None) -> NumberQC:
    """
    Normalise one numeric cell and raise QC flags.

    `decimals` overrides the currency default and is what makes JOD/KWD/BHD
    safe: with decimals=3, '1,234,567' stays 1234567 and '1,234.567' stays
    1234.567 -- neither is coerced by a last-two-digits heuristic.
    """
    qc = NumberQC(raw=raw, value=None, normalised=raw)
    s = raw

    for bad, good in _MIRROR.items():
        if bad in s:
            s = s.replace(bad, good)
            qc.flags.append("BIDI-MIRRORED-BRACKET")
            _set_severity(qc, "MAJOR")

    s = _INVISIBLE.sub("", s)
    s = convert_numerals(s).strip()

    if re.search(r"\?{2,}|[\uFFFD]|#{3,}", s):
        qc.flags.append("JUNK-OR-MOJIBAKE")
        _set_severity(qc, "CRITICAL")
        return qc

    negative = False
    if re.fullmatch(r"\(\s*[^()]*\s*\)", s):
        negative = True
        s = s[1:-1].strip()
    elif s.count("(") != s.count(")"):
        qc.flags.append("UNBALANCED-PARENTHESIS-ON-NEGATIVE")
        _set_severity(qc, "CRITICAL")
        s = s.replace("(", "").replace(")", "")
        negative = True

    trail = re.fullmatch(r"(.*?)\s*-\s*", s)
    if trail:
        negative = True
        s = trail.group(1).strip()
        qc.flags.append("TRAILING-MINUS-MOVED")
        _set_severity(qc, "MAJOR")
    elif s.startswith("-"):
        negative = True
        s = s[1:].strip()

    is_pct = s.endswith("%")
    if is_pct:
        s = s[:-1].strip()

    trailing_junk = re.fullmatch(r"([0-9.,\s]+?)[^0-9.,\s]+", s)
    if trailing_junk:
        qc.flags.append("TRAILING-JUNK-REMOVED")
        _set_severity(qc, "MAJOR")
        s = trailing_junk.group(1)

    # Internal spaces: a French-style thousands separator (1 234 567) is
    # legitimate and common in Egyptian and Levantine statements. Groups of
    # exactly 3 are a separator; anything else is OCR damage.
    if " " in s.strip():
        parts = s.strip().split()
        if len(parts) > 1 and all(re.fullmatch(r"\d{3}", p) for p in parts[1:]) \
                and re.fullmatch(r"\d{1,3}", parts[0]):
            s = "".join(parts)
            qc.flags.append("SPACE-THOUSANDS-SEPARATOR-PRESERVED")
        else:
            s = "".join(parts)
            qc.flags.append("INTERNAL-SPACE-REPAIRED-VERIFY-MAGNITUDE")
            _set_severity(qc, "CRITICAL")

    if decimals is None:
        decimals = 3 if currency.upper() in THREE_DECIMAL_CCY else 2

    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            qc.flags.append("SWAPPED-SEPARATORS-EU-STYLE")
            _set_severity(qc, "CRITICAL")
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        groups = s.split(",")
        if all(re.fullmatch(r"\d{3}", g) for g in groups[1:]) and re.fullmatch(r"\d{1,3}", groups[0]):
            s = s.replace(",", "")
        elif len(groups) == 2 and len(groups[1]) == decimals:
            s = s.replace(",", ".")          # comma acting as decimal mark
        else:
            qc.flags.append("MALFORMED-THOUSANDS-GROUPING")
            _set_severity(qc, "CRITICAL")
            s = s.replace(",", "")

    if s.count(".") > 1:
        qc.flags.append("MULTIPLE-DECIMAL-POINTS")
        _set_severity(qc, "CRITICAL")
        head, _, tail = s.rpartition(".")
        s = head.replace(".", "") + "." + tail

    if s in ("", "-", "."):
        qc.flags.append("EMPTY-OR-DASH-CELL")
        qc.normalised = raw.strip()
        return qc

    try:
        val = Decimal(s)
    except InvalidOperation:
        qc.flags.append("UNPARSEABLE-NUMBER")
        _set_severity(qc, "CRITICAL")
        return qc

    if negative:
        val = -val
    qc.value = val
    qc.negative = negative

    frac = -val.as_tuple().exponent
    if frac > decimals:
        qc.flags.append(f"PRECISION-EXCEEDS-{decimals}DP-FOR-{currency.upper()}")
        _set_severity(qc, "MAJOR")

    body = f"{abs(val):,.{min(frac, decimals)}f}" if frac else f"{abs(val):,}"
    qc.normalised = (f"({body})" if negative else body) + ("%" if is_pct else "")
    return qc


# ---------------------------------------------------------------------------
# SECTION 4 -- UMBRELLA / NESTED HEADER FLATTENING
# ---------------------------------------------------------------------------

JOINER = " - "          # MANDATORY umbrella joiner: space-hyphen-space.
_SPLIT = re.compile(r"\s-\s")


def flatten_headers(levels: Sequence[Sequence[Optional[str]]]) -> List[str]:
    """
    Fold an N-level header pyramid, top -> leaf, into one label per LEAF column,
    joined by ' - '.

    `levels` is top-level-first. Use None for a spanned continuation cell; the
    label carries down (rowspan pass-down). Use "" for a genuinely empty level,
    which contributes nothing to the joined label.

        [["Assets", None,  "Liabilities", None ],
         ["2025",   "2024","2025",        "2024"]]
      -> ["Assets - 2025", "Assets - 2024",
          "Liabilities - 2025", "Liabilities - 2024"]

    Guard: a source label containing a SPACED hyphen would make the joined
    label ambiguous when split back, so it is tightened to an unspaced hyphen.
    'Non-current' (unspaced) is untouched and round-trips safely.
    """
    if not levels:
        return []
    width = max(len(r) for r in levels)
    filled: List[List[str]] = []
    for row in levels:
        row = list(row) + [None] * (width - len(row))
        carried: List[str] = []
        last = ""
        for cell in row:
            if cell is None:
                carried.append(last)
            else:
                lab = _SPLIT.sub("-", str(cell).strip())
                carried.append(lab)
                last = lab
        filled.append(carried)

    out = []
    for c in range(width):
        parts = [filled[r][c] for r in range(len(filled)) if filled[r][c]]
        out.append(JOINER.join(parts))
    return out


def verify_leaf_parity(flattened: Sequence[str], source_leaf_count: int) -> Tuple[bool, str]:
    ok = len(flattened) == source_leaf_count
    return ok, (
        f"leaf columns {len(flattened)} == source {source_leaf_count}"
        if ok else
        f"COLUMN COUNT MISMATCH: flattened {len(flattened)} vs source leaf {source_leaf_count}"
    )


def unflatten(label: str) -> List[str]:
    """Split a flattened label back into its levels -- proves round-trip safety."""
    return _SPLIT.split(label) if label else []


# ---------------------------------------------------------------------------
# SECTION 5 -- SIDE-BY-SIDE BLOCK ORDERING
# ---------------------------------------------------------------------------

def order_side_by_side(blocks: Sequence[dict], source_direction: str = "RTL") -> List[dict]:
    """
    Order blocks detected on one physical page.

    An Arabic page is laid out RIGHT-to-LEFT, so the logically FIRST block is
    the one with the LARGEST x coordinate. Processing "left then right" on an
    Arabic source inverts the document's own reading order -- see GAP SBS-01.

    Each block: {"id":..., "x_left":float, "x_right":float, "y_top":float}
    Blocks are grouped into rows by y_top, then ordered within the row.
    """
    reverse = source_direction.upper() == "RTL"
    rows: List[List[dict]] = []
    for b in sorted(blocks, key=lambda b: b["y_top"]):
        placed = False
        for row in rows:
            if abs(row[0]["y_top"] - b["y_top"]) <= 40:      # same band tolerance
                row.append(b)
                placed = True
                break
        if not placed:
            rows.append([b])
    out: List[dict] = []
    for row in rows:
        out.extend(sorted(row, key=lambda b: b["x_left"], reverse=reverse))
    return out


def detect_gutter(column_ink: Sequence[int], min_gap_px: int = 25) -> Optional[Tuple[int, int]]:
    """
    Find the widest empty vertical band in a whitespace projection profile.
    Returns (start, end) or None. Splitting at the gutter is what prevents a
    row from one table being merged with a row from the table beside it.
    """
    best = cur = None
    for i, v in enumerate(list(column_ink) + [1]):
        if v == 0:
            cur = i if cur is None else cur
        else:
            if cur is not None:
                if best is None or (i - cur) > (best[1] - best[0]):
                    best = (cur, i)
                cur = None
    if best and (best[1] - best[0]) >= min_gap_px:
        return best
    return None


# ---------------------------------------------------------------------------
# SECTION 6 -- TABLE TOTALS VALIDATION (vertical, horizontal, cross-foot)
# ---------------------------------------------------------------------------

TICK, CROSS, WARN = "\u2705", "\u274C", "\u26A0\uFE0F"


@dataclass
class CheckResult:
    scope: str
    label: str
    expected: Optional[Decimal]
    reported: Optional[Decimal]
    delta: Optional[Decimal]
    status: str
    symbol: str

    def as_row(self) -> List[str]:
        f = lambda d: "" if d is None else f"{d:,}"
        return [self.scope, self.label, f(self.expected), f(self.reported), f(self.delta),
                self.status, self.symbol]


def _judge(expected: Decimal, reported: Decimal, tolerance: Decimal) -> Tuple[str, str]:
    delta = reported - expected
    if delta == 0:
        return "MATCH", TICK
    if abs(delta) <= tolerance:
        return "ROUNDING", WARN
    return "MISMATCH", CROSS


def validate_vertical(rows: Sequence[Tuple[str, Sequence[Optional[Decimal]]]],
                      subtotal_map: Dict[str, Sequence[str]],
                      tolerance: Decimal = Decimal("0")) -> List[CheckResult]:
    """
    subtotal_map: {"Total current assets": ["Cash", "Receivables", ...]}
    One CheckResult per (subtotal row, column).
    """
    by_label = {lab: vals for lab, vals in rows}
    out: List[CheckResult] = []
    for total_label, components in subtotal_map.items():
        if total_label not in by_label:
            out.append(CheckResult("VERTICAL", total_label, None, None, None,
                                   "SUBTOTAL-ROW-MISSING", CROSS))
            continue
        reported_row = by_label[total_label]
        for ci in range(len(reported_row)):
            missing = [c for c in components if c not in by_label]
            if missing:
                out.append(CheckResult("VERTICAL", f"{total_label} [col {ci+1}]", None, None, None,
                                       f"COMPONENT-ROW-MISSING: {', '.join(missing)}", CROSS))
                break
            vals = [by_label[c][ci] for c in components]
            if any(v is None for v in vals) or reported_row[ci] is None:
                out.append(CheckResult("VERTICAL", f"{total_label} [col {ci+1}]", None, None, None,
                                       "NULL-CELL-IN-RANGE", WARN))
                continue
            exp = sum(vals, Decimal("0"))
            rep = reported_row[ci]
            status, sym = _judge(exp, rep, tolerance)
            out.append(CheckResult("VERTICAL", f"{total_label} [col {ci+1}]",
                                   exp, rep, rep - exp, status, sym))
    return out


def validate_horizontal(rows: Sequence[Tuple[str, Sequence[Optional[Decimal]]]],
                        component_cols: Sequence[int], total_col: int,
                        tolerance: Decimal = Decimal("0")) -> List[CheckResult]:
    """Row-wise cross-cast: components across the row must equal the total column."""
    out: List[CheckResult] = []
    for label, vals in rows:
        try:
            parts = [vals[i] for i in component_cols]
            rep = vals[total_col]
        except IndexError:
            out.append(CheckResult("HORIZONTAL", label, None, None, None,
                                   "COLUMN-INDEX-OUT-OF-RANGE", CROSS))
            continue
        if any(p is None for p in parts) or rep is None:
            out.append(CheckResult("HORIZONTAL", label, None, None, None,
                                   "NULL-CELL-IN-RANGE", WARN))
            continue
        exp = sum(parts, Decimal("0"))
        status, sym = _judge(exp, rep, tolerance)
        out.append(CheckResult("HORIZONTAL", label, exp, rep, rep - exp, status, sym))
    return out


def validate_crossfoot(vertical_total: Optional[Decimal], horizontal_total: Optional[Decimal],
                       label: str = "Grand total", tolerance: Decimal = Decimal("0")) -> CheckResult:
    """The corner cell must be reachable both ways. This catches a whole dropped row."""
    if vertical_total is None or horizontal_total is None:
        return CheckResult("CROSS-FOOT", label, vertical_total, horizontal_total, None,
                           "NULL-TOTAL", WARN)
    status, sym = _judge(vertical_total, horizontal_total, tolerance)
    return CheckResult("CROSS-FOOT", label, vertical_total, horizontal_total,
                       horizontal_total - vertical_total, status, sym)


def validate_balance_sheet(assets: Decimal, liabilities: Decimal, equity: Decimal,
                           tolerance: Decimal = Decimal("0")) -> CheckResult:
    exp = liabilities + equity
    status, sym = _judge(exp, assets, tolerance)
    return CheckResult("BALANCE", "Assets = Liabilities + Equity", exp, assets,
                       assets - exp, status, sym)


# ---------------------------------------------------------------------------
# SECTION 7 -- FIDELITY PARITY LOG
# ---------------------------------------------------------------------------

@dataclass
class PageParity:
    page: int
    src_lines: int
    out_lines: int
    src_tables: int
    out_tables: int
    src_rows: int
    out_rows: int
    src_cols: int
    out_cols: int
    orientation_src: str = "portrait"
    orientation_out: str = "portrait"

    def checks(self) -> List[Tuple[str, str]]:
        pairs = [("Lines", self.src_lines, self.out_lines),
                 ("Tables", self.src_tables, self.out_tables),
                 ("Rows", self.src_rows, self.out_rows),
                 ("Cols", self.src_cols, self.out_cols)]
        return [(n, TICK if a == b else CROSS) for n, a, b in pairs]

    @property
    def passed(self) -> bool:
        return all(sym == TICK for _, sym in self.checks())

    def as_row(self) -> List[str]:
        c = dict(self.checks())
        return [str(self.page),
                f"{self.src_lines}/{self.out_lines} {c['Lines']}",
                f"{self.src_tables}/{self.out_tables} {c['Tables']}",
                f"{self.src_rows}/{self.out_rows} {c['Rows']}",
                f"{self.src_cols}/{self.out_cols} {c['Cols']}",
                f"{self.orientation_src}->{self.orientation_out}",
                TICK if self.passed else CROSS]


def render_fidelity_table(pages: Sequence[PageParity]) -> str:
    head = ("| Page | Lines src/out | Tables src/out | Rows src/out | Cols src/out "
            "| Orientation | Page verdict |")
    sep = "|---|---|---|---|---|---|---|"
    body = ["| " + " | ".join(p.as_row()) + " |" for p in pages]
    ok = sum(1 for p in pages if p.passed)
    body.append(f"| **TOTAL** | | | | | | **{ok}/{len(pages)} pages "
                f"{TICK if ok == len(pages) else CROSS}** |")
    return "\n".join([head, sep] + body)


def render_check_table(results: Sequence[CheckResult]) -> str:
    head = "| Scope | Label | Expected | Reported | Delta | Status | |"
    sep = "|---|---|---|---|---|---|---|"
    body = ["| " + " | ".join(r.as_row()) + " |" for r in results]
    bad = sum(1 for r in results if r.symbol == CROSS)
    body.append(f"| **TOTAL** | {len(results)} checks | | | | "
                f"**{bad} failed** | {TICK if bad == 0 else CROSS} |")
    return "\n".join([head, sep] + body)


# ---------------------------------------------------------------------------
# SECTION 8 -- BATCH SIZING (complexity-weighted, replaces fixed page count)
# ---------------------------------------------------------------------------

PAGE_WEIGHTS = {"narrative": 1, "simple_table": 2, "dense_table": 3, "wide_or_nested": 4}
DEFAULT_BUDGET = 15
HARD_PAGE_CAP = 15


def plan_batches(page_types: Sequence[str], budget: int = DEFAULT_BUDGET,
                 hard_cap: int = HARD_PAGE_CAP) -> List[Tuple[int, int, int]]:
    """
    Return [(start_page, end_page, weight)] 1-indexed.

    15 narrative pages -> one batch. Four wide nested tables -> one batch.
    This is why a flat '15 pages per reply' fails: it is the wrong unit.
    A single page never splits, even if it exceeds the budget on its own.
    """
    batches, start, weight, count = [], 1, 0, 0
    for i, t in enumerate(page_types, start=1):
        w = PAGE_WEIGHTS.get(t, 3)
        if count and (weight + w > budget or count + 1 > hard_cap):
            batches.append((start, i - 1, weight))
            start, weight, count = i, 0, 0
        weight += w
        count += 1
    if count:
        batches.append((start, len(page_types), weight))
    return batches


# ---------------------------------------------------------------------------
# SECTION 9 -- v2.1  SPAN HEADER RENDERING (three layers, one source of truth)
# ---------------------------------------------------------------------------
# A spanned header is printed ONCE in the PDF. Repeating it into every leaf
# column would put text on the page that the source does not contain, which
# breaches REPLICA-ONLY -- the highest authority rule. So the folded " - " form
# is confined to the validation layer, and the two delivered layers reproduce
# the span exactly as printed.
#
#   MERGED  -> .docx        : one cell carrying the label, spanning its leaves.
#   MIRROR  -> on-screen    : label in the first leaf, continuation leaves BLANK.
#   FOLDED  -> validation   : "Assets - 2025" -- never delivered, never printed.

SPAN_MERGED, SPAN_MIRROR, SPAN_FOLDED = "MERGED", "MIRROR", "FOLDED"


def _carry(levels: Sequence[Sequence[Optional[str]]]) -> List[List[str]]:
    """Resolve rowspan/colspan continuation (None) into carried labels."""
    if not levels:
        return []
    width = max(len(r) for r in levels)
    filled: List[List[str]] = []
    for row in levels:
        row = list(row) + [None] * (width - len(row))
        carried, last = [], ""
        for cell in row:
            if cell is None:
                carried.append(last)
            else:
                lab = str(cell).strip()
                carried.append(lab)
                last = lab
        filled.append(carried)
    return filled


def span_spec(levels: Sequence[Sequence[Optional[str]]]) -> List[List[Tuple[str, int]]]:
    """
    MERGED layer -> the .docx.

    Returns, per header row, a list of (text, colspan). A label that spans four
    leaf columns is emitted once with colspan 4, exactly as the PDF prints it.
    The sum of colspans in every row equals the leaf count, so no column is
    invented or lost.
    """
    filled = _carry(levels)
    out: List[List[Tuple[str, int]]] = []
    for row in filled:
        cells: List[Tuple[str, int]] = []
        for cell in row:
            if cells and cells[-1][0] == cell:
                cells[-1] = (cell, cells[-1][1] + 1)   # extend the span
            else:
                cells.append((cell, 1))
        out.append(cells)
    return out


def render_mirror_header(levels: Sequence[Sequence[Optional[str]]]) -> List[List[str]]:
    """
    MIRROR layer -> the on-screen reply.

    The label appears once, in the first leaf column it covers. Every
    continuation column beneath the same span is left BLANK, because that is
    what the source page shows. Nothing is repeated and nothing is added.
    """
    filled = _carry(levels)
    out: List[List[str]] = []
    for row in filled:
        seen: List[str] = []
        prev: Optional[str] = None
        for cell in row:
            seen.append("" if cell == prev and cell != "" else cell)
            prev = cell
        out.append(seen)
    return out


def verify_span_parity(levels: Sequence[Sequence[Optional[str]]],
                       source_leaf_count: int) -> Tuple[bool, str]:
    """Every rendering layer must resolve to the same leaf count as the source."""
    merged = span_spec(levels)
    mirror = render_mirror_header(levels)
    folded = flatten_headers(levels)
    widths = {sum(n for _, n in row) for row in merged}
    widths |= {len(r) for r in mirror}
    widths.add(len(folded))
    ok = widths == {source_leaf_count}
    return ok, (f"all layers resolve to {source_leaf_count} leaf columns" if ok
                else f"LAYER DISAGREEMENT: {sorted(widths)} vs source {source_leaf_count}")


# ---------------------------------------------------------------------------
# SECTION 10 -- v2.1  ZERO-ANNOTATION GUARD (the mirror carries no commentary)
# ---------------------------------------------------------------------------
# The deliverable is a translation, not a review. Every flag, tick, delta,
# highlight and bracketed marker belongs in the logs. If any of it reaches the
# .docx, the document is no longer an exact copy of the source.

FORBIDDEN_MIRROR_TOKENS = [
    "[TERM-UNMAPPED", "[ILLEGIBLE", "[PREPROCESS-MISSING", "[FLAG",
    "[QC", "[CHECK", "[NOTE:", "[TRANSLATOR", "[SIC", "[VERIFY",
    TICK, CROSS, WARN,
    "MISMATCH", "CRITICAL:", "MAJOR:", "ROUNDING:",
    "<mark", "<span style", "background-color", "highlight",
]


@dataclass
class AnnotationViolation:
    location: str
    token: str
    excerpt: str


def scan_mirror_for_annotations(text: str, location: str = "mirror") -> List[AnnotationViolation]:
    """Any hit is a release blocker: the deliverable is carrying commentary."""
    hits: List[AnnotationViolation] = []
    low = text.lower()
    for tok in FORBIDDEN_MIRROR_TOKENS:
        i = low.find(tok.lower())
        while i != -1:
            hits.append(AnnotationViolation(location, tok,
                                            text[max(0, i - 30): i + len(tok) + 30]))
            i = low.find(tok.lower(), i + 1)
    return hits


def _blank(v: Optional[str]) -> bool:
    return v is None or str(v).strip() == ""


@dataclass
class CellDelta:
    ref: str
    kind: str           # INVENTED | DROPPED | OK
    source: str
    output: str


def check_blank_preservation(source_cells: Sequence[Optional[str]],
                             output_cells: Sequence[Optional[str]],
                             row_ref: str = "r?") -> List[CellDelta]:
    """
    A cell the source leaves empty must stay empty. A cell the source fills must
    stay filled. INVENTED is the dangerous direction: it is the model writing a
    label, a zero or a total into a gap the source deliberately left open.
    """
    out: List[CellDelta] = []
    width = max(len(source_cells), len(output_cells))
    for i in range(width):
        s = source_cells[i] if i < len(source_cells) else None
        o = output_cells[i] if i < len(output_cells) else None
        ref = f"{row_ref}c{i + 1}"
        if _blank(s) and not _blank(o):
            out.append(CellDelta(ref, "INVENTED", "", str(o)))
        elif not _blank(s) and _blank(o):
            out.append(CellDelta(ref, "DROPPED", str(s), ""))
        else:
            out.append(CellDelta(ref, "OK", "" if _blank(s) else str(s),
                                 "" if _blank(o) else str(o)))
    return out


def check_no_synthesised_totals(rows: Sequence[dict]) -> List[CellDelta]:
    """
    The validator re-computes totals to REPORT on them. It must never write one
    back. A row whose total cell is empty in the source and populated in the
    output has been proof-read rather than translated -- a blocker, however
    arithmetically correct the inserted figure is.
    """
    bad: List[CellDelta] = []
    for r in rows:
        if _blank(r.get("source_total")) and not _blank(r.get("output_total")):
            bad.append(CellDelta(r.get("label", "?"), "INVENTED",
                                 "", str(r.get("output_total"))))
    return bad


def check_untranslated_row_not_invented(source_text: Optional[str],
                                        output_text: Optional[str],
                                        ref: str = "row") -> CellDelta:
    """An empty source line stays an empty output line. No filler, no guess."""
    if _blank(source_text):
        return CellDelta(ref, "OK" if _blank(output_text) else "INVENTED",
                         "", "" if _blank(output_text) else str(output_text))
    return CellDelta(ref, "DROPPED" if _blank(output_text) else "OK",
                     str(source_text), "" if _blank(output_text) else str(output_text))


# ---------------------------------------------------------------------------
# SECTION 11 -- v2.1  RUNNING HEADER / FOOTER PARITY
# ---------------------------------------------------------------------------
# A running header belongs in the Word header, not inline in the body. Printed
# page numbers are reproduced as static text, never as an auto-numbering field:
# a field regenerates and can silently diverge from the number the PDF prints.

@dataclass
class HeaderFooterParity:
    page: int
    src_header: str = ""
    out_header: str = ""
    src_footer: str = ""
    out_footer: str = ""
    placement: str = "section"      # section | inline  (inline is a defect)
    page_number_mode: str = "static"  # static | field  (field is a defect)

    def issues(self) -> List[str]:
        bad: List[str] = []
        if (self.src_header or "").strip() != (self.out_header or "").strip():
            bad.append("HEADER-MISMATCH")
        if (self.src_footer or "").strip() != (self.out_footer or "").strip():
            bad.append("FOOTER-MISMATCH")
        if self.placement != "section":
            bad.append("HF-INLINE-IN-BODY")
        if self.page_number_mode != "static":
            bad.append("PAGE-NUMBER-IS-FIELD")
        if not (self.src_header or "").strip() and (self.out_header or "").strip():
            bad.append("HEADER-INVENTED")
        if not (self.src_footer or "").strip() and (self.out_footer or "").strip():
            bad.append("FOOTER-INVENTED")
        return bad

    @property
    def passed(self) -> bool:
        return not self.issues()


def render_header_footer_log(rows: Sequence[HeaderFooterParity]) -> str:
    head = "| Page | Source header | Output header | Source footer | Output footer | Placement | Verdict |"
    sep = "|---|---|---|---|---|---|---|"
    body = []
    for r in rows:
        body.append("| " + " | ".join([
            str(r.page), r.src_header or "(none)", r.out_header or "(none)",
            r.src_footer or "(none)", r.out_footer or "(none)", r.placement,
            TICK if r.passed else CROSS + " " + ",".join(r.issues())]) + " |")
    ok = sum(1 for r in rows if r.passed)
    body.append(f"| **TOTAL** | | | | | | **{ok}/{len(rows)} pages "
                f"{TICK if ok == len(rows) else CROSS}** |")
    return "\n".join([head, sep] + body)


# ---------------------------------------------------------------------------
# SECTION 12 -- v2.3  TMS-FIRST ENFORCEMENT AND THE AI FALLBACK TIER
# ---------------------------------------------------------------------------
# Resolution order, restored to the business requirement:
#   1. TMS Excel      exact -> normalised -> clitic/article variant
#   2. IFRS termbase  curated fallback file
#   3. AI             the model translates in formal Arabic-GAAP / IFRS
#                     financial-reporting English, logged AI-TRANSLATED
# Nothing is left in Arabic except Do-Not-Translate entries.
#
# Why a PRE-PASS exists: a knowledge file uploaded to the agent is indexed for
# semantic search, not queried as a table. Retrieval returns chunks that look
# relevant; it does not guarantee the row for every term on the page. So "TMS
# first" cannot rest on the model finding the right row. The flow reads the
# Excel as a table, finds every TMS term in the batch deterministically, and
# hands the model a TMS HITS list. The model then only has to obey it.

TIER_AI = "AI-IFRS-TRANSLATION"

_HEADER_ALIASES = {
    "arabic": {"native", "arabic", "arabic_term", "arabic term", "source",
               "source_term", "source term", "ar", "native_term", "native term",
               "term", "\u0639\u0631\u0628\u064a", "\u0627\u0644\u0645\u0635\u0637\u0644\u062d"},
    "english": {"english", "english_term", "english term", "target", "target_term",
                "target term", "en", "translation",
                "\u0627\u0646\u062c\u0644\u064a\u0632\u064a",
                "\u0627\u0644\u0625\u0646\u062c\u0644\u064a\u0632\u064a\u0629"},
}


@dataclass
class TMSLoadReport:
    entries: List[GlossaryEntry]
    header_row: Optional[int]
    native_col: int
    english_col: int
    skipped_blank: int = 0
    duplicates: List[Tuple[str, str, str]] = field(default_factory=list)  # (native, kept, other)

    @property
    def ok(self) -> bool:
        return bool(self.entries) and not self.duplicates


def load_tms_rows(rows: Sequence[Sequence[object]]) -> TMSLoadReport:
    """
    Load a TMS from table rows. Built for the simplest real glossary: two
    columns, Native and English. Extra columns are ignored; jurisdiction
    defaults to ALL when absent.

    A header row is recognised by its labels (Native/Arabic/Source and
    English/Target, in English or Arabic). If none is found and the sheet is
    two columns wide, column 1 is native and column 2 is English.

    A native term mapped to two DIFFERENT English terms is reported, never
    resolved silently by keeping whichever row came first: that decision
    belongs to the glossary owner.
    """
    rows = [list(r) for r in rows]
    hdr_idx, n_col, e_col = None, 0, 1
    for i, r in enumerate(rows[:15]):
        labels = [str(c).strip().lower() if c is not None else "" for c in r]
        a = [j for j, v in enumerate(labels) if v in _HEADER_ALIASES["arabic"]]
        e = [j for j, v in enumerate(labels) if v in _HEADER_ALIASES["english"]]
        if a and e:
            hdr_idx, n_col, e_col = i, a[0], e[0]
            break

    body = rows[hdr_idx + 1:] if hdr_idx is not None else rows
    entries: List[GlossaryEntry] = []
    seen: Dict[str, str] = {}
    dups: List[Tuple[str, str, str]] = []
    skipped = 0
    for r in body:
        nat = r[n_col] if n_col < len(r) else None
        eng = r[e_col] if e_col < len(r) else None
        nat = str(nat).strip() if nat is not None else ""
        eng = str(eng).strip() if eng is not None else ""
        if not nat or not eng:
            skipped += 1
            continue
        key = normalise_arabic(nat)
        if key in seen:
            if seen[key] != eng:
                dups.append((nat, seen[key], eng))
            continue
        seen[key] = eng
        entries.append(GlossaryEntry(nat, clean_value(eng), note=eng))
    # Conflicting duplicates: NEITHER rendering is applied, matching
    # check_arabic_master(). Picking the first would be arbitrary, and if it is
    # the wrong one an approved-looking error enters the document silently.
    # Dropping both sends the term to the AI tier, where it is logged
    # AI-TRANSLATED and surfaces in TMS CANDIDATES -- visible, not silent.
    bad = {normalise_arabic(clean_key(n)) for n, _, _ in dups}
    entries = [e for e in entries if normalise_arabic(clean_key(e.arabic)) not in bad]
    return TMSLoadReport(entries, hdr_idx, n_col, e_col, skipped, dups)


def load_tms_xlsx(path: str) -> TMSLoadReport:
    """Read the TMS workbook: the 'Glossary' sheet if present, else the first."""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb["Glossary"] if "Glossary" in wb.sheetnames else wb.worksheets[0]
    return load_tms_rows(list(ws.iter_rows(values_only=True)))


# Attached prefixes. Only the forms that CARRY the article are stripped, because
# a bare leading waw or ba is often part of the word itself: ودائع is
# "deposits", not "and" + something.
_CLITIC_PREFIXES = ("\u0648\u0627\u0644", "\u0641\u0627\u0644", "\u0628\u0627\u0644",
                    "\u0643\u0627\u0644")            # وال فال بال كال
_LAM_LAM = "\u0644\u0644"                              # لل  (li + al, alef elided)


def conj_variants(word: str) -> List[str]:
    """
    Last-resort lookup key: a bare leading و or ف with no article.
    "وحسابات" = "and accounts". This is tried ONLY after the whole word and the
    article-carrying forms have missed, so a word that genuinely begins with waw
    ("ودائع" = deposits) resolves as itself whenever it is in the glossary.
    """
    out: List[str] = []
    for p in ("\u0648", "\u0641"):
        if word.startswith(p) and len(word) > 3:
            out.append(word[1:])
    return out


def clitic_variants(word: str) -> List[str]:
    """Lookup keys for a word carrying an attached preposition + article."""
    out: List[str] = []
    for p in _CLITIC_PREFIXES:
        if word.startswith(p) and len(word) > len(p) + 1:
            out.append("\u0627\u0644" + word[len(p):])   # restore ال
    if word.startswith(_LAM_LAM) and len(word) > 3:
        out.append("\u0627\u0644" + word[2:])
    return out


@dataclass
class TMSHit:
    start_tok: int
    end_tok: int            # exclusive
    source: str
    english: str
    tier: str


# Arabic LETTERS and marks only. The Arabic block also holds punctuation --
# comma U+060C, semicolon U+061B, question mark U+061F, full stop U+06D4 -- and
# the Arabic-Indic digits and separators U+0660-066D. A class spanning the whole
# block glues "، " onto the preceding word, so "والمخزون،" never matches the TMS
# entry "المخزون" and the term silently falls through to AI translation.
_AR_TOKEN = re.compile(
    r"[\u0621-\u063A\u0640-\u065F\u0670-\u06D3\u06D5-\u06ED"
    r"\u06EE\u06EF\u06FA-\u06FF\u0750-\u077F]+")


def tms_prepass(text: str, resolver: "GlossaryResolver",
                max_words: int = 8) -> List[TMSHit]:
    """
    Find every TMS term in a block of source text: leftmost, longest first,
    non-overlapping. A multi-word term therefore wins over its components, and
    a term embedded in a sentence is found as reliably as one alone in a cell.

    Only TMS tiers are reported. The IFRS termbase and the AI tier are for what
    this pass leaves over.
    """
    toks = [(m.group(0), m.start(), m.end()) for m in _AR_TOKEN.finditer(text)]
    hits: List[TMSHit] = []
    i = 0
    tms_tiers = (TIER_TMS_EXACT, TIER_TMS_NORM, TIER_TMS_DIALECT)
    while i < len(toks):
        found = None
        for n in range(min(max_words, len(toks) - i), 0, -1):
            words = [t[0] for t in toks[i:i + n]]
            phrase = text[toks[i][1]:toks[i + n - 1][2]]
            candidates = [phrase]
            for v in clitic_variants(words[0]):
                candidates.append(" ".join([v] + words[1:]))
            for v in conj_variants(words[0]):          # last resort
                candidates.append(" ".join([v] + words[1:]))
            for ci, c in enumerate(candidates):
                r = resolver.peek(c)
                if r is not None and r.tier in tms_tiers:
                    # a hit reached through a clitic variant is reported as such,
                    # so the log shows how the match was made
                    tier = r.tier if ci == 0 else TIER_TMS_DIALECT
                    found = TMSHit(i, i + n, phrase, r.english, tier)
                    break
            if found:
                break
        if found:
            hits.append(found)
            i = found.end_tok
        else:
            i += 1
    return hits


def render_tms_hits(hits: Sequence[TMSHit]) -> str:
    """The table the flow injects ahead of each batch."""
    head = "| # | Native (source) | English -- insert VERBATIM | Tier |"
    sep = "|---|---|---|---|"
    rows = [f"| {k} | {h.source} | {h.english} | {h.tier} |"
            for k, h in enumerate(hits, 1)]
    return "\n".join(["TMS HITS FOR THIS BATCH", head, sep] + rows)


def verify_tms_applied(output_text: str, hits: Sequence[TMSHit]) -> List[TMSHit]:
    """
    Every TMS hit's English must appear VERBATIM in the output: same words,
    same spelling, same capitalisation. Returns the hits that did not. An empty
    list is the proof that the TMS was applied rather than paraphrased.
    """
    return [h for h in hits if h.english not in output_text]


def _peek(self: "GlossaryResolver", term: str) -> Optional[TermResolution]:
    """Resolve WITHOUT touching the session ledger -- used by the pre-pass."""
    raw = term.strip()
    for key, table, tier in (
        (raw, self._exact, TIER_TMS_EXACT),
        (normalise_arabic(raw), self._norm, TIER_TMS_NORM),
        (normalise_arabic(raw, strip_al=True), self._noal, TIER_TMS_DIALECT),
        (normalise_arabic(raw), self._ifrs_norm, TIER_IFRS),
    ):
        hit = table.get(key)
        if hit is not None:
            return TermResolution(raw, hit.english, tier, hit.jurisdiction)
    return None


def _resolve_with_ai(self: "GlossaryResolver", term: str,
                     ai_english: str) -> TermResolution:
    """
    Tier 3. Called only after the TMS and the termbase have both missed.

    - A TMS or termbase hit ALWAYS wins; the AI proposal is discarded, and if it
      differed the attempt is recorded as AI-OVERRIDE-BLOCKED.
    - An AI rendering is locked into the session ledger, so the same term is
      translated the same way on page 3 and page 190.
    - Every AI rendering is flagged AI-TRANSLATED, which is what puts it on the
      reviewer's TMS-candidates list.
    """
    r = self.resolve(term)
    if r.tier != TIER_UNMAPPED:
        if ai_english and r.english and ai_english.strip() != r.english:
            self.blocked_overrides.append((term.strip(), r.english, ai_english.strip()))
            r.flag = r.flag or "AI-OVERRIDE-BLOCKED"
        return r
    key = normalise_arabic(term)
    locked = self.ledger.get(key)
    if locked is not None:
        return TermResolution(term.strip(), locked, TIER_AI, flag="AI-TRANSLATED")
    eng = (ai_english or "").strip()
    if not eng:
        return TermResolution(term.strip(), None, TIER_UNMAPPED, flag="TERM-UNMAPPED")
    self.ledger[key] = eng
    self.ai_terms.append((term.strip(), eng))
    return TermResolution(term.strip(), eng, TIER_AI, flag="AI-TRANSLATED")


def _tms_candidates(self: "GlossaryResolver") -> str:
    """LOG 3 appendix: every AI rendering, ready to paste into the TMS Excel."""
    head = "TMS CANDIDATES (AI-translated this session -- review, then add to the TMS)"
    rows = ["| Native | English (AI proposal) |", "|---|---|"]
    rows += [f"| {a} | {e} |" for a, e in self.ai_terms]
    return "\n".join([head] + rows)


_orig_init = GlossaryResolver.__init__


def _init_v23(self, *a, **kw):
    _orig_init(self, *a, **kw)
    self.ai_terms: List[Tuple[str, str]] = []
    self.blocked_overrides: List[Tuple[str, str, str]] = []
    # Index the edge-cleaned form as well, so a glossary entry carrying the
    # document's own bullet ("قروض عقارية -") still matches the clean term
    # printed on the page. Without this, a correct entry never fires.
    for tbl in (getattr(self, "_exact", {}),):
        for ent in list(tbl.values()):
            ck = clean_key(ent.arabic)
            if ck and ck != ent.arabic.strip():
                self._exact.setdefault(ck, ent)
            self._norm.setdefault(normalise_arabic(ck), ent)
            self._noal.setdefault(normalise_arabic(ck, strip_al=True), ent)
    self._ordered = sorted(self._norm.keys(), key=len, reverse=True)


GlossaryResolver.__init__ = _init_v23
GlossaryResolver.peek = _peek
GlossaryResolver.resolve_with_ai = _resolve_with_ai
GlossaryResolver.tms_candidates = _tms_candidates


# ---------------------------------------------------------------------------
# SECTION 13 -- v3.0  ARABIC MASTER: CLEANING AND HEALTH CHECK
# ---------------------------------------------------------------------------
# The Arabic Master is the TOP-priority tier, so its defects are applied to the
# document verbatim. Three classes of row are handled differently:
#
#   EXCLUDED   not terminology at all -- header repeats, dash-only rows, rows
#              with no Arabic letters. Applying "---- -> -" would collapse dash
#              runs in the document, which breaches REPLICA-ONLY (authority 1,
#              above the glossary). These are never loaded.
#   AUTO-FIXED list markers, note references and edge punctuation that belong to
#              the document's layout, not to the term. Stripped, then loaded.
#   REVIEW     loaded and APPLIED (the business rule: linguist-verified entries
#              win) but listed for the linguist, because the row shows a pattern
#              that usually means the extraction that built it was damaged.

_HDR_WORDS = _HEADER_ALIASES["arabic"] | _HEADER_ALIASES["english"]
_AR_LETTER = re.compile(r"[\u0621-\u063A\u0641-\u064A\u0671-\u06D3]")
_EDGE = r"[\s\-\u2010-\u2015\u2212\u00b7\u2022*:;\u060c\u061b.,]+"
_ENUM = r"\(\s*(?:\d{1,3}|[A-Za-z]|[\u0621-\u064A])\s*\)"


def _strip_edges(s: str) -> Tuple[str, bool]:
    """Remove list markers, enumerators and note references at either edge."""
    orig = s
    for _ in range(6):                      # repeat: "(2) (a) 6 - Term" needs several passes
        before = s
        s = re.sub(r"^" + _EDGE, "", s)
        s = re.sub(_EDGE + r"$", "", s)
        s = re.sub(r"^" + _ENUM + r"\s*", "", s)
        s = re.sub(r"\s*" + _ENUM + r"$", "", s)
        s = re.sub(r"^\d{1,3}\s*[-\u2013\u2014.)]\s*", "", s)   # "6 - Term"
        if s == before:
            break
    s = re.sub(r"\s{2,}", " ", s).strip()
    return s, s != orig.strip()


_MONTHS = ("\u064a\u0646\u0627\u064a\u0631 \u0641\u0628\u0631\u0627\u064a\u0631 \u0645\u0627\u0631\u0633 "
           "\u0623\u0628\u0631\u064a\u0644 \u0627\u0628\u0631\u064a\u0644 \u0645\u0627\u064a\u0648 "
           "\u064a\u0648\u0646\u064a\u0648 \u064a\u0648\u0644\u064a\u0648 \u0623\u063a\u0633\u0637\u0633 "
           "\u0633\u0628\u062a\u0645\u0628\u0631 \u0623\u0643\u062a\u0648\u0628\u0631 \u0646\u0648\u0641\u0645\u0628\u0631 "
           "\u062f\u064a\u0633\u0645\u0628\u0631").split()
_PREPS = r"(?:\u0645\u0639|\u0641\u064a|\u0641\u0649|\u0645\u0646|\u0639\u0644\u0649|\u0625\u0644\u0649|\u0627\u0644\u0649|\u0639\u0646)"


def arabic_master_signals(ar: str, en: str) -> List[Tuple[str, str, str]]:
    """
    Heuristic review signals for one CLEANED row: (code, severity, explanation).
    Heuristics -- they say 'suspected', never 'wrong'. A linguist decides.
    """
    out: List[Tuple[str, str, str]] = []
    toks = ar.split()

    if "?" in en:
        out.append(("TRANSLATOR-UNCERTAIN", "HIGH",
                    "English contains '?': the rendering was not settled when the row was entered."))
    if any(t[0] in "\u0629\u0649" for t in toks if t):
        out.append(("SUSPECTED-REVERSED", "HIGH",
                    "A word starts with \u0629 or \u0649, which cannot begin an Arabic word: the "
                    "letters look reversed (typical of PDF text extracted in visual order)."))
    elif any(len(t) >= 5 and t.endswith("\u0644\u0627") and not t.startswith("\u0627\u0644") for t in toks):
        out.append(("SUSPECTED-REVERSED", "HIGH",
                    "A word ends in \u0644\u0627 -- the article \u0627\u0644 reversed onto the end of the word."))
    if re.search(r"(?:^|\s)" + _PREPS + r"\s+\u0648\S+", ar) or (toks and re.fullmatch(_PREPS, toks[-1])):
        out.append(("SUSPECTED-WORD-ORDER", "HIGH",
                    "A preposition is followed by a \u0648-word or ends the phrase: the word order "
                    "looks reversed."))
    if re.search(r"(?:^|\s)\u0627\u0627\u0644|\u064a\u0627\u0644\u062a(?:\s|$)|(?:^|\s)\u0648\u0644\u0627\u0644|\u0627\u0627\u0644\u062a(?:\s|$)", ar):
        out.append(("LAM-ALEF-ARTIFACT", "HIGH",
                    "The \u0644\u0627 ligature has been split and swapped (e.g. \u0627\u0644\u062a\u0633\u0647\u064a\u0627\u0644\u062a for "
                    "\u0627\u0644\u062a\u0633\u0647\u064a\u0644\u0627\u062a). Clean source text will never match this row."))
    if (re.search(r"[\u2022!*\[\]{}|<>@#$^~_=+\\'\"]", ar) or re.search(r"[A-Za-z]", ar)
            or re.search(r"[\u0621-\u064A][\d\u0660-\u0669][\u0621-\u064A]", ar)):
        out.append(("OCR-NOISE", "HIGH",
                    "Symbols, Latin letters or digits inside the Arabic term: OCR residue."))
    # و (and), م (AD, ميلادي) and ه (Hijri) legitimately stand alone
    if any(len(t) == 1 and t not in "\u0648\u0645\u0647" and _AR_LETTER.match(t) for t in toks) or \
            re.search(r"(?:^|\s)\u0648\u0627\s+\u0644", ar):
        out.append(("SPLIT-WORD", "HIGH",
                    "A word is broken by a stray space (e.g. '\u0648\u0627\u0644\u0645\u0634\u0631\u0648\u0639\u0627 \u062a'). "
                    "Clean source text will never match this row."))
    en_words = len(en.split())
    if toks and ((en_words >= 1.75 * len(toks) and en_words - len(toks) >= 4)
                 or (toks[0].startswith("\u0648\u0627\u0644") and not en.lower().startswith("and"))):
        out.append(("EXPANSION-RISK", "HIGH",
                    "The Arabic looks like a FRAGMENT of a longer term while the English is complete. "
                    "Applied verbatim, the English would add words the source does not contain."))
    if any(m in ar for m in _MONTHS) or re.search(r"\d{1,4}[/-]\d{1,2}[/-]\d{1,4}", ar):
        out.append(("DATE-ENTRY", "LOW",
                    "A specific date stored as a term. Dates are reproduced as printed (MDR-02); "
                    "a per-date row also imposes one date format on a single date only."))
    if en[:1].islower():
        out.append(("STYLE-CASE", "LOW",
                    "English starts in lower case; it is inserted verbatim, so it will appear lower "
                    "case at the start of a line or table cell."))
    if re.search(r"\bright to use\b", en, re.I):
        out.append(("IFRS-TERMINOLOGY", "LOW",
                    "IFRS 16 uses 'right-of-use assets' and 'lease liabilities'."))
    if re.search(r"\btaxable assets?\b", en, re.I) and re.search(r"[\u0623\u0627]\u0635\u0644 \u0636\u0631\u064a\u0628", ar):
        out.append(("IFRS-TERMINOLOGY", "HIGH",
                    "\u0623\u0635\u0644 \u0636\u0631\u064a\u0628\u064a is a deferred tax ASSET (IAS 12), not 'taxable assets'."))
    return out


@dataclass
class MasterRowFinding:
    row: int                  # 1-based spreadsheet row
    arabic: str
    english: str
    status: str               # EXCLUDED | LOADED | LOADED-REVIEW
    codes: List[str]
    detail: str
    clean_arabic: str = ""
    clean_english: str = ""


def check_arabic_master(rows: Sequence[Sequence[object]],
                        exclude_suspect: bool = False
                        ) -> Tuple[List[GlossaryEntry], List[MasterRowFinding], List[str]]:
    """
    Clean and health-check an Arabic Master sheet (column A Arabic, column B
    English). Returns (entries to load, per-row findings, file-level findings).

    exclude_suspect=False is the default because the business rule is that the
    linguist-verified file wins. Set it True only by decision of the glossary
    owner; the report is identical either way.
    """
    rows = [list(r) + [None, None] for r in rows]
    entries: List[GlossaryEntry] = []
    findings: List[MasterRowFinding] = []
    seen: Dict[str, Tuple[int, str]] = {}
    conflicted: set = set()
    en_dates: List[Tuple[int, str]] = []

    for i, r in enumerate(rows, start=1):
        ar = "" if r[0] is None else str(r[0]).strip()
        en = "" if r[1] is None else str(r[1]).strip()
        if not ar and not en:
            continue
        if ar.lower() in _HDR_WORDS and en.lower() in _HDR_WORDS:
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", ["HEADER-ROW"],
                            "Column label, not a term." + (" Repeated header." if i > 1 else "")))
            continue
        for m in re.finditer(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", en):
            en_dates.append((i, m.group(0)))
        if not ar or not en:
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", ["EMPTY-SIDE"],
                            "One side is empty."))
            continue
        if not re.search(r"[\w\u0600-\u06FF]", ar):
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", ["PUNCTUATION-ONLY"],
                            "Dashes or punctuation only. Loading it would let the agent rewrite dash "
                            "runs in the document, which REPLICA-ONLY forbids."))
            continue
        if not _AR_LETTER.search(ar):
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", ["NO-ARABIC"],
                            "Column A contains no Arabic letters (a bare date, number or English text)."))
            continue

        car, fa = _strip_edges(ar)
        cen, fe = _strip_edges(en)
        codes: List[str] = []
        notes: List[str] = []
        if fa or fe:
            codes.append("AUTO-FIXED")
            notes.append("Edge markers / note references removed: layout, not terminology.")
        sig = arabic_master_signals(car, cen)
        codes += [c for c, _, _ in sig]
        notes += [d for _, _, d in sig]
        high = any(s == "HIGH" for _, s, _ in sig)

        key = normalise_arabic(car)
        if key in conflicted:
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", codes + ["TMS-DUPLICATE"],
                            "Further conflicting duplicate.", car, cen))
            continue
        if key in seen:
            prev_row, prev_en = seen[key]
            if prev_en != cen:
                # Neither row is applied: keeping the first would be choosing one,
                # which is the glossary owner's decision. The term falls through to
                # the termbase / AI tier until the Excel is fixed.
                conflicted.add(key)
                entries[:] = [e for e in entries if normalise_arabic(e.arabic) != key]
                for f in findings:
                    if f.row == prev_row and f.status != "EXCLUDED":
                        f.status = "EXCLUDED"; f.codes.append("TMS-DUPLICATE")
                findings.append(MasterRowFinding(prev_row, "", prev_en, "EXCLUDED",
                                ["TMS-DUPLICATE"], f"Conflicts with row {i}.", "", prev_en)) \
                    if not any(f.row == prev_row for f in findings) else None
                codes.append("TMS-DUPLICATE")
                notes.append(f"Same Arabic as row {prev_row} with different English "
                             f"('{prev_en}'). NEITHER row is applied until the Excel is fixed.")
                findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", codes,
                                " ".join(notes), car, cen))
                continue
            codes.append("EXACT-REPEAT")
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", codes,
                            f"Identical to row {prev_row}.", car, cen))
            continue

        if high and exclude_suspect:
            findings.append(MasterRowFinding(i, ar, en, "EXCLUDED", codes + ["SUSPECT-EXCLUDED"],
                            " ".join(notes), car, cen))
            continue
        seen[key] = (i, cen)
        entries.append(GlossaryEntry(car, cen))
        status = "LOADED-REVIEW" if high else "LOADED"
        if codes:
            findings.append(MasterRowFinding(i, ar, en, status, codes, " ".join(notes), car, cen))

    file_level: List[str] = []
    mdy = [d for _, d in en_dates if int(d.split("/")[1]) > 12]
    dmy = [d for _, d in en_dates if int(d.split("/")[0]) > 12]
    if mdy and dmy:
        file_level.append(f"DATE-FORMAT-INCONSISTENT: English dates use both month-first "
                          f"({mdy[0]}) and day-first ({dmy[0]}). Pick one house style.")
    return entries, findings, file_level


def load_arabic_master_xlsx(path: str, exclude_suspect: bool = False):
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.worksheets[0]
    return check_arabic_master(list(ws.iter_rows(values_only=True)), exclude_suspect)


# ---------------------------------------------------------------------------
# SECTION 13 -- v3.0  TMS HYGIENE: EDGE NOISE AND JUNK ROWS
# ---------------------------------------------------------------------------
# Real termbases are exported from CAT tools and carry the layout of the
# document they came from: leading bullets, trailing dashes, note numbers.
# "قروض عقارية -" is a correct, linguist-approved entry -- but the PDF prints
# "قروض عقارية", so an untreated exact/normalised match fails and the term
# silently falls through to AI translation. The dash defeats the whole glossary.

_EDGE_CHARS = "-\u2010\u2011\u2012\u2013\u2014\u2015\u0640\u2022\u00b7*:\uFF1A\u060C,;\u061B.\u06D4 \t\u00a0"
_NUM_PREFIX = re.compile(
    r"^\s*(\(\s*[0-9\u0660-\u0669\u0621-\u064A]{1,3}\s*\)|[0-9\u0660-\u0669]{1,3}\s*[-.)])\s*")


def clean_value(s: str) -> str:
    """Trim edge noise from the ENGLISH side. A leading '- ' in the glossary
    would otherwise be inserted into the mirror -- a character the source does
    not print, which breaches REPLICA-ONLY."""
    return (s or "").strip().strip(_EDGE_CHARS).strip()


def clean_key(s: str) -> str:
    """Aggressive cleaning for the LOOKUP KEY only: edge noise plus any leading
    note/section number, so '(18) حق استخدام' also matches a bare 'حق استخدام'.
    Never applied to delivered text."""
    t = (s or "").strip().strip(_EDGE_CHARS)
    prev = None
    while prev != t:
        prev = t
        t = _NUM_PREFIX.sub("", t).strip().strip(_EDGE_CHARS)
    return t.strip()


# Row classification and the Arabic Master health report live in
# check_arabic_master() above -- the single normative implementation. The
# helpers below are shared by it and by the generic two-column loader.


# ---------------------------------------------------------------------------
# CLI -- glossary health, so the team can check the Arabic Master before a run
# ---------------------------------------------------------------------------
def _cli() -> int:
    import argparse
    import os
    import sys
    import openpyxl
    ap = argparse.ArgumentParser(description="MirrorDoc-AR glossary tools")
    ap.add_argument("--health", metavar="XLSX",
                    help="health-check an Arabic Master sheet (col A Arabic, col B English)")
    ap.add_argument("--sheet", default=None, help="sheet name (default: first)")
    a = ap.parse_args()
    if not a.health:
        ap.print_help()
        return 2

    wb = openpyxl.load_workbook(a.health, data_only=True)
    ws = wb[a.sheet] if a.sheet else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    entries, findings, file_notes = check_arabic_master(rows)

    counts: Dict[str, int] = {}
    for f in findings:
        for c in f.codes:
            counts[c] = counts.get(c, 0) + 1

    print("=" * 70)
    print(f"ARABIC MASTER HEALTH -- {os.path.basename(a.health)}")
    print("=" * 70)
    print(f"  rows read        : {len(rows)}")
    print(f"  usable entries   : {len(entries)}")
    print(f"  rows with issues : {sum(1 for f in findings if f.status != 'LOADED')}")
    if file_notes:
        print("  file-level       : " + "; ".join(file_notes))
    print()
    for code, n in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {code:28} {n:>5}")
    print()
    worst = [f for f in findings if f.status == "EXCLUDED"][:12]
    if worst:
        print("  excluded rows (first 12):")
        for f in worst:
            print(f"    row {f.row:<4} {','.join(f.codes)[:34]:36} {str(f.arabic)[:28]}")
    print()
    print("  AUTO-FIXED rows are repaired on load. GARBLED-ARABIC, SUSPECTED-REVERSED")
    print("  and SPLIT-WORD rows will never match a real page -- re-export them.")
    print("  DUPLICATE rows map one term to two English renderings: neither is applied")
    print("  until the glossary owner resolves them.")
    return 0 if entries else 1


if __name__ == "__main__":
    import sys as _sys
    _sys.exit(_cli())
