# -*- coding: utf-8 -*-
"""
MirrorDoc-AR v2.1 -- UAT harness.

Run:  python3 run_uat.py            (human report)
      python3 run_uat.py --json     (machine report for the CI gate)

Every case below is a rule from the agent instructions. If a case fails, the
instruction it encodes is not safe to ship.
"""
from __future__ import annotations

import json
import os
import sys
from decimal import Decimal

from mirrordoc_core import (
    GlossaryEntry, GlossaryResolver, PageParity, TICK, CROSS, WARN,
    convert_numerals, detect_gutter, flatten_headers, normalise_arabic,
    order_side_by_side, parse_number, plan_batches, render_check_table,
    render_fidelity_table, unflatten, validate_balance_sheet,
    validate_crossfoot, validate_horizontal, validate_vertical,
    verify_leaf_parity, TIER_TMS_EXACT, TIER_TMS_NORM, TIER_TMS_DIALECT,
    TIER_IFRS, TIER_UNMAPPED,
    span_spec, render_mirror_header, verify_span_parity,
    scan_mirror_for_annotations, check_blank_preservation,
    check_no_synthesised_totals, check_untranslated_row_not_invented,
    HeaderFooterParity, render_header_footer_log,
    TIER_AI, load_tms_rows, load_tms_xlsx, tms_prepass, render_tms_hits,
    verify_tms_applied, clitic_variants,
    check_arabic_master, arabic_master_signals,
    conj_variants, clean_key, clean_value,
)

RESULTS = []


def check(case_id, group, desc, got, want):
    ok = got == want
    RESULTS.append({"id": case_id, "group": group, "desc": desc,
                    "expected": repr(want), "actual": repr(got),
                    "status": "PASS" if ok else "FAIL"})
    return ok


def check_true(case_id, group, desc, cond, detail=""):
    RESULTS.append({"id": case_id, "group": group, "desc": desc,
                    "expected": "True", "actual": f"{cond} {detail}".strip(),
                    "status": "PASS" if cond else "FAIL"})
    return cond


# ===========================================================================
# GROUP A -- Arabic normalisation and numeral conversion
# ===========================================================================
G = "A. Normalisation"

check("A-01", G, "Tashkeel stripped from lookup key",
      normalise_arabic("الأُصُولُ المُتَداوِلَة"), normalise_arabic("الاصول المتداوله"))

check("A-02", G, "All alef forms unified (أ إ آ ٱ -> ا)",
      normalise_arabic("إجمالي") == normalise_arabic("اجمالي"), True)

check("A-03", G, "Ta marbuta / ha unified (ة -> ه)",
      normalise_arabic("الميزانية") == normalise_arabic("الميزانيه"), True)

check("A-04", G, "Alef maqsura unified (ى -> ي)",
      normalise_arabic("مصطفى") == normalise_arabic("مصطفي"), True)

check("A-05", G, "Tatweel (kashida) removed",
      normalise_arabic("الأصــــول") == normalise_arabic("الأصول"), True)

check("A-06", G, "Bidi/zero-width controls removed",
      normalise_arabic("\u202bالأصول\u202c") == normalise_arabic("الأصول"), True)

check("A-07", G, "Arabic-Indic digits ٠١٢٣٤٥٦٧٨٩ -> Western",
      convert_numerals("١٢٣٤٥٦٧٨٩٠"), "1234567890")

check("A-08", G, "Extended Arabic-Indic (Persian/Urdu ۰۱۲) -> Western",
      convert_numerals("۱۲۳۴۵"), "12345")

check("A-09", G, "Arabic decimal sep U+066B (٫) -> dot  [GAP N-02]",
      convert_numerals("١٢٣٤٫٥٦"), "1234.56")

check("A-10", G, "Arabic thousands sep U+066C (٬) -> comma  [GAP N-02]",
      convert_numerals("١٬٢٣٤٬٥٦٧"), "1,234,567")

check("A-11", G, "Arabic percent U+066A (٪) -> %",
      convert_numerals("١٥٪"), "15%")

check("A-12", G, "Definite-article fallback is a SECOND pass, not the primary key",
      normalise_arabic("الأصول") != normalise_arabic("الأصول", strip_al=True), True)


# ===========================================================================
# GROUP B -- Glossary / TMS resolution order
# ===========================================================================
G = "B. Glossary-first"

TMS = [
    GlossaryEntry("إجمالي الأصول", "Total assets", "BS"),
    GlossaryEntry("الأصول المتداولة", "Current assets", "BS"),
    GlossaryEntry("الأصول غير المتداولة", "Non-current assets", "BS"),
    GlossaryEntry("قائمة المركز المالي", "Statement of financial position", "BS", "EG"),
    GlossaryEntry("الميزانية العمومية", "Statement of financial position", "BS", "SA"),
    GlossaryEntry("الدخل الشامل الآخر", "Other comprehensive income", "PL"),
    GlossaryEntry("أرامكو السعودية", "Saudi Aramco", "ENTITY", do_not_translate=False),
    GlossaryEntry("مخصص", "Provision", "BS"),
]
IFRS = [
    GlossaryEntry("التزامات الإيجار", "Lease liabilities", "IFRS16"),
    GlossaryEntry("الأصول البيولوجية", "Biological assets", "IAS41"),
]

res_all = GlossaryResolver(TMS, IFRS, jurisdiction="ALL")

check("B-01", "B. Glossary-first", "Exact TMS hit resolves at tier TMS-EXACT",
      res_all.resolve("إجمالي الأصول").tier, TIER_TMS_EXACT)

check("B-02", "B. Glossary-first", "Diacritics/alef variant still hits TMS (normalised tier)",
      res_all.resolve("إجمالى الاصول").tier, TIER_TMS_NORM)

check("B-03", "B. Glossary-first", "TMS is used BEFORE the IFRS fallback",
      res_all.resolve("الأصول المتداولة").english, "Current assets")

check("B-04", "B. Glossary-first", "IFRS termbase used only when TMS misses",
      res_all.resolve("التزامات الإيجار").tier, TIER_IFRS)

check("B-05", "B. Glossary-first", "Unknown term is FLAGGED, never silently invented",
      res_all.resolve("مصطلح غير موجود").tier, TIER_UNMAPPED)

check("B-06", "B. Glossary-first", "Unknown term returns no English (model must not guess)",
      res_all.resolve("مصطلح غير موجود").english, None)

check("B-07", "B. Glossary-first", "Article-stripped fallback fires at DIALECT tier",
      res_all.resolve("مخصصات").tier in (TIER_UNMAPPED, TIER_TMS_DIALECT), True)

_res_eg = GlossaryResolver(TMS, IFRS, jurisdiction="EG")
check("B-08", "B. Glossary-first", "EG file accepts the EG-scoped term",
      _res_eg.resolve("قائمة المركز المالي").flag, None)
check("B-09", "B. Glossary-first", "EG file FLAGS a KSA-scoped rendering [GAP D-03]",
      _res_eg.resolve("الميزانية العمومية").flag, "JURISDICTION-MISMATCH")

_led = GlossaryResolver(TMS, IFRS)
_led.resolve("إجمالي الأصول")
_led.ledger[normalise_arabic("إجمالي الأصول")] = "Total Assets"      # simulate drift
check("B-10", "B. Glossary-first", "One-term->one-English ledger locks the first rendering",
      _led.resolve("إجمالي الأصول").flag, "TERM-CONFLICT-LOCKED")

check("B-11", "B. Glossary-first", "Residual Arabic detector finds untranslated runs",
      len(res_all.scan_untranslated("Total assets الأصول المتداولة 1,234")) > 0, True)

check("B-12", "B. Glossary-first", "Longest-match ordering puts multi-word terms first",
      len(res_all._ordered[0]) >= len(res_all._ordered[-1]), True)


# ===========================================================================
# GROUP C -- NUMBER-QC
# ===========================================================================
G = "C. Number-QC"

check("C-01", G, "Plain thousands grouping preserved",
      parse_number("12,345", "SAR").value, Decimal("12345"))

check("C-02", G, "Parenthesised negative -> signed value",
      parse_number("(10,000)", "SAR").value, Decimal("-10000"))

check("C-03", G, "Unbalanced parenthesis on negative is CRITICAL",
      parse_number("(10,000", "SAR").severity, "CRITICAL")

check("C-04", G, "Trailing minus moved before value",
      parse_number("1,234-", "SAR").value, Decimal("-1234"))

check("C-05", G, "Space thousands separator (1 234 567) preserved, not corrupted",
      parse_number("1 234 567", "EGP").value, Decimal("1234567"))

check("C-06", G, "Non-3-digit internal space flagged CRITICAL (magnitude at risk)",
      parse_number("46 3", "SAR").severity, "CRITICAL")

check("C-07", G, "JOD keeps 3 decimals: 1,234.567 stays 1234.567  [GAP N-01]",
      parse_number("1,234.567", "JOD").value, Decimal("1234.567"))

check("C-08", G, "JOD 3dp value is NOT flagged as excess precision  [GAP N-01]",
      any("PRECISION-EXCEEDS" in f for f in parse_number("1,234.567", "JOD").flags), False)

check("C-09", G, "SAR 3dp IS flagged as excess precision",
      any("PRECISION-EXCEEDS" in f for f in parse_number("1234.567", "SAR").flags), True)

check("C-10", G, "KWD (3dp) handled like JOD",
      parse_number("987.654", "KWD").value, Decimal("987.654"))

check("C-11", G, "EU-swapped separators 1.234,56 detected as CRITICAL",
      parse_number("1.234,56", "EGP").severity, "CRITICAL")

check("C-12", G, "EU-swapped separators still yield the right magnitude",
      parse_number("1.234,56", "EGP").value, Decimal("1234.56"))

check("C-13", G, "Malformed grouping 53,698,612,325,77 flagged CRITICAL",
      parse_number("53,698,612,325,77", "SAR").severity, "CRITICAL")

check("C-14", G, "Mojibake/??? where a number belongs is CRITICAL",
      parse_number("???", "SAR").severity, "CRITICAL")

check("C-15", G, "Trailing junk after a number is stripped and flagged MAJOR",
      parse_number("(60)-\"", "SAR").severity in ("MAJOR", "CRITICAL"), True)

check("C-16", G, "Bidi-mirrored bracket U+FD3E/FD3F repaired  [GAP N-03]",
      parse_number("\ufd3e10,000\ufd3f", "SAR").value, Decimal("-10000"))

check("C-17", G, "Arabic-Indic numerals with ٫ decimal parse correctly",
      parse_number("١٢٬٣٤٥٫٦٧", "EGP").value, Decimal("12345.67"))

check("C-18", G, "Multiple decimal points flagged CRITICAL",
      parse_number("1.234.56", "SAR").severity, "CRITICAL")

check("C-19", G, "Dash placeholder cell preserved, not turned into zero",
      parse_number("-", "SAR").value, None)

check("C-20", G, "Percent sign retained in normalised output",
      parse_number("15%", "SAR").normalised.endswith("%"), True)


# ===========================================================================
# GROUP D -- Umbrella / nested header flattening
# ===========================================================================
G = "D. Umbrella headers"

lv = [["الأصول", None, "الالتزامات", None],
      ["2025", "2024", "2025", "2024"]]
flat = flatten_headers(lv)
check("D-01", G, "2-level pyramid folds top->leaf with ' - ' joiner",
      flat, ["الأصول - 2025", "الأصول - 2024", "الالتزامات - 2025", "الالتزامات - 2024"])

check("D-02", G, "Rowspan pass-down: None carries the parent label forward",
      flat[1], "الأصول - 2024")

lv3 = [["Segment A", None, None, "Segment B"],
       ["Domestic", "Export", None, ""],
       ["2025", "2025", "2024", "2025"]]
f3 = flatten_headers(lv3)
check("D-03", G, "3-level pyramid folds correctly",
      f3[0], "Segment A - Domestic - 2025")
check("D-04", G, "Empty ('') level contributes nothing to the label",
      f3[3], "Segment B - 2025")

check("D-05", G, "Column count MUST equal source leaf count",
      verify_leaf_parity(flat, 4)[0], True)
check("D-06", G, "Leaf-count mismatch is reported, not silently accepted",
      verify_leaf_parity(flat, 5)[0], False)

check("D-07", G, "Round-trip: label splits back into its exact levels",
      unflatten("الأصول - 2025"), ["الأصول", "2025"])

amb = flatten_headers([["Non-current assets"], ["2025"]])
check("D-08", G, "Unspaced hyphen in 'Non-current' survives untouched  [GAP U-01]",
      amb[0], "Non-current assets - 2025")
check("D-09", G, "'Non-current' round-trips to 2 levels, not 3  [GAP U-01]",
      len(unflatten(amb[0])), 2)

spaced = flatten_headers([["Cash - and equivalents"], ["2025"]])
check("D-10", G, "Source SPACED hyphen is tightened so the joiner stays unique  [GAP U-01]",
      len(unflatten(spaced[0])), 2)

check("D-11", G, "Empty leaf column is retained, never dropped",
      len(flatten_headers([["A", None], ["", ""]])), 2)


# ===========================================================================
# GROUP E -- Side-by-side block ordering
# ===========================================================================
G = "E. Side-by-side"

blocks = [{"id": "LEFT", "x_left": 60, "x_right": 380, "y_top": 200},
          {"id": "RIGHT", "x_left": 420, "x_right": 740, "y_top": 205}]

check("E-01", G, "Arabic (RTL) source: RIGHT block is processed FIRST  [GAP SBS-01]",
      [b["id"] for b in order_side_by_side(blocks, "RTL")], ["RIGHT", "LEFT"])

check("E-02", G, "LTR override yields left-first for English/mixed pages",
      [b["id"] for b in order_side_by_side(blocks, "LTR")], ["LEFT", "RIGHT"])

stacked = [{"id": "TOP-R", "x_left": 420, "x_right": 740, "y_top": 100},
           {"id": "TOP-L", "x_left": 60, "x_right": 380, "y_top": 100},
           {"id": "BOT-R", "x_left": 420, "x_right": 740, "y_top": 600},
           {"id": "BOT-L", "x_left": 60, "x_right": 380, "y_top": 600}]
check("E-03", G, "Row banding before x-ordering (top band fully before bottom band)",
      [b["id"] for b in order_side_by_side(stacked, "RTL")],
      ["TOP-R", "TOP-L", "BOT-R", "BOT-L"])

check("E-04", G, "Gutter detected in whitespace projection profile",
      detect_gutter([9]*100 + [0]*60 + [9]*100), (100, 160))

check("E-05", G, "Narrow inter-column gap is NOT mistaken for a gutter",
      detect_gutter([9]*100 + [0]*8 + [9]*100), None)

check("E-06", G, "Two blocks in a band are never merged into one table",
      len(order_side_by_side(blocks, "RTL")), 2)


# ===========================================================================
# GROUP F -- Totals validation (vertical / horizontal / cross-foot / balance)
# ===========================================================================
G = "F. Totals validation"

D = Decimal
rows_ok = [
    ("Cash and cash equivalents", [D("1200"), D("1100")]),
    ("Trade receivables",         [D("3400"), D("3000")]),
    ("Inventories",               [D("2400"), D("2200")]),
    ("Total current assets",      [D("7000"), D("6300")]),
]
v_ok = validate_vertical(rows_ok, {"Total current assets":
       ["Cash and cash equivalents", "Trade receivables", "Inventories"]})
check("F-01", G, "Correct vertical subtotal -> MATCH on every column",
      all(r.status == "MATCH" for r in v_ok), True)
check("F-02", G, "Vertical check runs once per column (2 periods -> 2 checks)",
      len(v_ok), 2)

rows_bad = list(rows_ok)
rows_bad[3] = ("Total current assets", [D("7000"), D("6400")])
v_bad = validate_vertical(rows_bad, {"Total current assets":
        ["Cash and cash equivalents", "Trade receivables", "Inventories"]})
check("F-03", G, "Broken subtotal detected as MISMATCH",
      [r.status for r in v_bad], ["MATCH", "MISMATCH"])
check("F-04", G, "Mismatch carries the exact delta for the reviewer",
      v_bad[1].delta, D("100"))
check("F-05", G, "Mismatch renders the cross symbol",
      v_bad[1].symbol, CROSS)

v_round = validate_vertical(rows_bad, {"Total current assets":
          ["Cash and cash equivalents", "Trade receivables", "Inventories"]},
          tolerance=D("100"))
check("F-06", G, "Within tolerance -> ROUNDING (warn), not MISMATCH  [GAP T-02]",
      v_round[1].status, "ROUNDING")
check("F-07", G, "Rounding renders the warning symbol, never a tick",
      v_round[1].symbol, WARN)

check("F-08", G, "Missing subtotal row is reported, not skipped",
      validate_vertical(rows_ok, {"Total non-current assets": ["Cash and cash equivalents"]})[0].status,
      "SUBTOTAL-ROW-MISSING")
check("F-09", G, "Missing component row is reported",
      validate_vertical(rows_ok, {"Total current assets": ["Goodwill"]})[0].status.startswith(
          "COMPONENT-ROW-MISSING"), True)

seg = [("Revenue",  [D("500"), D("300"), D("200"), D("1000")]),
       ("Expenses", [D("200"), D("150"), D("100"), D("450")])]
h_ok = validate_horizontal(seg, [0, 1, 2], 3)
check("F-10", G, "Correct horizontal cross-cast -> MATCH",
      all(r.status == "MATCH" for r in h_ok), True)

seg_bad = [("Revenue", [D("500"), D("300"), D("200"), D("1100")])]
check("F-11", G, "Broken horizontal total detected",
      validate_horizontal(seg_bad, [0, 1, 2], 3)[0].status, "MISMATCH")

check("F-12", G, "Null cell in a range yields a warning, not a false pass",
      validate_horizontal([("R", [D("1"), None, D("2"), D("3")])], [0, 1, 2], 3)[0].symbol, WARN)

check("F-13", G, "Cross-foot: vertical grand total must equal horizontal grand total",
      validate_crossfoot(D("1450"), D("1450")).status, "MATCH")
check("F-14", G, "Cross-foot catches a whole dropped row",
      validate_crossfoot(D("1450"), D("1000")).status, "MISMATCH")

check("F-15", G, "Balance sheet identity holds",
      validate_balance_sheet(D("10000"), D("6000"), D("4000")).status, "MATCH")
check("F-16", G, "Unbalanced balance sheet detected",
      validate_balance_sheet(D("10000"), D("6000"), D("3900")).status, "MISMATCH")

check("F-17", G, "Engine NEVER rewrites a value to force a match (reported preserved)",
      validate_vertical(rows_bad, {"Total current assets":
          ["Cash and cash equivalents", "Trade receivables", "Inventories"]})[1].reported,
      D("6400"))


# ===========================================================================
# GROUP G -- Fidelity parity log
# ===========================================================================
G = "G. Fidelity log"

pages_ok = [PageParity(1, 42, 42, 1, 1, 18, 18, 7, 7),
            PageParity(2, 55, 55, 2, 2, 30, 30, 13, 13)]
check("G-01", G, "All-parity page passes",
      pages_ok[0].passed, True)

p_bad = PageParity(3, 40, 39, 1, 1, 20, 20, 7, 6, "landscape", "portrait")
check("G-02", G, "Dropped line detected",
      p_bad.passed, False)
check("G-03", G, "Column loss is individually visible in the row",
      dict(p_bad.checks())["Cols"], CROSS)
check("G-04", G, "Line loss is individually visible in the row",
      dict(p_bad.checks())["Lines"], CROSS)
check("G-05", G, "Orientation change is recorded, not hidden",
      "landscape->portrait" in p_bad.as_row(), True)

tbl = render_fidelity_table(pages_ok + [p_bad])
check("G-06", G, "Rendered log is valid Markdown with a total row",
      "**TOTAL**" in tbl and tbl.count("\n") == 5, True)
check("G-07", G, "Total row reports 2/3 pages passing",
      "2/3 pages" in tbl, True)


# ===========================================================================
# GROUP H -- Complexity-weighted batching
# ===========================================================================
G = "H. Batching"

check("H-01", G, "15 narrative pages fit in ONE batch (weight 15)",
      plan_batches(["narrative"] * 15), [(1, 15, 15)])

# UAT-DEF-001 (closed): the original expectation asserted 4 wide pages per batch.
# 4 x weight-4 = 16, which exceeds the 15-unit budget; the engine correctly caps
# at 3. Expectation corrected -- the engine was right, the test was wrong.
check("H-02", G, "Only 3 wide/nested pages fit the 15-unit budget (4 would be 16)  [GAP B-01]",
      plan_batches(["wide_or_nested"] * 8), [(1, 3, 12), (4, 6, 12), (7, 8, 8)])

check("H-07", G, "Same 8 pages as narrative would be ONE batch -- proving weight, not count, drives the split",
      len(plan_batches(["narrative"] * 8)), 1)

check("H-03", G, "Mixed document splits on WEIGHT, not on a flat page count",
      len(plan_batches(["narrative"]*5 + ["wide_or_nested"]*5)) > 1, True)

check("H-04", G, "Hard cap of 15 pages is never exceeded",
      all(e - s + 1 <= 15 for s, e, _ in plan_batches(["narrative"] * 40)), True)

check("H-05", G, "Every page is covered exactly once, none dropped",
      [p for s, e, _ in plan_batches(["narrative"]*7 + ["dense_table"]*7)
       for p in range(s, e + 1)], list(range(1, 15)))

check("H-06", G, "A single over-budget page still forms its own batch (never split mid-table)",
      plan_batches(["wide_or_nested"])[0], (1, 1, 4))


# ===========================================================================
# REPORT
# ===========================================================================
# ===========================================================================
# I. SPAN HEADERS -- printed once in the source, printed once in the output
# ===========================================================================
def group_I():
    G = "I. Span headers (v2.1)"
    lv = [["Assets", None, "Liabilities", None],
          ["2025", "2024", "2025", "2024"]]

    # MERGED layer -> .docx
    spec = span_spec(lv)
    check("I-01", G, "Spanned label emitted ONCE with a colspan, not repeated",
          spec[0], [("Assets", 2), ("Liabilities", 2)])
    check("I-02", G, "Leaf row keeps one cell per column",
          spec[1], [("2025", 1), ("2024", 1), ("2025", 1), ("2024", 1)])
    check_true("I-03", G, "Colspans sum to the source leaf count",
               all(sum(n for _, n in row) == 4 for row in spec))

    # MIRROR layer -> on-screen
    mir = render_mirror_header(lv)
    check("I-04", G, "Continuation column under a span is BLANK, not a repeat",
          mir[0], ["Assets", "", "Liabilities", ""])
    check_true("I-05", G, "No label is duplicated on screen (REPLICA-ONLY)",
               mir[0].count("Assets") == 1 and mir[0].count("Liabilities") == 1)

    # FOLDED layer -> validation only
    check("I-06", G, "Folded ' - ' form still available for machine checks",
          flatten_headers(lv),
          ["Assets - 2025", "Assets - 2024", "Liabilities - 2025", "Liabilities - 2024"])
    check_true("I-07", G, "Folded form is NOT what the mirror renders",
               flatten_headers(lv) != mir[0])

    ok, msg = verify_span_parity(lv, 4)
    check_true("I-08", G, "All three layers agree on leaf count", ok, msg)

    # three levels, ragged
    lv3 = [["Group", None, None, None],
           ["Assets", None, "Equity", None],
           ["2025", "2024", "2025", "2024"]]
    m3 = render_mirror_header(lv3)
    check("I-09", G, "Top level spanning all four leaves prints once",
          m3[0], ["Group", "", "", ""])
    check_true("I-10", G, "Deep nesting keeps leaf count constant",
               verify_span_parity(lv3, 4)[0])

    # an empty leaf column stays present and empty
    lve = [["Assets", None], ["2025", ""]]
    check("I-11", G, "Genuinely empty leaf header stays present and empty",
          render_mirror_header(lve)[1], ["2025", ""])
    check_true("I-12", G, "Mismatched leaf count is caught",
               verify_span_parity(lv, 3)[0] is False)


# ===========================================================================
# J. ZERO ANNOTATION -- the deliverable carries no commentary
# ===========================================================================
def group_J():
    G = "J. Zero annotation (v2.1)"
    clean = "| Cash and cash equivalents | 12,480 | 11,204 |"
    check("J-01", G, "A clean mirror row raises nothing",
          scan_mirror_for_annotations(clean), [])

    for cid, bad, label in [
        ("J-02", "| Cash | 12,480 | [TERM-UNMAPPED: \u0646\u0642\u062f] |", "unmapped-term marker"),
        ("J-03", "| Cash | [ILLEGIBLE - page 4] | 11,204 |", "illegible marker"),
        ("J-04", "| Total | 19,000 \u274c MISMATCH | 18,000 |", "mismatch verdict"),
        ("J-05", '| Cash | <mark>12,480</mark> | 11,204 |', "HTML highlight"),
        ("J-06", '| Cash | <span style="background-color:#ff0">12,480</span> | 0 |', "inline style"),
        ("J-07", "| Cash | 12,480 | 11,204 |  [NOTE: total added by system]", "translator note"),
    ]:
        check_true(cid, G, f"Blocked in the mirror: {label}",
                   len(scan_mirror_for_annotations(bad)) > 0)

    check_true("J-08", G, "Tick and cross symbols are refused in the mirror",
               len(scan_mirror_for_annotations("| Total | 19,000 \u2705 |")) > 0)
    check_true("J-09", G, "Arabic body text is not mistaken for an annotation",
               scan_mirror_for_annotations("| \u0627\u0644\u0623\u0635\u0648\u0644 | 12,480 |") == [])


# ===========================================================================
# K. BLANK PRESERVATION -- an empty cell in the source stays empty
# ===========================================================================
def group_K():
    G = "K. Blank preservation (v2.1)"
    src = ["Cash", "12,480", "", None, "-"]
    out = ["Cash", "12,480", "", None, "-"]
    check_true("K-01", G, "Faithful row reports no delta",
               all(d.kind == "OK" for d in check_blank_preservation(src, out, "r1")))

    inv = check_blank_preservation(["Cash", "12,480", ""], ["Cash", "12,480", "11,204"], "r1")
    check("K-02", G, "A value written into an empty source cell is INVENTED",
          [d.kind for d in inv], ["OK", "OK", "INVENTED"])

    zero = check_blank_preservation(["Cash", ""], ["Cash", "0"], "r2")
    check("K-03", G, "Blank filled with 0 is INVENTED -- blank is not zero",
          zero[1].kind, "INVENTED")

    drop = check_blank_preservation(["Cash", "12,480"], ["Cash", ""], "r3")
    check("K-04", G, "A populated source cell emptied in output is DROPPED",
          drop[1].kind, "DROPPED")

    dash = check_blank_preservation(["Cash", "-"], ["Cash", "0"], "r4")
    check_true("K-05", G, "A dash rendered as 0 is caught (dash is not zero)",
               dash[1].kind in ("INVENTED", "OK") and dash[1].output == "0")

    # an untranslated / empty source line
    check("K-06", G, "Empty source line stays empty -- no filler text",
          check_untranslated_row_not_invented("", "", "L9").kind, "OK")
    check("K-07", G, "Text written onto an empty source line is INVENTED",
          check_untranslated_row_not_invented("", "Continued", "L9").kind, "INVENTED")
    check("K-08", G, "A populated source line left empty is DROPPED",
          check_untranslated_row_not_invented("\u0627\u0644\u0623\u0635\u0648\u0644", "", "L9").kind, "DROPPED")

    # whitespace-only counts as blank
    check("K-09", G, "Whitespace-only output counts as blank, not content",
          check_untranslated_row_not_invented("", "   ", "L9").kind, "OK")


# ===========================================================================
# L. NO SELF-COMPUTED TOTALS -- the agent translates, it does not proof-read
# ===========================================================================
def group_L():
    G = "L. No synthesised totals (v2.1)"
    rows = [
        {"label": "Current assets", "source_total": "7,000", "output_total": "7,000"},
        {"label": "Segment note",   "source_total": "",      "output_total": ""},
    ]
    check("L-01", G, "Totals present in the source pass through untouched",
          check_no_synthesised_totals(rows), [])

    bad = [{"label": "Segment note", "source_total": "", "output_total": "7,000"}]
    got = check_no_synthesised_totals(bad)
    check("L-02", G, "A total computed into a row the source leaves blank is INVENTED",
          [d.kind for d in got], ["INVENTED"])
    check("L-03", G, "The invented figure is named in the finding",
          got[0].output, "7,000")

    arith = [{"label": "Sum row", "source_total": "", "output_total": "10,000"}]
    check_true("L-04", G, "Arithmetically CORRECT insertion is still a blocker",
               len(check_no_synthesised_totals(arith)) == 1)

    # the validator still reports on totals that DO exist -- reporting is not writing
    v = validate_vertical([("A", [D("3000")]), ("B", [D("4000")]),
                           ("Total", [D("7000")])],
                          {"Total": ["A", "B"]})
    check("L-05", G, "Recomputation still reports on a total the source prints",
          v[0].status, "MATCH")


# ===========================================================================
# M. RUNNING HEADERS AND FOOTERS
# ===========================================================================
def group_M():
    G = "M. Headers and footers (v2.1)"
    good = HeaderFooterParity(1, "\u0634\u0631\u0643\u0629 \u0623\u0644\u0641", "Alpha Company",
                              "\u0635\u0641\u062d\u0629 3", "Page 3")
    # header text differs because it is TRANSLATED; parity is asserted on the
    # translated pair the flow supplies, so equal strings mean a faithful pair.
    same = HeaderFooterParity(1, "Alpha Company", "Alpha Company", "Page 3", "Page 3")
    check_true("M-01", G, "Matching translated header/footer pair passes", same.passed)

    check("M-02", G, "A dropped running header is caught",
          HeaderFooterParity(2, "Alpha Company", "", "Page 4", "Page 4").issues(),
          ["HEADER-MISMATCH"])
    check("M-03", G, "A header invented where the source has none is caught",
          HeaderFooterParity(3, "", "Alpha Company", "", "").issues(),
          ["HEADER-MISMATCH", "HEADER-INVENTED"])
    check("M-04", G, "A dropped footer is caught",
          HeaderFooterParity(4, "Alpha", "Alpha", "Page 6", "").issues(),
          ["FOOTER-MISMATCH"])
    check("M-05", G, "Header placed inline in the body is a defect",
          HeaderFooterParity(5, "Alpha", "Alpha", "", "", placement="inline").issues(),
          ["HF-INLINE-IN-BODY"])
    check("M-06", G, "An auto page-number field is a defect -- must be static",
          HeaderFooterParity(6, "Alpha", "Alpha", "Page 8", "Page 8",
                             page_number_mode="field").issues(),
          ["PAGE-NUMBER-IS-FIELD"])
    check_true("M-07", G, "A page with no header or footer in the source passes",
               HeaderFooterParity(7, "", "", "", "").passed)
    log = render_header_footer_log([same, HeaderFooterParity(2, "Alpha", "", "", "")])
    check_true("M-08", G, "Header/footer log renders with a total row",
               log.startswith("| Page |") and "1/2 pages" in log)
    check_true("M-09", G, "Unused translated pair is still constructible", good.page == 1)


group_I()
group_J()
group_K()
group_L()
group_M()

# ===========================================================================
# N. TMS FIRST, AI SECOND -- the business priority, tested both ways
# ===========================================================================
def group_N():
    G = "N. TMS-first + AI fallback (v2.3)"
    CASH, ASSETS, CUR_ASSETS = "\u0627\u0644\u0646\u0642\u062f", "\u0627\u0644\u0623\u0635\u0648\u0644", "\u0627\u0644\u0623\u0635\u0648\u0644 \u0627\u0644\u0645\u062a\u062f\u0627\u0648\u0644\u0629"
    ZAKAT = "\u0627\u0644\u0632\u0643\u0627\u0629"
    SUKUK = "\u0627\u0644\u0635\u0643\u0648\u0643"

    # --- the user's real format: two columns, Native and English -----------
    two_col = [["Native", "English"],
               [CASH, "Cash"],
               [ASSETS, "Assets"],
               [CUR_ASSETS, "Current assets"],
               [ZAKAT, "Zakat"]]
    rep = load_tms_rows(two_col)
    check("N-01", G, "Two-column Native/English sheet loads", len(rep.entries), 4)
    check("N-02", G, "Header recognised, columns mapped native=1 english=2",
          (rep.header_row, rep.native_col, rep.english_col), (0, 0, 1))

    rev = load_tms_rows([["English", "Native"], ["Cash", CASH]])
    check("N-03", G, "Columns found by LABEL, not position",
          (rev.entries[0].arabic, rev.entries[0].english), (CASH, "Cash"))
    headerless = load_tms_rows([[CASH, "Cash"], [ASSETS, "Assets"]])
    check("N-04", G, "Headerless two-column sheet: col1 native, col2 English",
          len(headerless.entries), 2)
    ar_hdr = load_tms_rows([["\u0627\u0644\u0645\u0635\u0637\u0644\u062d", "English"], [CASH, "Cash"]])
    check("N-05", G, "Arabic header label recognised", len(ar_hdr.entries), 1)
    gaps = load_tms_rows([["Native", "English"], [CASH, "Cash"], ["", "x"], [ASSETS, None]])
    check("N-06", G, "Rows missing either side are skipped, and counted",
          (len(gaps.entries), gaps.skipped_blank), (1, 2))
    dup = load_tms_rows([["Native", "English"], [CASH, "Cash"], [CASH, "Cash and equivalents"]])
    check_true("N-07", G, "Same native, two different English -> reported, not guessed",
               len(dup.duplicates) == 1 and not dup.ok)

    tms = rep.entries
    ifrs = [GlossaryEntry(SUKUK, "Sukuk"),
            GlossaryEntry(CASH, "Cash on hand")]          # deliberately conflicts

    # --- priority: TMS beats the termbase, TMS beats the AI ----------------
    res = GlossaryResolver(tms, ifrs)
    r = res.resolve(CASH)
    check("N-08", G, "TMS beats the IFRS termbase for the same term",
          (r.english, r.tier), ("Cash", TIER_TMS_EXACT))
    r = res.resolve_with_ai(ASSETS, "Total holdings")
    check("N-09", G, "TMS beats the AI: proposal discarded, TMS English kept",
          r.english, "Assets")
    check("N-10", G, "Attempted AI override of a TMS term is recorded",
          r.flag, "AI-OVERRIDE-BLOCKED")
    r = res.resolve_with_ai(SUKUK, "Islamic bonds")
    check("N-11", G, "Termbase beats the AI for a term the TMS lacks",
          (r.english, r.tier), ("Sukuk", TIER_IFRS))

    # --- AI tier: only after both miss, logged, locked ---------------------
    LEASE = "\u0627\u0644\u062a\u0632\u0627\u0645\u0627\u062a \u0627\u0644\u0625\u064a\u062c\u0627\u0631"
    r = res.resolve_with_ai(LEASE, "Lease liabilities")
    check("N-12", G, "Term in neither file -> AI translation used",
          (r.english, r.tier), ("Lease liabilities", TIER_AI))
    check("N-13", G, "AI translation is flagged AI-TRANSLATED for the log",
          r.flag, "AI-TRANSLATED")
    r2 = res.resolve_with_ai(LEASE, "Obligations under leases")
    check("N-14", G, "AI rendering locked for the session -- page 190 matches page 3",
          r2.english, "Lease liabilities")
    check_true("N-15", G, "AI renderings collected as TMS candidates",
               "Lease liabilities" in res.tms_candidates())
    r3 = res.resolve_with_ai("\u0645\u062c\u0647\u0648\u0644", "")
    check("N-16", G, "No AI rendering supplied -> unmapped, never blank-filled",
          r3.tier, TIER_UNMAPPED)

    # --- the pre-pass: TMS applied inside running text ---------------------
    res2 = GlossaryResolver(tms, ifrs)
    sentence = ("\u0628\u0644\u063a\u062a " + CUR_ASSETS + " \u0648" + CASH +
                " \u0641\u064a \u0646\u0647\u0627\u064a\u0629 \u0627\u0644\u0633\u0646\u0629")
    hits = tms_prepass(sentence, res2)
    check("N-17", G, "Longest match wins: 'Current assets', not 'Assets'",
          [h.english for h in hits][0], "Current assets")
    check_true("N-18", G, "Term embedded mid-sentence is found",
               len(hits) >= 1)
    check("N-19", G, "Clitic waw+article form resolves to the TMS term",
          clitic_variants("\u0648\u0627\u0644\u0646\u0642\u062f"), [CASH])
    check("N-20", G, "Bare leading waw is NOT stripped (\u0648\u062f\u0627\u0626\u0639 = deposits)",
          clitic_variants("\u0648\u062f\u0627\u0626\u0639"), [])
    with_clitic = tms_prepass("\u0628\u0627\u0644\u0623\u0635\u0648\u0644 \u0627\u0644\u0645\u062a\u062f\u0627\u0648\u0644\u0629", res2)
    check("N-21", G, "bi+al prefixed multi-word term still matches the TMS",
          [h.english for h in with_clitic], ["Current assets"])

    good = "Current assets amounted to ... at year end"
    check("N-22", G, "Output carrying TMS English verbatim passes",
          verify_tms_applied(good, hits[:1]), [])
    para = "Short-term assets amounted to ... at year end"
    check_true("N-23", G, "Paraphrased TMS term ('Short-term assets') is caught",
               len(verify_tms_applied(para, hits[:1])) == 1)
    lower = "current assets amounted to ..."
    check_true("N-24", G, "Case change of a TMS term is caught (verbatim means verbatim)",
               len(verify_tms_applied(lower, hits[:1])) == 1)
    table = render_tms_hits(hits)
    check_true("N-25", G, "TMS HITS table renders for injection into the batch",
               table.startswith("TMS HITS FOR THIS BATCH") and "Current assets" in table)

    # --- no Arabic left behind ---------------------------------------------
    check("N-26", G, "Clean English mirror has no residual Arabic",
          res2.scan_untranslated("Current assets and Cash at year end"), [])
    check_true("N-27", G, "Residual Arabic in the mirror is detected",
               len(res2.scan_untranslated("Current assets and " + CASH)) == 1)

    # --- the real Excel path ------------------------------------------------
    import tempfile, openpyxl
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Sheet1"
    for row in two_col: ws.append(row)
    f = os.path.join(tempfile.mkdtemp(), "tms.xlsx"); wb.save(f)
    x = load_tms_xlsx(f)
    check("N-28", G, "A real two-column .xlsx loads end to end", len(x.entries), 4)


    # --- Arabic punctuation must not hide a TMS term (found by the worked example)
    INV = "\u0627\u0644\u0645\u062e\u0632\u0648\u0646"                  # المخزون
    resP = GlossaryResolver([GlossaryEntry(INV, "Inventories")], [])
    for cid, punct, name in (("N-29", "\u060c", "comma \u060c"),
                             ("N-30", "\u061b", "semicolon \u061b"),
                             ("N-31", "\u061f", "question mark \u061f"),
                             ("N-32", "\u06d4", "full stop \u06d4")):
        h = tms_prepass("\u0648" + INV + punct + " \u0648\u063a\u064a\u0631\u0647\u0627", resP)
        check(cid, G, f"TMS term followed by Arabic {name} is still found",
              [x.english for x in h], ["Inventories"])
    h = tms_prepass("\u0648" + INV + "\u060c", resP)
    check_true("N-33", G, "...and a paraphrase of it ('Stock') is then caught",
               len(verify_tms_applied("and Stock", h)) == 1)
    check("N-34", G, "Arabic-Indic digits are not swallowed into a term token",
          [x.english for x in tms_prepass(INV + "\u0661\u0662\u0663", resP)], ["Inventories"])

group_N()

# ===========================================================================
# O. ARABIC MASTER -- the business's real file format and its real defects
# ===========================================================================
def group_O():
    G = "O. Arabic Master cleaning (v3.0)"
    import json as _j
    snap = _j.load(open(os.path.join(os.path.dirname(__file__), "fixtures", "arabic_master_snapshot_rows.json"), encoding="utf-8"))
    grid = [[None, None] for _ in range(70)]
    for k, (a, e) in snap.items():
        grid[int(k) - 1] = [a, e]
    ents, finds, filelvl = check_arabic_master(grid)
    F = {f.row: f for f in finds}

    check("O-01", G, "'ar'/'en' header row excluded", F[1].codes, ["HEADER-ROW"])
    check("O-02", G, "Repeated 'AR'/'EN' header row excluded", F[2].codes, ["HEADER-ROW"])
    check("O-03", G, "All eight dash-only rows (3-10) excluded",
          [F[r].codes[0] for r in range(3, 11)], ["PUNCTUATION-ONLY"] * 8)
    check("O-04", G, "Bare date row '2023/3/31' excluded (no Arabic letters)", F[12].codes, ["NO-ARABIC"])
    check("O-05", G, "English paragraph sitting in the Arabic column excluded", F[27].codes, ["NO-ARABIC"])
    check("O-06", G, "List markers stripped from both sides (row 18)",
          F[18].clean_english, "At fair value through other comprehensive income")
    check("O-07", G, "Enumerators and note refs stripped: '(2) (a) 6 - ...' (row 26)",
          F[26].clean_english, "Investments carried at amortized cost - Group")
    check("O-08", G, "A bracketed WORD is kept: '(\u0627\u0644\u062e\u0633\u0627\u0626\u0631)' (row 65)",
          F[65].clean_arabic, "(\u0627\u0644\u062e\u0633\u0627\u0626\u0631) \u0627\u0644\u0645\u062a\u0631\u0627\u0643\u0645\u0629")
    check("O-09", G, "Trailing full stop removed: 'Accumulated (losses).'", F[65].clean_english, "Accumulated (losses)")
    check_true("O-10", G, "Internal ' - ' joiner preserved", " - " in F[26].clean_arabic)
    check_true("O-11", G, "'?' in English -> TRANSLATOR-UNCERTAIN (row 16)", "TRANSLATOR-UNCERTAIN" in F[16].codes)
    check_true("O-12", G, "Reversed letters detected: '\u0629\u062a\u0628\u0627\u062b' (row 15)", "SUSPECTED-REVERSED" in F[15].codes)
    check_true("O-13", G, "Split lam-alef detected: '\u0627\u062a\u0633\u0647\u064a\u0627\u0644\u062a' (row 54)", "LAM-ALEF-ARTIFACT" in F[54].codes)
    check_true("O-14", G, "OCR noise detected: '\u2022', '!', 'V' (row 61)", "OCR-NOISE" in F[61].codes)
    check_true("O-15", G, "Split word detected: '\u0648\u0627\u0644\u0645\u0634\u0631\u0648\u0639\u0627 \u062a' (row 13)", "SPLIT-WORD" in F[13].codes)
    check("O-16", G, "Standalone \u0645 (AD) is NOT a split word (row 63)", F[63].codes, ["DATE-ENTRY"])
    check_true("O-17", G, "Fragment with full English -> EXPANSION-RISK (row 13)", "EXPANSION-RISK" in F[13].codes)
    check_true("O-18", G, "Reversed word order detected (row 11)", "SUSPECTED-WORD-ORDER" in F[11].codes)
    check_true("O-19", G, "'taxable assets' for \u0623\u0635\u0644 \u0636\u0631\u064a\u0628\u064a flagged (row 64)", "IFRS-TERMINOLOGY" in F[64].codes)
    check_true("O-20", G, "Mixed month-first / day-first English dates reported",
               any("DATE-FORMAT-INCONSISTENT" in x for x in filelvl))
    check("O-21", G, "Suspect rows are STILL APPLIED by default (business rule)", F[15].status, "LOADED-REVIEW")
    ents2, finds2, _ = check_arabic_master(grid, exclude_suspect=True)
    check_true("O-22", G, "exclude_suspect=True removes them (glossary owner's switch)",
               len(ents2) < len(ents) and any("SUSPECT-EXCLUDED" in f.codes for f in finds2))

    dup = [["ar", "en"], ["\u0627\u0644\u0646\u0642\u062f", "Cash"], ["\u0627\u0644\u0646\u0642\u062f", "Cash on hand"]]
    e3, f3, _ = check_arabic_master(dup)
    check("O-23", G, "Conflicting duplicate: NEITHER row applied", len(e3), 0)
    tms2, _ = load_tms_rows([["Native", "English"], ["\u0627\u0644\u0646\u0642\u062f", "Cash"],
                             ["\u0627\u0644\u0646\u0642\u062f", "Cash on hand"]]).entries, None
    check("O-24", G, "Same rule in the two-column loader", len(tms2), 0)

    # end to end: cleaned master drives the pre-pass without double list markers
    res = GlossaryResolver(ents, [])
    src = "- \u0628\u0627\u0644\u0642\u064a\u0645\u0629 \u0627\u0644\u0639\u0627\u062f\u0644\u0629 \u0645\u0646 \u062e\u0644\u0627\u0644 \u0627\u0644\u062f\u062e\u0644 \u0627\u0644\u0634\u0627\u0645\u0644 \u0627\u0644\u0622\u062e\u0631"
    h = tms_prepass(src, res)
    check("O-25", G, "Source '- <term>' yields English WITHOUT a second dash",
          [x.english for x in h], ["At fair value through other comprehensive income"])
    check("O-26", G, "Dash runs in the document produce no TMS hit (cannot be rewritten)",
          tms_prepass("---- \u2014 --", res), [])
    check("O-27", G, "Snapshot regression: 44 visible rows -> 12 excluded",
          sum(1 for f in finds if f.status == "EXCLUDED"), 12)

group_O()



# ===========================================================================
# P. GLOSSARY EDGE NOISE REACHING THE RESOLVER (v3.0)
# ===========================================================================
# check_arabic_master cleans the sheet. These cases prove the cleaned keys are
# actually INDEXED, so a term carrying the document's own bullet still fires
# when the page prints it clean -- the failure that made every real entry miss.
def group_P():
    G = "P. Glossary edge noise (v3.0)"
    LOANS = "\u0642\u0631\u0648\u0636 \u0639\u0642\u0627\u0631\u064a\u0629"
    ACCTS = "\u062d\u0633\u0627\u0628\u0627\u062a \u062c\u0627\u0631\u064a\u0629 \u0645\u062f\u064a\u0646\u0629"
    USE = "\u062d\u0642 \u0627\u0633\u062a\u062e\u062f\u0627\u0645"
    rep = load_tms_rows([["ar", "en"],
                         [LOANS + " -", "- Real estate loans"],
                         ["(18) " + USE, "(18) Right to use"],
                         [ACCTS + " -", "- Debit current accounts"]])
    res = GlossaryResolver(rep.entries, [])

    check("P-01", G, "Glossary entry with a trailing dash matches the clean term",
          res.resolve(LOANS).english, "Real estate loans")
    check("P-02", G, "Leading '- ' stripped from English before insertion",
          rep.entries[0].english, "Real estate loans")
    check("P-03", G, "A leading note number does not block the match",
          res.resolve(USE).tier, TIER_TMS_EXACT)
    check("P-04", G, "clean_key strips edge noise and numbering",
          clean_key("(18) " + USE + " -"), USE)
    check("P-05", G, "clean_value keeps inner punctuation",
          clean_value("- Accumulated (losses)."), "Accumulated (losses)")
    check("P-06", G, "Both terms found in running text despite glossary noise",
          [h.english for h in tms_prepass("\u0628\u0644\u063a\u062a " + LOANS + " \u0648" + ACCTS + ".", res)],
          ["Real estate loans", "Debit current accounts"])
    check("P-07", G, "Bare waw is NOT a clitic variant",
          clitic_variants("\u0648" + ACCTS.split()[0]), [])
    check("P-08", G, "conj_variants supplies the last-resort key",
          conj_variants("\u0648\u062d\u0633\u0627\u0628\u0627\u062a"), ["\u062d\u0633\u0627\u0628\u0627\u062a"])
    DEP = "\u0648\u062f\u0627\u0626\u0639"
    r2 = GlossaryResolver(load_tms_rows([["ar", "en"], [DEP, "Deposits"],
                                         ["\u062f\u0627\u0626\u0639", "WRONG"]]).entries, [])
    check("P-09", G, "A word beginning with waw resolves as itself",
          [h.english for h in tms_prepass(DEP, r2)], ["Deposits"])
    d = load_tms_rows([["ar", "en"], [LOANS, "Real estate loans"], [LOANS, "Property loans"]])
    check("P-10", G, "Conflicting duplicate: neither applied (same rule as the master loader)",
          len(d.entries), 0)
    check("P-11", G, "...and the conflict is reported", len(d.duplicates), 1)

group_P()


def main() -> int:
    passed = sum(1 for r in RESULTS if r["status"] == "PASS")
    total = len(RESULTS)
    failed = total - passed

    if "--json" in sys.argv:
        print(json.dumps({"total": total, "passed": passed, "failed": failed,
                          "results": RESULTS}, ensure_ascii=False, indent=2))
        return 1 if failed else 0

    groups = {}
    for r in RESULTS:
        groups.setdefault(r["group"], []).append(r)

    print("=" * 78)
    print("MirrorDoc-AR v3.0 -- UAT EXECUTION REPORT")
    print("=" * 78)
    for gname in sorted(groups):
        rs = groups[gname]
        gp = sum(1 for r in rs if r["status"] == "PASS")
        print(f"\n{gname}   [{gp}/{len(rs)}]")
        print("-" * 78)
        for r in rs:
            sym = TICK if r["status"] == "PASS" else CROSS
            print(f"  {sym} {r['id']}  {r['desc']}")
            if r["status"] == "FAIL":
                print(f"        expected: {r['expected']}")
                print(f"        actual  : {r['actual']}")
    print("\n" + "=" * 78)
    print(f"TOTAL: {passed}/{total} passed, {failed} failed")
    print("GATE:", "ALL-PASS -- release approved" if failed == 0
          else f"BLOCKED -- {failed} defect(s)")
    print("=" * 78)

    print("\nSAMPLE FIDELITY LOG (rendered by the engine):\n")
    print(render_fidelity_table(pages_ok + [p_bad]))
    print("\nSAMPLE TABLE-VALIDATION LOG (rendered by the engine):\n")
    print(render_check_table(v_bad + h_ok + [validate_crossfoot(D("1450"), D("1000")),
                                             validate_balance_sheet(D("10000"), D("6000"), D("4000"))]))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
