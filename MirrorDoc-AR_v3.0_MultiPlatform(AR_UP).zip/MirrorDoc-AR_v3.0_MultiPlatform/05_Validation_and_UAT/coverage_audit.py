# -*- coding: utf-8 -*-
"""
MirrorDoc-AR v2.3 -- instruction coverage audit.

Splitting a 25,000-character instruction into an 8,000-character inline core
plus five knowledge modules is a lossy operation unless something checks it.
This does.

Every rule atom that existed in v2.1 is listed below with the place it must now
live. The audit fails if an atom is missing everywhere (content lost), and warns
if an atom that must be INLINE has drifted into the knowledge base only.

Why the INLINE/KB distinction matters: knowledge retrieval is probabilistic. A
rule whose absence causes SILENT corruption must be inline, because a missed
retrieval would not announce itself. A rule that is reference DATA can live in
the KB provided the inline core carries a fail-closed guard pointing at it.

Run:  python3 coverage_audit.py [--json]
"""
from __future__ import annotations

import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "01_Copilot_Studio_UNDER_8000"))
# The deployable .docx lives in 01_; the editable plain-text source lives in 06_.
# The character budget is always measured on the plain text, because that is what
# gets pasted into the instruction field.
INLINE_TXT = os.path.abspath(os.path.join(HERE, "..", "06_Editable_Sources",
                                          "copilot_under8000.txt"))
INLINE = os.path.join(ROOT, "01_Agent_Instructions",
                      "COPILOT_Instructions_UNDER_8000.docx")
KB_DIR = os.path.join(ROOT, "02_Knowledge_Resources")

INLINE_LIMIT = 8000

# (atom id, description, required location, list of substrings that evidence it)
# location: "INLINE" = must appear in the instruction field
#           "KB"     = may live in a module, guarded by a fail-closed pointer
#           "BOTH"   = summary inline, detail in the KB
ATOMS = [
    ("CORE-01", "Core equation: mirror == PDF == docx", "INLINE", ["CORE EQUATION"]),
    ("CORE-02", "Never summarise/add/drop/reorder/improve", "INLINE", ["never summarise, add, drop, reorder"]),
    ("AUTH-01", "REPLICA-ONLY is authority rule 1", "INLINE", ["REPLICA-ONLY"]),
    ("AUTH-02", "NO-ANNOTATION is authority rule 2", "INLINE", ["NO-ANNOTATION"]),
    ("AUTH-03", "NO-HALLUCINATION", "INLINE", ["NO-HALLUCINATION"]),
    ("AUTH-04", "GLOSSARY-FIRST outranks model judgement", "INLINE", ["GLOSSARY-FIRST"]),
    ("AUTH-05", "Structure fidelity", "INLINE", ["STRUCTURE FIDELITY"]),
    ("AUTH-06", "Never silently deviate", "INLINE", ["silently deviate"]),

    ("ART-01", "Two artifacts named and separated", "INLINE", ["ARTIFACT A", "ARTIFACT B"]),
    ("ART-02", "No number the source does not print", "INLINE", ["a number the source does not print"]),
    ("ART-03", "No text on an empty line", "INLINE", ["text on a line or in a cell the source leaves empty"]),
    ("ART-04", "No highlight/tick/cross/severity in mirror", "INLINE", ["highlight, colour, tick, cross"]),
    ("ART-05", "No bracketed marker or translator note", "INLINE", ["bracketed marker"]),
    ("ART-06", "No invented 'continued'", "BOTH", ["continued"]),
    ("ART-07", "No repeated span label", "INLINE", ["repeated across its continuation columns"]),
    ("ART-08", "Translator+reporter, never editor", "INLINE", ["never an\neditor", "never an editor"]),
    ("ART-09", "Source error reproduced and reported", "INLINE", ["correcting it destroys the evidence"]),

    ("KB-01", "KB modules enumerated by filename", "INLINE", ["MDR-01", "MDR-02", "MDR-03", "MDR-04", "MDR-05"]),
    ("KB-02", "Fail-closed on unretrievable KB", "INLINE", ["FAIL-CLOSED"]),
    ("KB-03", "Never proceed from memory", "INLINE", ["never proceed from memory"]),

    ("SESS-01", "Inventory contract before converting", "INLINE", ["INVENTORY CONTRACT"]),
    ("SESS-02", "Jurisdiction + currency + precision declared", "INLINE", ["jurisdiction and reporting currency"]),
    ("SESS-03", "Per-page orientation/class/manifest", "INLINE", ["orientation, page class"]),
    ("SESS-04", "Upload once; session file handle", "INLINE", ["gblSourceDocRef"]),
    ("SESS-05", "Never re-OCR or re-output earlier pages", "BOTH", ["re-output earlier pages"]),

    ("BAT-01", "Page weights 1/2/3/4", "BOTH", ["narrative 1, simple table 2", "narrative | 1"]),
    ("BAT-02", "15-unit budget", "INLINE", ["15 weight units"]),
    ("BAT-03", "15-page hard cap", "INLINE", ["HARD CAP 15 pages", "HARD CAP = 15 pages"]),
    ("BAT-04", "Never split a table across replies", "INLINE", ["NEVER split a table"]),
    ("BAT-05", "Over-budget page forms its own batch", "BOTH", ["own batch"]),
    ("BAT-06", "Mid-reply abort at last complete table", "INLINE", ["last COMPLETE table"]),
    ("BAT-07", "Exact non-final footer string", "INLINE", ["BATCH DONE: pages X-Y of N delivered"]),
    ("BAT-08", "Exact final footer string", "INLINE", ["ALL PAGES 1-N DELIVERED"]),

    ("PRE-01", "Pre-processing belongs to the flow", "BOTH", ["300", "DPI"]),
    ("PRE-02", "Input is structured OCR, not an image", "INLINE", ["structured OCR"]),
    ("PRE-03", "Missing structure is logged, not guessed", "BOTH", ["without cell structure"]),

    ("BLANK-01", "Blank is not zero and not a dash", "INLINE", ["not zero and not a dash"]),
    ("BLANK-02", "Blank rows/labels/lines preserved", "INLINE", ["blank row, blank label"]),
    ("BLANK-03", "Empty source line not translated or filled", "INLINE", ["not translated, described or\nfilled", "not translated, described or filled"]),
    ("BLANK-04", "Line count in == line count out", "INLINE", ["Line count in == line count out"]),

    ("TOT-01", "Recompute only to report", "INLINE", ["only to REPORT"]),
    ("TOT-02", "No total where source prints none", "INLINE", ["the mirror has none", "the mirror has no total"]),
    ("TOT-03", "'no total present in source' logged", "INLINE", ["no total present in source"]),
    ("TOT-04", "Holds when arithmetic is obvious", "INLINE", ["arithmetic is obvious"]),
    ("TOT-05", "Never alter a value to force a match", "INLINE", ["force a match"]),
    ("TOT-06", "Vertical check", "KB", ["VERTICAL"]),
    ("TOT-07", "Horizontal check", "KB", ["HORIZONTAL"]),
    ("TOT-08", "Cross-foot check", "KB", ["CROSS-FOOT"]),
    ("TOT-09", "Balance check", "KB", ["Assets = Liabilities + Equity"]),
    ("TOT-10", "Rounding tolerance is a warning not a defect", "KB", ["rounding tolerance"]),

    ("SPAN-01", "Merged cell in the .docx", "INLINE", ["merged cell in the .docx"]),
    ("SPAN-02", "Blank continuation on screen", "INLINE", ["continuation\ncolumns BLANK", "continuation columns BLANK"]),
    ("SPAN-03", "Folded form only in LOG 1 column map", "INLINE", ["LOG 1's column map"]),
    ("SPAN-04", "All layers same leaf count", "INLINE", ["same leaf count"]),
    ("SPAN-05", "Empty leaf header stays present and empty", "KB", ["empty leaf header stays present and empty"]),
    ("SPAN-06", "Joiner ambiguity guard, folded layer only", "KB", ["SPACED hyphen"]),
    ("SPAN-07", "Unit captions above the table", "KB", ["SAR in thousands"]),
    ("SPAN-08", "Vertical span merged vertically", "KB", ["vertical span"]),

    ("TBL-01", "Four table classes named", "BOTH", ["Standard, long, complex and nested", "STANDARD", "NESTED"]),
    ("TBL-02", "Class never changes fidelity owed", "INLINE", ["class never changes what is owed"]),
    ("TBL-03", "Single-table fidelity", "KB", ["output ONE table"]),
    ("TBL-04", "Section labels stay as rows", "KB", ["own ROW inside the table"]),
    ("TBL-05", "Never drop minor rows", "BOTH", ["minor row", "Others, eliminations"]),
    ("TBL-06", "Never drop the line after a header", "KB", ["Other comprehensive income"]),
    ("TBL-07", "Borderless tables rebuilt with borders", "KB", ["borderless", "Borderless"]),
    ("TBL-08", "Valid Markdown contract", "BOTH", ["Markdown"]),

    ("SBS-01", "Split at the gutter first", "BOTH", ["gutter"]),
    ("SBS-02", "Right block first (RTL logical order)", "INLINE", ["RIGHT block is logically first", "RIGHT block"]),
    ("SBS-03", "Announce the order used", "INLINE", ["Announce the order"]),
    ("SBS-04", "Never merge rows across blocks", "KB", ["Never merge a row from one block"]),
    ("SBS-05", "One wide table is not two blocks", "KB", ["it is one table"]),

    ("HF-01", "Header/footer to Word header/footer", "INLINE", ["Word header and footer"]),
    ("HF-02", "Never inline in the body", "INLINE", ["never inline in the\nbody", "never inline in the body"]),
    ("HF-03", "Static page numbers, never a field", "INLINE", ["never an automatic\nfield", "STATIC text"]),
    ("HF-04", "Never invent running furniture", "INLINE", ["invent running furniture"]),
    ("HF-05", "New Word section when the header changes", "KB", ["new Word section"]),
    ("HF-06", "Watermarks/stamps reproduced in place", "KB", ["Watermarks, stamps"]),
    ("HF-07", "Footnotes stay on their page", "KB", ["Footnote markers"]),

    ("NUM-01", "Arabic-Indic digits converted", "BOTH", ["Arabic-Indic"]),
    ("NUM-02", "Extended Arabic-Indic digits converted", "BOTH", ["extended Arabic-Indic", "Extended Arabic-Indic"]),
    ("NUM-03", "Arabic separators converted not deleted", "BOTH", ["U+066B", "Arabic separators"]),
    ("NUM-04", "Three-decimal currency list", "KB", ["JOD, KWD, BHD, OMR"]),
    ("NUM-05", "Two-decimal currency list", "KB", ["EGP, SAR, AED"]),
    ("NUM-06", "No last-two-digits decimal heuristic", "INLINE", ["last two digits"]),
    ("NUM-07", "Stop and ask if precision unknown", "INLINE", ["precision is unknown"]),
    ("NUM-08", "Trailing minus moved before the value", "KB", ["Trailing minus"]),
    ("NUM-09", "Space thousands separators legitimate", "KB", ["1 234 567"]),
    ("NUM-10", "Bidi mirrored brackets", "KB", ["U+FD3E"]),
    ("NUM-11", "Flag taxonomy CRITICAL/MAJOR/ROUNDING", "KB", ["CRITICAL", "MAJOR", "ROUNDING"]),
    ("NUM-12", "Hijri dates reproduced as printed", "KB", ["Hijri"]),

    ("GLO-01", "TMS is tier 1 and top priority", "BOTH", ["TOP PRIORITY", "the TMS is the top priority"]),
    ("GLO-02", "AI translates only after TMS and termbase miss", "INLINE", ["Only then YOU translate"]),
    ("GLO-03", "AI renderings logged AI-TRANSLATED", "INLINE", ["AI-TRANSLATED"]),
    ("GLO-04", "TMS English inserted verbatim, even mid-sentence", "INLINE", ["VERBATIM, even mid-sentence"]),
    ("GLO-05", "One term one English, session-locked", "INLINE", ["One term -> one English"]),
    ("GLO-06", "Normalisation rules for lookup", "KB", ["tashkeel"]),
    ("GLO-07", "Normalisation applies to lookup key only", "KB", ["never to delivered text"]),
    ("GLO-08", "Jurisdiction guard", "KB", ["Jurisdiction guard"]),
    ("GLO-09", "TERM-CONFLICT logged", "KB", ["TERM-CONFLICT"]),
    ("GLO-10", "Translate headings/notes/stamps/labels", "KB", ["stamps, seals, labels"]),
    ("GLO-11", "Proper nouns transliterated", "KB", ["proper nouns"]),
    ("GLO-12", "Formal IFRS register", "KB", ["IFRS register"]),
    ("GLO-13", "TMS never overridden by model preference", "INLINE", ["never overridden by your own preference"]),
    ("GLO-14", "TMS HITS table applied first", "BOTH", ["TMS HITS"]),
    ("GLO-15", "Two-column Native/English TMS accepted", "KB", ["Two columns are enough"]),
    ("GLO-16", "Duplicate native terms reported, not guessed", "KB", ["TMS-DUPLICATE"]),
    ("GLO-17", "No Arabic remains except Do-Not-Translate", "INLINE", ["No Arabic remains"]),
    ("GLO-18", "Clitic prefixes; bare waw never stripped", "KB", ["\u0648\u062f\u0627\u0626\u0639"]),
    ("GLO-19", "TMS CANDIDATES list for curation", "KB", ["TMS CANDIDATES"]),
    ("GLO-20", "AI register: Arabic-GAAP / IFRS financial reporting", "INLINE", ["Arabic-GAAP / IFRS financial-reporting"]),
    ("GLO-21", "AI override of a TMS term blocked and logged", "KB", ["AI-OVERRIDE-BLOCKED"]),
    ("GLO-22", "Termbase is tier 2, between TMS and AI", "INLINE", ["IFRS_Fallback_Termbase, for terms the TMS lacks"]),
    ("GLO-23", "Missing pre-pass logged, TMS file used", "KB", ["TMS-PREPASS-MISSING"]),
    ("GLO-24", "Verbatim check after the reply fails a paraphrase", "KB", ["a paraphrase fails the"]),
    ("GLO-25", "Longest match first", "KB", ["longest match first"]),
    ("ILL-01", "Illegible left empty in mirror", "INLINE", ["left EMPTY in the mirror"]),
    ("ILL-02", "Illegible located in LOG 3", "INLINE", ["located in LOG 3"]),

    ("GEO-01", "Portrait default", "KB", ["Portrait is the default"]),
    ("GEO-02", "Never squeeze/narrow/drop columns", "KB", ["never be squeezed"]),
    ("GEO-03", "Wide-table priority order 1-2-3", "KB", ["continuation blocks"]),
    ("GEO-04", "Method recorded in LOG 1", "KB", ["Record which option"]),

    ("LOG-01", "LOG 1 fidelity emitted", "INLINE", ["LOG 1"]),
    ("LOG-02", "LOG 2 table validation emitted", "INLINE", ["LOG 2"]),
    ("LOG-03", "LOG 3 flags emitted", "INLINE", ["LOG 3"]),
    ("LOG-04", "LOG 1 carries header/footer parity", "KB", ["Header src/out"]),
    ("LOG-05", "LOG 1 carries the column map", "KB", ["COLUMN MAP"]),
    ("LOG-06", "Blank lines count as lines", "KB", ["Blank lines count as lines"]),
    ("LOG-07", "Closing summary line", "KB", ["total pages, total tables"]),
    ("LOG-08", "Gate is computed, not attested", "BOTH", ["computed gate", "computed, not attested"]),

    ("OUT-01", "Output order: mirror, logs, footer", "INLINE", ["OUTPUT ORDER"]),
    ("GATE-01", "Gate checklist present", "INLINE", ["GATE"]),
    ("GATE-02", "Claim 100% only on final all-PASS", "INLINE", ["Claim 100%"]),
    ("ACC-01", "Owns output, fixes failed gates", "INLINE", ["Fix failed gates"]),
    ("ACC-02", "States limits with page/row refs", "INLINE", ["page and row references"]),
]


# Normative tables that must have exactly ONE authoritative home. A rule stated
# in two files can drift; retrieval may then return the stale one, and nothing
# announces the contradiction. Each entry lists the needle, the file that owns
# it, and the marker a deferring file must carry.
# Owner is matched on the filename STEM, so a module counts as its own owner
# whether it is deployed as .md or .docx.
SINGLE_SOURCE = [
    ("three-decimal currency table", "JOD, KWD, BHD, OMR",
     "MDR-02_Numbers_Currency_QC", "MDR-02"),
    ("span header three layers", "folded",
     "MDR-01_Tables_and_Headers", "MDR-01"),
    ("glossary resolution order", "Clitic or article variant",
     "MDR-03_Translation_Glossary", "MDR-03"),
    ("batch weight table", "wide_or_nested",
     "MDR-05_Pages_Batching_HeadersFooters", "MDR-05"),
]


# Superseded rules. The atom check proves a new rule is PRESENT; this proves the
# rule it replaced is GONE from everything the agent reads. Two opposite rules
# in the knowledge base is worse than one missing rule: retrieval surfaces
# whichever chunk scores higher, and nothing reports the contradiction.
# Scope is strict -- the inline instruction and every knowledge file -- because
# the agent cannot tell a historical note from a live rule.
SUPERSEDED = [
    ("unmapped term left in Arabic", r"reproduce the term in the ORIGINAL"),
    ("ban on AI rendering of unmapped terms", r"never invent an English rendering"),
    ("ban on AI rendering of unmapped terms", r"do not invent an English rendering"),
    ("general knowledge disabled", r"disable general knowledge"),
    ("unmapped marker in output", r"\[TERM-UNMAPPED:"),
]


def stem(fn):
    return os.path.splitext(fn)[0]


def docx_text(path):
    """
    Extract every character a knowledge indexer would see: body paragraphs plus
    all table cell text. Conversion to .docx can silently drop content -- a table
    that fails to render, a code block that collapses -- so the audit reads the
    .docx itself rather than trusting the markdown it came from.
    """
    from docx import Document as Docx
    d = Docx(path)
    parts = [p.text for p in d.paragraphs]
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                parts.extend(pp.text for pp in c.paragraphs)
    return "\n".join(parts)


def read_any(path):
    if path.lower().endswith(".docx"):
        return docx_text(path)
    return open(path, encoding="utf-8").read()


def load():
    """
    Audit what will actually be deployed. If a .docx twin exists it wins, because
    that is the artifact being pasted into the instruction field and uploaded as
    a knowledge source; the .md/.txt originals are kept only as the editable source.
    """
    inline_path = INLINE
    docx_twin = INLINE.rsplit(".", 1)[0] + ".docx"
    if os.path.exists(docx_twin):
        inline_path = docx_twin
    inline = read_any(inline_path)

    kb, seen = {}, set()
    for fn in sorted(os.listdir(KB_DIR)):
        low = fn.lower()
        if low.endswith(".docx"):
            kb[fn] = read_any(os.path.join(KB_DIR, fn))
            seen.add(low[:-5])
    for fn in sorted(os.listdir(KB_DIR)):
        low = fn.lower()
        if low.endswith(".md") and low[:-3] not in seen:
            kb[fn] = read_any(os.path.join(KB_DIR, fn))
    return inline, kb


def norm(t):
    return " ".join(t.split()).lower()


# The two unlimited-length builds state every rule inline, so they must satisfy
# the same atom list with no knowledge base at all. KB-02/KB-03 are excluded:
# they govern what to do when retrieval fails, and these builds never retrieve.
FULL_BUILDS = [
    ("GitHub Copilot", os.path.join(HERE, "..", "06_Editable_Sources", "github_copilot_full.md")),
    ("Gemini",         os.path.join(HERE, "..", "06_Editable_Sources", "gemini_full.md")),
]
FULL_BUILD_NA = {"KB-02", "KB-03"}


def audit_full_builds():
    out = []
    for label, path in FULL_BUILDS:
        if not os.path.exists(path):
            out.append((label, None, None, ["FILE-MISSING"]))
            continue
        text = norm(open(path, encoding="utf-8").read())
        miss = [a for a, d, loc, needles in ATOMS
                if a not in FULL_BUILD_NA and not any(norm(x) in text for x in needles)]
        stale = [lbl for lbl, pat in SUPERSEDED if re.search(pat, text, re.I)]
        total = len(ATOMS) - len(FULL_BUILD_NA)
        out.append((label, total - len(miss), total, miss + stale))
    return out


def main() -> int:
    inline, kb = load()
    n_inline, n_kb = norm(inline), {k: norm(v) for k, v in kb.items()}
    kb_all = " || ".join(n_kb.values())

    rows, lost, misplaced = [], [], []
    for aid, desc, loc, needles in ATOMS:
        hits_inline = any(norm(x) in n_inline for x in needles)
        where_kb = [f for f, t in n_kb.items() if any(norm(x) in t for x in needles)]
        hits_kb = bool(where_kb)

        if hits_inline and hits_kb:
            found = "INLINE+KB"
        elif hits_inline:
            found = "INLINE"
        elif hits_kb:
            found = "KB"
        else:
            found = "MISSING"

        if found == "MISSING":
            status = "LOST"
            lost.append((aid, desc))
        elif loc == "INLINE" and not hits_inline:
            status = "MISPLACED"
            misplaced.append((aid, desc))
        else:
            status = "OK"

        rows.append({"id": aid, "desc": desc, "required": loc,
                     "found": found, "kb_files": where_kb, "status": status})

    # --- duplicate-authority check -------------------------------------
    dup = []
    for label, needle, owner, marker in SINGLE_SOURCE:
        holders = [f for f, t in n_kb.items() if norm(needle) in t]
        strays = [f for f in holders
                  if stem(f) != owner and norm(marker) not in n_kb[f]]
        if owner not in [stem(f) for f in holders]:
            dup.append({"table": label, "problem": "OWNER-MISSING",
                        "owner": owner, "found_in": holders})
        elif strays:
            dup.append({"table": label, "problem": "UNDEFERRED-DUPLICATE",
                        "owner": owner, "found_in": strays})

    # The 8,000-character budget applies to the text pasted into the instruction
    # field, so it is always measured on the .txt, never on the .docx wrapper.
    contradictions = []
    for label, pat in SUPERSEDED:
        for where, text in [("INLINE", inline)] + list(kb.items()):
            m = re.search(pat, text, re.I)
            if m:
                contradictions.append({"rule": label, "file": where,
                                       "excerpt": text[max(0, m.start()-40): m.end()+40]})

    size = len(open(INLINE_TXT, encoding="utf-8").read())
    size_ok = size <= INLINE_LIMIT

    if "--json" in sys.argv:
        print(json.dumps({"inline_chars": size, "limit": INLINE_LIMIT,
                          "within_limit": size_ok, "atoms": len(rows),
                          "lost": len(lost), "misplaced": len(misplaced),
                          "duplicate_authority": dup,
                          "contradictions": contradictions,
                          "rows": rows}, ensure_ascii=False, indent=2))
        return 1 if (lost or misplaced or dup or contradictions or not size_ok) else 0

    print("=" * 78)
    print("MirrorDoc-AR v2.3 -- INSTRUCTION COVERAGE AUDIT")
    print("=" * 78)
    print(f"Inline instruction size : {size} chars (limit {INLINE_LIMIT}) "
          f"{'OK' if size_ok else 'OVER LIMIT'}")
    print(f"Knowledge modules       : {len(kb)}")
    print(f"Rule atoms audited      : {len(rows)}")
    print()
    for r in rows:
        if r["status"] != "OK":
            print(f"  [{r['status']}] {r['id']}  {r['desc']}  "
                  f"(required {r['required']}, found {r['found']})")
    if not lost and not misplaced:
        print("  Every atom is homed. No rule was lost in the split.")
    print()
    full = audit_full_builds()
    full_bad = [f for f in full if f[3]]
    print("  Cross-platform check (full-text builds carry every rule inline):")
    for label, ok, total, probs in full:
        mark = "OK" if not probs else "FAIL " + ", ".join(probs[:4])
        print(f"    {label:16} {ok}/{total} atoms  {mark}")
    print()
    print("  Contradiction check (superseded rules must be gone):")
    if contradictions:
        for c in contradictions:
            print(f"    [STALE] {c['rule']} -> still in {c['file']}")
    else:
        print("    No superseded rule survives in the instructions or knowledge base.")
    print()
    print("  Single-source check:")
    if dup:
        for d in dup:
            print(f"    [{d['problem']}] {d['table']} -> owner {d['owner']}, "
                  f"also in {', '.join(d['found_in'])}")
    else:
        print("    Every normative table has one owner; duplicates defer to it.")
    print()
    by_loc = {}
    for r in rows:
        by_loc[r["found"]] = by_loc.get(r["found"], 0) + 1
    for k in sorted(by_loc):
        print(f"  {k:<12} {by_loc[k]}")
    print()
    print("=" * 78)
    ok = (not lost and not misplaced and not dup and not contradictions
          and not full_bad and size_ok)
    print("RESULT:", "PASS -- coverage complete and within limit" if ok
          else f"BLOCKED -- {len(lost)} lost, {len(misplaced)} misplaced, "
               f"{len(dup)} duplicate-authority, {len(contradictions)} stale, {len(full_bad)} platform, size {'ok' if size_ok else 'over'}")
    print("=" * 78)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
