# Installation — GitHub Copilot (no instruction-length limit)

**What this build can do that the Copilot Studio one cannot.** There is no cap on
instruction length, so every rule is stated inline — nothing depends on retrieval. And
the agent can run code, so it reads the Arabic Master as a table itself and **builds the
.docx itself**, with no external flow.

## 1. Repository layout

```
mirrordoc-ar/
├── .github/copilot-instructions.md     <- the full instruction file
├── knowledge/
│   ├── Arabic_Master.xlsx              <- your glossary: col A Arabic, col B English
│   ├── IFRS_Fallback_Termbase.xlsx
│   └── MDR-01..05 (reference copies)
├── tools/
│   ├── mirrordoc_core.py               <- loader, pre-pass, validators
│   └── build_mirror_docx.py            <- mirror -> .docx
├── input/                              <- source PDFs
└── output/                             <- delivered .docx and logs
```

## 2. Install

1. Copy `01_Agent_Instructions/GITHUB_COPILOT_Instructions_FULL.docx` into the repo as
   `.github/copilot-instructions.md` (plain Markdown — export or paste the text).
   Repository instructions are picked up automatically by Copilot Chat.
2. Copy `02_Knowledge_Resources/` into `knowledge/` and `03_Installation_Guide/tools/`
   into `tools/`.
3. Install dependencies:

```bash
pip install python-docx openpyxl --break-system-packages
```

4. Put your glossary at `knowledge/Arabic_Master.xlsx`.

## 3. Check the glossary before the first run

```bash
python3 tools/mirrordoc_core.py --health knowledge/Arabic_Master.xlsx
```

Read the report. Rows marked AUTO-FIXED are repaired on load. Rows marked
GARBLED-ARABIC, SUSPECTED-REVERSED or SPLIT-WORD will never match a real page and need a
clean re-export. Rows marked DUPLICATE map one term to two English renderings — neither
is applied until you resolve them.

## 4. Run a conversion

Open Copilot Chat in the repo and ask it to convert `input/<file>.pdf`. It will:

1. run the pre-pass against the Arabic Master and print the TMS HITS table;
2. render the mirror on screen for the batch;
3. verify every Arabic Master term appears verbatim;
4. build `output/Mirror_<file>_p1-15.docx`;
5. print LOG 1, LOG 2, LOG 3 and the batch footer.

Reply `next` for the following batch.

## 5. Acceptance tests

Same six as the Copilot Studio build, plus:

7. `verify_tms_applied` returns empty for a good batch and non-empty when you deliberately
   paraphrase a glossary term.
8. The produced .docx opens, spanned headers are merged cells, blank source cells are
   blank, and the running header sits in the Word header — not in the body.

Never accept a reply that claims a file was produced without a path you can open.
