# MirrorDoc-AR v3.0 — Start here

One Arabic→English financial document converter, built for three platforms. The rules are
identical in all three; only the platform mechanics differ.

| Folder | Instruction limit | Builds the .docx? |
|---|---|---|
| `01_Copilot_Studio_UNDER_8000` | 8,000 chars — uses **7,971** | **No** — a Power Automate flow does |
| `02_GitHub_Copilot_NO_LIMIT` | none — all rules inline | **Yes** — the agent runs the script |
| `03_Gemini` | none — all rules inline | **Yes** — via code execution |

Each platform folder contains `01_Agent_Instructions`, `02_Knowledge_Resources` and
`03_Installation_Guide`. Start with the installation guide in the folder for your platform.

## The one rule that matters most

**The Arabic Master comes first, always.** Column A Arabic, column B English, verified by
your linguists. Every term found there is used **verbatim** — same words, same spelling,
same capitalisation — wherever it appears, including mid-sentence. The AI cannot override
it, even when it believes another rendering is better.

Only for terms the Master does not contain does the agent fall back to the IFRS termbase,
and then to its own translation in Arabic-GAAP / IFRS financial-reporting register. Every
one of those is logged **AI-TRANSLATED** and listed as a TMS candidate for your glossary
owner, so the Master grows and the AI share shrinks.

No Arabic remains in the English output, except entries marked Do-Not-Translate.

## Before your first run: check the Arabic Master

```bash
python3 tools/mirrordoc_core.py --health knowledge/Arabic_Master.xlsx
```

**This is not optional.** The sample you supplied was checked, and of 34 rows only 21 were
usable. The rest were language-code rows, punctuation-only rows, dates, English in the
Arabic column, and — most seriously — rows whose Arabic is garbled or reversed
(`ةتباث موجودات` for `موجودات ثابتة`). A garbled row can never match a real page, so that
term silently falls to AI translation no matter how correct its English is.

Worse, most genuine rows carried the source document's own bullet: `قروض عقارية -`. The
page prints `قروض عقارية`, without the dash — so **every one of those approved terms
failed to match** until this was fixed. The loader now strips edge noise and note numbers
from the lookup key, and strips the leading `- ` from the English so it is not inserted
into your document.

## Why a pre-pass exists on every platform

A glossary uploaded as a knowledge file is indexed for **semantic search**, not queried as
a table. On a large glossary some rows simply will not be retrieved, and a missed term
becomes an AI translation that still reads as good English — so nobody notices.

Every build therefore reads the Arabic Master **as a table**, finds every term in the
batch deterministically, hands the agent a **TMS HITS** list to apply first, and afterwards
checks each one appears verbatim in the output. That is what turns "Master first" from an
instruction into a check.

## What each reply contains

1. the **mirror** — the translated document and nothing else;
2. **LOG 1** page fidelity, **LOG 2** table validation, **LOG 3** flags and AI-TRANSLATED terms;
3. the exact batch footer, so you can continue with `next`.

The mirror never carries a highlight, a tick, a marker, a note, or a total the source does
not print. All of that lives in the logs.

## Folder map

```
01_Copilot_Studio_UNDER_8000/   01_Agent_Instructions  02_Knowledge_Resources  03_Installation_Guide
02_GitHub_Copilot_NO_LIMIT/     01_Agent_Instructions  02_Knowledge_Resources  03_Installation_Guide
03_Gemini/                      01_Agent_Instructions  02_Knowledge_Resources  03_Installation_Guide
04_Shared_Team_Materials/       team presentation, worked example, Arabic Master template
05_Validation_and_UAT/          validators, 208-case UAT, coverage audit, validation workbook
06_Editable_Sources/            the Markdown/text originals — edit these, then regenerate
```
