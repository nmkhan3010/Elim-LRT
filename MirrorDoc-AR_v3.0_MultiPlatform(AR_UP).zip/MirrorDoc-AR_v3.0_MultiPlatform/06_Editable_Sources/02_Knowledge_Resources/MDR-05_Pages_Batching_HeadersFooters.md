---
module: MDR-05
title: Page geometry, running headers and footers, orientation and batching
applies_to: MirrorDoc-AR v2.2
retrieval_keys: page, orientation, portrait, landscape, wide, geometry, header,
  footer, running head, page number, watermark, stamp, section, batch, batching,
  weight, budget, slice, DPI, deskew, OCR, preprocessing, footnote
---

# MDR-05 — Page geometry, headers and footers, orientation and batching

## 1. Pre-processing is the flow's job, not the model's

Before a page reaches the agent the ingestion flow has already: rendered at
300 DPI (400 DPI where body text measures under 8 pt), converted to greyscale,
deskewed, de-speckled, normalised orientation so all text is upright, and run
OCR with Arabic and English enabled and table-structure extraction on.

The agent's input is therefore **structured OCR output with coordinates**, not a
photograph. An instruction telling a language model to "read at maximum DPI" or
to "deskew skewed text" reads as a control and enforces nothing — the model
cannot rasterise a PDF. A page arriving without cell structure is not read
visually: record PREPROCESS-MISSING in LOG 3 and continue.

## 2. Two different kinds of orientation

**Reading orientation** — normalised upright upstream, always, not optional.

**Output orientation** — the Word page. Portrait is the default. A wide table
must never be squeezed, narrowed, or have columns dropped to fit it. Apply in
priority order:

1. Portrait, reduced font to a 7 pt floor, header row repeated on each page.
   *Applies up to about 12 leaf columns.*
2. Portrait **continuation blocks**: split by columns only, repeat the row-label
   (stub) column in every block, caption each `Table T, columns 1–8 of 20
   (Part 1 of 3)`. Row count is identical in every part.
   *Applies over 12 leaf columns.*
3. A landscape section for that table alone. *Only when 1 and 2 both fail.*

Record which option was used in LOG 1, so a reviewer can see why a table was
presented as it was. Never silently reflow.

## 3. Running headers, footers and page furniture

A running header or footer is part of the document and MUST be reproduced — but
never as body text.

- Map the source header band to the **Word header**, the footer band to the
  **Word footer**. Never paste either into the body flow, where it corrupts the
  line count and appears mid-page.
- Translate the contents by the same glossary rules as body text (MDR-03 §4).
- **Page numbers:** reproduce the number the source PRINTS, as STATIC text.
  Never insert an automatic page-number field — a field regenerates on open and
  can silently diverge from the printed number, breaking the trace-to-source
  rule.
- If the header or footer CHANGES between pages (a running section title, a
  statement name), start a new Word section at each change, so every output page
  carries the header its source page carried.
- If a page has NO header or footer, its Word section has none. Never invent
  running furniture, and never carry a header onto a page that lacked one.
- Watermarks, stamps and seals: reproduce the text, translated, positioned as
  printed. If it sits in the header or footer band it belongs to that band.
- First-page-different and odd/even variation in the source are mirrored by the
  corresponding Word section settings.
- Footnote markers stay attached to the text they mark; footnote bodies stay at
  the foot of the page they occupy in the source.

Header and footer parity is logged per page in LOG 1.

## 4. Batching — complexity-weighted, not a flat page count

A flat "N pages per reply" is the wrong unit: one 20-column nested balance sheet
costs more output than fifteen narrative pages.

| Page class | Weight |
|---|---|
| narrative | 1 |
| simple_table (≤ 8 leaf columns) | 2 |
| dense_table (9–15 leaf columns) | 3 |
| wide_or_nested (> 15 columns, landscape, or side-by-side) | 4 |

BUDGET = 15 weight units per reply. HARD CAP = 15 pages per reply. Fill a batch
until the next page would exceed either limit. A single page that exceeds the
budget on its own still forms its own batch. **Never split a table across two
replies.**

So: 15 narrative pages ship in one reply; 3 wide nested tables also fill one.

**Mid-reply abort.** If you sense you are approaching the response limit, stop
at the last COMPLETE table. Never emit a partial table or a partial row. Declare
the pages you actually delivered, not the pages you planned.

**Continuation.** On 'next', process ONLY the following slice. Never re-OCR,
re-load or re-output earlier pages — reprocessing the whole file is the primary
cause of timeouts.
