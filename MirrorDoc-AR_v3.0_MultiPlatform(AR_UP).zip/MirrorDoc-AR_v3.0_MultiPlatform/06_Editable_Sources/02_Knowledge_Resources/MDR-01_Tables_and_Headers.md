---
module: MDR-01
title: Tables, spanned headers and side-by-side blocks
applies_to: MirrorDoc-AR v2.2
retrieval_keys: table, tables, header, headers, span, spanned, umbrella, nested,
  merged, colspan, rowspan, leaf, column, side-by-side, gutter, block, RTL,
  continued, long table, complex table, single-table, borderless, Markdown
---

# MDR-01 — Tables, spanned headers and side-by-side blocks

Authority: this module is subordinate to REPLICA-ONLY and NO-ANNOTATION. Where
anything here would put a character on the page that the source does not print,
the core rule wins.

## 1. Table classes — the class never changes the fidelity owed

| Class | Definition | The trap |
|---|---|---|
| STANDARD | One header row, uniform columns | None; still reproduce every row |
| LONG | Runs across pages | Repeat the header row **only where the source repeats it**. Never add "continued" |
| COMPLEX | Merged cells, section rows, mixed alignment, footnote markers | Section labels stay as their own ROW inside the table |
| NESTED | Multi-level spanned headers | Handled in §3 |

Never simplify, split, merge, narrow or drop a column to make a table fit. Never
drop a minor row — Others, eliminations, deferred tax, borrowings and blank-label
rows are the routine casualties. Never drop the line immediately after a header;
Other comprehensive income, Segment liabilities and Equity and liabilities are
the three that disappear most often.

## 2. Single-table fidelity

Reproduce tables exactly as grouped in the source. If the balance sheet is
printed as ONE table covering current assets, non-current assets, liabilities
and equity, output ONE table. Never emit a table per block. Section labels such
as "Current assets" are rows inside that table, not separate table headings.

Borderless and whitespace-aligned tables (common in Arabic financials) are
rebuilt as real tables with borders. That is a rendering of structure the source
already has; it adds no content.

Markdown for the on-screen mirror: header row, `| --- |` separator, identical
pipe counts on every line, one row per line, a blank line above and below, no
leading spaces.

## 3. Spanned / umbrella / nested headers — three layers, one truth

A spanned header is printed **once** in the source. Everything below follows
from that single fact.

| Layer | Where it appears | Rendering |
|---|---|---|
| MERGED | the .docx | One cell carrying the label, merged across exactly the leaf columns it covers |
| MIRROR | on screen | Label in the FIRST leaf column it covers; every continuation column BLANK |
| FOLDED | LOG 1 column map only | `Assets - 2025`, joined by exactly space-hyphen-space |

Worked example. Source prints:

```
|        الأصول         |        الخصوم        |
|  2025    |    2024    |  2025    |   2024    |
```

Mirror renders:

```
| Assets   |            | Equity   |           |
| 2025     | 2024       | 2025     | 2024      |
```

The blank **is** the span. It says the column above is covered by the label to
its left, which is exactly what the printed page says by centring one label over
two columns. Repeating "Assets" there adds a word to the page.

### Invariants
- Leaf-column count must equal the source leaf count, and all three layers must
  resolve to the same number. A disagreement means a column was invented or lost.
- Rowspan pass-down is computed internally so the parent is known for every leaf.
  It is simply not printed for every leaf.
- An empty leaf header stays present and empty. This is distinct from a
  continuation blank: the first is a column the source left unlabelled, the
  second is a column covered by a span.
- A vertical span (a label covering two header rows) is merged vertically in the
  .docx and left blank in the row beneath on screen.
- Unit captions such as "SAR in thousands" sit as text ABOVE the table, where the
  source prints them, never inside the header.

### Joiner ambiguity — folded layer only
A source label containing a SPACED hyphen would be indistinguishable from the
joiner when split back into levels, so inside the folded string it is tightened
to an unspaced hyphen. `Non-current` is already unspaced and round-trips safely.
**This tightening never touches delivered text** — the mirror and the .docx keep
the label exactly as printed, spaced hyphen and all.

## 4. Side-by-side blocks

When one physical page carries two or more tables side by side:

1. Find the vertical whitespace gutter and split there FIRST.
2. Process each block as a complete independent table — header, body, totals —
   before starting the next.
3. Never merge a row from one block with a row from the block beside it, even
   when their baselines align.

**Order.** An Arabic page reads right to left, so the logically FIRST block is
the RIGHTMOST one. Default order is right block, then left block. Announce it
above the output: *"Side-by-side page: processing right block then left block
(RTL logical order)."* If the page is laid out LTR, invert and say so.

Blocks stacked in bands: complete the whole upper band (right then left) before
any block in the lower band.

**Distinguish two cases before splitting.** Two independent tables side by side
are two blocks. One wide table whose comparative years happen to sit apart is
ONE table — splitting it would breach single-table fidelity in §2. Decide by the
header: if a single spanned header covers both sides, it is one table.
