# Dialect & Jurisdiction Variant Map — Arabic financial reporting

The agent uses this to resolve tier-3 lookups and to set numeric expectations per
jurisdiction. Terminology, currency precision and numeral conventions all vary by market,
and getting the numeric conventions wrong is far more damaging than getting a caption wrong:
a mistranslated heading is visible to a reviewer, a mis-scaled number is not.

## 1. Currency precision — the single highest-risk variable

> **Precision is defined in MDR-02_Numbers_Currency_QC.md**, which is the normative
> source. The decimal column below is reproduced for convenience when identifying a
> jurisdiction; if it ever disagrees with MDR-02, MDR-02 wins.

| Jurisdiction | Currency | Decimal places | Note |
|---|---|---|---|
| Jordan | JOD | **3** | Divided into 1,000 fils |
| Kuwait | KWD | **3** | |
| Bahrain | BHD | **3** | |
| Oman | OMR | **3** | |
| Tunisia | TND | **3** | |
| Libya | LYD | **3** | |
| Iraq | IQD | **3** | |
| Egypt | EGP | 2 | |
| Saudi Arabia | SAR | 2 | |
| UAE | AED | 2 | |
| Qatar | QAR | 2 | |
| Lebanon | LBP | 2 | Very large magnitudes; grouping errors are easy to miss |

**Why this matters.** A rule of the form *"a comma or dot before the last two digits means it
is a decimal separator"* is correct for EGP and SAR and **wrong for JOD, KWD, BHD and OMR**.
Applied to a Jordanian statement, `1,234.567` is read as `1,234,567` or `1,234.57` — a
factor-of-1,000 or a truncation error, in a cell that still looks perfectly plausible.
Precision must be read from the declared reporting currency, never inferred from digit
position.

## 2. Numeral systems

| Region | Digits typically used |
|---|---|
| Egypt, Levant, Gulf, Iraq | Arabic-Indic `٠١٢٣٤٥٦٧٨٩` (U+0660–0669) |
| Morocco, Algeria, Tunisia | Western `0123456789` |
| Occasional regional filings | Extended Arabic-Indic `۰۱۲۳۴۵۶۷۸۹` (U+06F0–06F9) |

Separators that must be **converted, never stripped**:

| Char | Code point | Name | Convert to |
|---|---|---|---|
| `٫` | U+066B | Arabic decimal separator | `.` |
| `٬` | U+066C | Arabic thousands separator | `,` |
| `٪` | U+066A | Arabic percent sign | `%` |
| `،` | U+060C | Arabic comma | `,` |

Deleting U+066B instead of converting it turns `١٢٣٤٫٥٦` (1234.56) into 123456 — a
hundred-fold error with no visible trace.

## 3. Statement captions by jurisdiction

| Concept | Egypt (EAS) | Gulf (IFRS) | Levant (IFRS) | English |
|---|---|---|---|---|
| Balance sheet | قائمة المركز المالي | الميزانية العمومية / قائمة المركز المالي | قائمة المركز المالي | Statement of financial position |
| Revenue | الإيرادات / المبيعات | الإيرادات | الإيرادات | Revenue |
| Retained earnings | الأرباح المرحلة | الأرباح المبقاة | الأرباح المدورة | Retained earnings |
| Trade receivables | المدينون / ذمم مدينة | ذمم مدينة تجارية | ذمم مدينة | Trade receivables |
| G&A expenses | مصروفات عمومية وإدارية | المصروفات العمومية والإدارية | مصاريف إدارية وعمومية | General and administrative expenses |
| Religious levy | — | الزكاة (KSA) | — | Zakat — **never render as "tax"** |

## 4. Jurisdiction-specific traps

**Saudi Arabia.** *Zakat* is a distinct levy from income tax and is frequently presented on
its own line, sometimes combined as الزكاة وضريبة الدخل. Render Zakat as Zakat. Collapsing it
into "tax" destroys a reported distinction.

**Egypt.** Filings may be prepared under Egyptian Accounting Standards rather than full IFRS;
captions differ and the standard reference in the glossary should say EAS, not IAS. Comparative
figures are commonly restated after a currency revaluation — reproduce the restated figures as
printed and never reconcile them to a prior filing.

**Jordan / Levant.** Three-decimal currency, and space-separated thousands (`1 234 567`) are
common. Both are legitimate; both are routinely destroyed by naive whitespace stripping.

**Gulf generally.** Hijri and Gregorian dates often appear together (`٣٠ ذو الحجة ١٤٤٦ / 30 June
2025`). Reproduce **both** as printed. Do not convert one into the other and do not drop either.

## 5. Bidirectional text hazards

- An RTL run can emit mirrored brackets U+FD3E `﴾` and U+FD3F `﴿` where `(` and `)` were
  intended. Treat as ordinary parentheses and flag.
- A negative rendered as `(1,234)` in an RTL paragraph may be extracted with the brackets
  transposed or on the wrong side. Verify against the sign convention used elsewhere in the
  same column before accepting.
- Zero-width and directional control characters (U+200B–U+200F, U+202A–U+202E, U+2066–U+2069)
  survive OCR and silently break exact string matching against the glossary. Strip them when
  building the lookup key; never strip them from displayed source text you are quoting.
