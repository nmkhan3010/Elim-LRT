# Knowledge resources — what to upload, in what order, and why

The agent's inline instruction field is capped at **8,000 characters** and currently
uses 7,885. Everything else lives here. That is a deliberate architecture, not a
workaround, but it has one consequence you must design around:

> **Knowledge retrieval is probabilistic. An instruction field is not.**

So the split is not "important rules inline, details in the knowledge base". It is:

| Goes inline | Goes in the knowledge base |
|---|---|
| Any rule whose absence causes **silent** corruption | Reference **data**: tables, lists, taxonomies, worked examples |
| The fail-closed guard pointing at each module | Anything a reviewer would catch on sight if it went wrong |

A missed retrieval does not announce itself. That is why the inline core carries
the *rule* ("read precision from the currency table; never infer it; if unknown,
stop and ask") while the knowledge base carries the *table*. If retrieval fails,
the agent stops rather than guessing — the failure becomes loud instead of silent.

## Your TMS Excel is the top priority — and needs more than an upload

Two columns, **Native** and **English**, are all it needs. Upload it as
`TMS_Glossary_Master` — but understand what an upload does and does not do.

A knowledge upload is indexed for **semantic search**. That is how the agent
finds the rules in the MDR modules, and it works well for that. It is not a
guaranteed lookup of every row: on a glossary of thousands of terms, retrieval
will miss some, and a missed TMS term falls through to AI translation — silently,
because the result still reads as good English.

So the TMS is used **twice**:

- as a knowledge source, so the agent can consult it; and
- by the **TMS pre-pass** in the flow, which reads the Excel as a table, finds
  every TMS term in each batch deterministically, and sends the agent a TMS HITS
  table to apply first. The flow then checks every one appears verbatim in the
  output.

The second is the guarantee. Set it up as described in PASTE_03 §E.

## Upload these as agent knowledge sources, in this order

| # | File | Carries |
|---|---|---|
| 1 | `MDR-01_Tables_and_Headers.md` | Table classes, spanned headers, side-by-side blocks |
| 2 | `MDR-02_Numbers_Currency_QC.md` | Numerals, separators, currency precision, flag taxonomy |
| 3 | `MDR-03_Translation_Glossary.md` | Resolution order, normalisation, regional variants |
| 4 | `MDR-04_Logs_Gate_Validation.md` | Totals checks, LOG 1–3 layouts, the gate |
| 5 | `MDR-05_Pages_Batching_HeadersFooters.md` | Geometry, headers/footers, batching |
| 6 | `TMS_Glossary_Master_TEMPLATE.xlsx` | Your approved termbase (populate first) |
| 7 | `IFRS_Fallback_Termbase.xlsx` | Tier-4 fallback |
| 8 | `Dialect_Variant_Map.md` | Tier-3 jurisdiction and dialect variants |
| 9 | `Number_Format_Rules.md` | Engineering map from rule to enforcing code |

Order matters only for tier resolution in the glossary chain (6 → 7 → 8). The five
MDR modules are retrieved by topic, not by order.

## Precedence — read this before editing anything

1. The **inline instructions** hold the authority order. Nothing here overrides it.
2. Each MDR module is the **single normative source** for its own subject. MDR-02
   owns numeric rules; MDR-01 owns table and header rules; and so on.
3. Where a file restates another module's rule, it must carry an explicit deferral
   pointing at the owner. `Dialect_Variant_Map.md` and `Number_Format_Rules.md`
   both defer to MDR-02 on currency precision for exactly this reason.
4. Where a module and `mirrordoc_core.py` disagree on a deterministic rule, the
   **code** is authoritative and the module is the defect.

`03_Validation_QC/validators/coverage_audit.py` enforces 2 and 3 automatically. It
fails the build if a normative table gains a second undeferred home, because two
copies of a rule will eventually drift and retrieval will surface the stale one
without saying so.

## Front matter

Each MDR module opens with a YAML block carrying `retrieval_keys`. These exist to
make topical retrieval hit reliably — a question about "fils" or "three decimals"
should reach MDR-02 even though neither phrase is a heading. If you add content to
a module, add its distinctive vocabulary to that list.

## After any edit

```bash
python3 03_Validation_QC/validators/coverage_audit.py
```

It re-checks all 121 rule atoms, the 8,000-character ceiling, and the single-source
rule. Do not upload a knowledge base that fails it.

## What must never go in here

**Never upload a source PDF as a knowledge source.** Knowledge files are
terminology and rules. A document to be converted is a job input. Uploading a
filing to knowledge lets its figures leak into an unrelated conversion — precisely
the failure REPLICA-ONLY exists to prevent. Use `UPLOAD_INBOX/` for material
awaiting review.
