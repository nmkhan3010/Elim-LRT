---
module: MDR-02
title: Numerals, separators, currency precision and number QC
applies_to: MirrorDoc-AR v2.2
retrieval_keys: number, numeral, digit, Arabic-Indic, decimal, separator,
  thousands, currency, precision, JOD, KWD, BHD, OMR, EGP, SAR, percent,
  negative, bracket, minus, QC, flag, critical, major, rounding, blank, dash
---

# MDR-02 — Numerals, separators, currency precision and number QC

> **NORMATIVE SOURCE.** This module is the single authority for numeral
> conversion, separators, currency precision and number-QC severity. Where any
> other knowledge file appears to state a numeric rule, it is illustrative and
> defers to this module. Where this module and
> `03_Validation_QC/validators/mirrordoc_core.py` disagree, the **code** is
> authoritative and this module is the defect — raise it, do not work around it.

## 1. Digit conversion

Arabic-Indic (U+0660–0669): ٠=0 ١=1 ٢=2 ٣=3 ٤=4 ٥=5 ٦=6 ٧=7 ٨=8 ٩=9

Extended Arabic-Indic (U+06F0–06F9): ۰۱۲۳۴۵۶۷۸۹ — the Persian/Urdu forms. These
appear in some regional filings and are a different code range from the above.
A converter that handles only the first range silently drops these.

## 2. Separators that are routinely lost

| Codepoint | Char | Meaning | Convert to |
|---|---|---|---|
| U+066B | ٫ | Arabic decimal separator | `.` |
| U+066C | ٬ | Arabic thousands separator | `,` |
| U+066A | ٪ | Arabic percent sign | `%` |
| U+060C | ، | Arabic comma | `,` |

These must be **converted, not deleted**. A pipeline that strips unrecognised
characters turns ١٢٣٤٫٥٦ into 123456: every digit is still correct and the
magnitude is wrong by two orders. No digit-level check catches it.

## 3. Currency precision — read it, never infer it

| Decimals | Currencies |
|---|---|
| 3 | JOD, KWD, BHD, OMR, TND, LYD, IQD |
| 2 | EGP, SAR, AED, QAR, USD, EUR, MAD, LBP, SYP, YER |

**Never apply a "comma or dot before the last two digits means a decimal point"
heuristic.** It is right for EGP and SAR and wrong for the Jordanian, Kuwaiti and
Bahraini dinar and the Omani rial, all of which carry three decimals. On a
Jordanian filing the heuristic rescales values by a factor of ten or truncates a
fils, and the result still looks like a sensible number.

Read precision from the currency declared in the inventory contract. Flag any
cell whose precision contradicts the declared currency. If the currency is not
determinable, STOP and ask — do not guess.

Hijri and dual-calendar dates are reproduced exactly as printed. Never convert
a calendar.

## 4. Number QC — apply to every numeric cell

- Trailing minus `1,234-` → move before the value: `-1,234`. Severity MAJOR.
- Deliberate space thousands separators (`1 234 567`) are LEGITIMATE in Egyptian
  and Levantine statements — reproduce exactly. Only groups of exactly three
  count; any other internal space is OCR damage (CRITICAL).
- Never change grouping magnitude.
- Bidi note: an RTL run can emit mirrored brackets (U+FD3E / U+FD3F). Treat them
  as `(` and `)` and flag BIDI-MIRRORED-BRACKET.
- Negatives in parentheses stay in parentheses. A missing closing parenthesis on
  a negative is CRITICAL — `(10,000)` read as `10,000` inverts the sign.

## 5. Blank, dash and zero are three different things

| Source shows | Mirror shows | Never |
|---|---|---|
| empty cell | empty cell | `0`, `-`, `n/a`, or any filler |
| `-` or `–` | the same dash | `0` or blank |
| `0` | `0` | blank or dash |

An empty cell is a deliberate statement by the preparer, not an omission for you
to repair. This extends to blank rows, blank label cells, blank figure cells and
blank lines between blocks — each is reproduced in place. Line count in equals
line count out, so an invented line and a dropped line are equally serious.

## 6. Flag taxonomy — these go in LOG 3, never in the mirror

**CRITICAL** — transposed digit (12,480→12,840); junk, mojibake or `???` where a
number belongs; comma-decimal confusion (`53,698,612,325,77`); malformed
punctuation near a sign (`-5,.358...`); missing parenthesis on a negative;
number split across two columns; EU-swapped separators (`1.234,56`); multiple
decimal points; internal space that changes magnitude; merge or symbol
detachment.

**MAJOR** — trailing junk after a number (`(60)- -"`); internal space trimmed
(`1 112`→`1112`); precision exceeding the declared currency precision;
bidi-mirrored bracket.

**ROUNDING** — a difference within the declared tolerance. Published statements
legitimately round; a rounding warning is not a defect.

Every flag names the page, the cell reference, the source text and the output
text. The cell is **not** highlighted in the mirror — the log carries it.
