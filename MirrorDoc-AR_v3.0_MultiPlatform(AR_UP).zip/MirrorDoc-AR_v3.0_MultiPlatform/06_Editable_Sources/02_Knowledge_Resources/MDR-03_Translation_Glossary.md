---
module: MDR-03
title: Glossary-first resolution, normalisation and regional variants
applies_to: MirrorDoc-AR v2.3
retrieval_keys: glossary, TMS, termbase, term, translation, translate, IFRS,
  GAAP, Arabic GAAP, financial reporting, AI translation, fallback, priority,
  Native, English, Excel, two columns, TMS HITS, verbatim, override, clitic,
  normalise, normalisation, tashkeel, alef, dialect, Egypt, Jordan, Gulf,
  jurisdiction, proper noun, unmapped, candidates, consistency, register
---

# MDR-03 — Glossary-first resolution, normalisation and regional variants

## 1. Resolution order — the TMS is the top priority

Every Arabic term is resolved in this order. Stop at the first hit.

| Tier | Source | Match | Logged as |
|---|---|---|---|
| 1a | **TMS Excel** | Exact string | TMS-EXACT |
| 1b | **TMS Excel** | Normalised (§2) | TMS-NORMALISED |
| 1c | **TMS Excel** | Clitic or article variant (§3) | TMS-DIALECT-VARIANT |
| 2 | IFRS_Fallback_Termbase | Normalised | IFRS-FALLBACK |
| 3 | **AI translation** | — | AI-TRANSLATED |

**Tier 1 always wins.** A TMS English is inserted **verbatim** — same words,
same spelling, same capitalisation — wherever the term occurs, including in the
middle of a sentence. It is never replaced by a rendering you consider better,
more idiomatic or more current. If you believe a TMS entry is wrong, apply it
anyway and say so in LOG 3; the glossary owner decides, not the agent.

**Tier 3 is real translation, not a placeholder.** When a term is in neither
file, translate it yourself in formal financial-reporting English: IFRS
terminology first, then the local Arabic GAAP or regulator usage for the file's
jurisdiction (Egyptian Accounting Standards, SOCPA for KSA, CBJ and JSC usage for
Jordan, and so on). Record every tier-3 rendering in LOG 3 as AI-TRANSLATED with
page and cell, so the reviewer can see exactly which terms are not yet
glossary-approved. No flag, marker or note appears in the mirror itself.

**No Arabic remains in the mirror** except entries the TMS marks
Do-Not-Translate. Proper nouns are rendered by their TMS entry or transliterated.

Match multi-word terms before their component words — longest match first.
"الأصول المتداولة" resolves to *Current assets* as one term; it is never split
into "الأصول" + "المتداولة".

## 1a. The TMS HITS table — why it exists and how to use it

A knowledge file uploaded to the agent is indexed for **semantic search**, not
queried as a table. Retrieval returns passages that look relevant; it does not
guarantee that the row for every term on the page comes back. On a glossary of
thousands of rows, some terms will be missed — and a missed TMS term silently
falls through to tier 3, which is the precise failure "TMS first" exists to
prevent.

So the ingestion flow reads the TMS Excel **as a table**, scans each batch's
source text deterministically (normalised, clitic-aware, longest match first),
and sends the results with the batch:

```
TMS HITS FOR THIS BATCH
| # | Native (source) | English -- insert VERBATIM | Tier |
| 1 | الأصول المتداولة | Current assets | TMS-EXACT |
| 2 | والنقد | Cash | TMS-DIALECT-VARIANT |
```

Apply every row of that table first. It is authoritative. Consult the TMS
knowledge file as well for anything the table does not cover, but never let a
retrieved passage override a TMS HITS row. After the reply, the flow checks that
every TMS HITS English appears verbatim in the output; a paraphrase fails the
batch.

If the TMS HITS table is missing from a batch, the pre-pass did not run. Say so,
fall back to the TMS knowledge file, and record TMS-PREPASS-MISSING in LOG 3.

## 1b. The TMS Excel format

Two columns are enough: **Native** and **English**.

- Columns are found by their header label, not their position. Accepted labels
  include Native, Arabic, Arabic_Term, Source, المصطلح for the Arabic side and
  English, English_Term, Target, Translation for the English side.
- A sheet with no header row and exactly two columns is read as native, then
  English.
- The sheet named Glossary is used if present, otherwise the first sheet.
- Rows missing either side are skipped and counted.
- A native term appearing twice with **different** English is reported as
  TMS-DUPLICATE and is not resolved by picking one. Fix it in the Excel.
- Extra columns (jurisdiction, domain, notes) are optional. Without them every
  entry applies to every jurisdiction.

## 2. Normalisation for lookup only

Applied to the **lookup key**, never to delivered text:

- strip tashkeel (U+0610–061A, U+064B–065F, U+0670, U+06D6–06ED) and tatweel (U+0640)
- unify alef forms: أ إ آ ٱ → ا
- unify ta marbuta: ة → ه
- unify alef maqsura: ى → ي
- remove bidi and zero-width controls (U+200B–200F, U+202A–202E, U+2066–2069, U+FEFF)
- collapse whitespace, case-fold the Latin side

Without this, a term that differs only by a diacritic misses the glossary and
falls through to the fallback tier — which is how an approved rendering silently
becomes an unapproved one.

## 3. Attached prepositions (clitics)

Arabic attaches prepositions and conjunctions to the word, so a TMS term rarely
appears on the page in its dictionary form. "النقد" is in the TMS; the page says
"والنقد" (and the cash), "بالنقد" (in cash) or "للنقد" (for the cash).

For lookup, these prefixes are removed and the article restored:

| Page form | Prefix | Looked up as |
|---|---|---|
| والنقد | و + ال | النقد |
| فالنقد | ف + ال | النقد |
| بالنقد | ب + ال | النقد |
| كالنقد | ك + ال | النقد |
| للنقد | ل + ال (alef elided) | النقد |

**Only prefixes that carry the article are stripped.** A bare leading و or ب is
frequently part of the word: "ودائع" means *deposits*, and stripping its waw
would look up "دائع", which is wrong. This is also a lookup rule only — the
English inserted is the TMS English, and the conjunction is translated normally
around it ("and Cash").

## 4. Consistency and jurisdiction

**One term → one English for the whole session.** Once a term is rendered —
from the TMS, the termbase or your own tier-3 translation — that rendering is
locked. If a later source variant would map differently, keep the
locked rendering and log TERM-CONFLICT.

**Jurisdiction guard.** A rendering scoped to one country must not be applied to
another country's file. Egyptian filings commonly use قائمة المركز المالي where
Gulf filings use الميزانية العمومية; both render as "Statement of financial
position", but the entry must match the file's jurisdiction or be flagged.

Watch these regional traps in particular:

| Native | Region | English | Note |
|---|---|---|---|
| إهلاك | EG / Levant | Depreciation | |
| الاستهلاك | Gulf / KSA | Depreciation | Literally "consumption"; do not render as such |
| إطفاء | all | Amortisation | Distinct from depreciation |
| ضريبة المبيعات | JO | Sales tax | Not "VAT" unless the source says القيمة المضافة |
| زكاة | KSA | Zakat | Retain the term; not "tax" |
| أوراق قبض / دفع | EG / Levant | Notes receivable / payable | |

## 5. Scope and register

Translate ALL text: headings, captions, notes, footnotes, stamps, seals, labels,
and the contents of running headers and footers. No native text remains except
proper nouns, which are rendered by the TMS entry or transliterated.

Tone: formal financial-reporting / IFRS register. Translate in place, cell for
cell. Never reorder lines, never turn numbers into words, never alter numeric
meaning, and never "improve" a clumsy source phrasing.

## 6. What the reviewer receives

At the end of every batch, LOG 3 carries a **TMS CANDIDATES** table: every term
translated at tier 3 this session, with the English used. It is formatted to be
pasted straight into the TMS Excel after review, so the glossary grows from real
documents and the tier-3 share falls over time.

A falling AI-TRANSLATED count is the measure of glossary health. A document with
many tier-3 terms is not a failed conversion — it is a glossary that needs work,
and the log tells you exactly where.
