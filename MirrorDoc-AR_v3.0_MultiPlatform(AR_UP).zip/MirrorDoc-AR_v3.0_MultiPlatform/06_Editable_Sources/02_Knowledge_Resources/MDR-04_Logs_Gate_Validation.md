---
module: MDR-04
title: Totals validation, the three logs and the release gate
applies_to: MirrorDoc-AR v2.3
retrieval_keys: log, LOG 1, LOG 2, LOG 3, fidelity, parity, validation, total,
  subtotal, vertical, horizontal, cross-foot, balance, tolerance, gate, verdict,
  tick, cross, delta, mismatch, column map
---

# MDR-04 — Totals validation, the three logs and the release gate

## 1. The reporting rule that governs this whole module

These checks produce LOG 2. **They never change the mirror.** You re-compute in
order to REPORT, not in order to correct.

If the source prints no total on a row, the mirror has no total on that row. Do
not compute one, infer one, or "complete" the table. LOG 2 records *"no total
present in source"* for it. This holds even when the arithmetic is obvious and
even when every other row in the table has one. An arithmetically correct
insertion is still a defect, because it is text the source does not contain.

Never alter a value to force a total to match. The mismatch **is** the
deliverable.

## 2. Four checks on every table and every block

| Scope | What it proves |
|---|---|
| VERTICAL | Each subtotal and total against its component rows, once per column |
| HORIZONTAL | Each row's component columns against its total column |
| CROSS-FOOT | The corner cell reached both ways — a difference means a whole row or column was dropped |
| BALANCE | Where applicable: Assets = Liabilities + Equity |

Vertical footing alone is not enough. It proves the surviving rows are
self-consistent; it cannot detect a row that was never transcribed, because the
total was re-computed from what *was* transcribed. Cross-footing is what exposes
the loss.

**Status:** MATCH → tick. |delta| ≤ declared rounding tolerance → ROUNDING
warning. Otherwise → MISMATCH cross, with the exact delta.

A table with no totals in the source is logged as "no totals present in source",
never omitted from the log.

## 3. LOG 1 — PDF fidelity parity

One row per page:

`| Page | Lines src/out | Tables src/out | Rows src/out | Cols src/out | Header src/out | Footer src/out | Orientation | Wide-table method | Page verdict |`

Tick where source equals output, cross where not, then a TOTAL row reading
"X/N pages". Blank lines count as lines. A page whose header or footer was
dropped, invented or placed inline fails the page.

LOG 1 also carries the **COLUMN MAP** for every table: the folded `" - "` header
form from MDR-01 §3. That form exists here and nowhere else.

## 4. LOG 2 — table validation

`| Table | Scope | Label | Expected | Reported | Delta | Status |`

Scope is VERTICAL / HORIZONTAL / CROSS-FOOT / BALANCE. Every table appears.

## 5. LOG 3 — QC and term flags

`| Page | Cell/Ref | Flag | Severity | Source text | Output text |`

Carries: number-QC flags (MDR-02 §6); ILLEGIBLE regions with page and
location; PREPROCESS-MISSING pages; and the terminology flags below.

| Flag | Meaning |
|---|---|
| AI-TRANSLATED | Tier 3: in neither the TMS nor the termbase, translated by the agent |
| AI-OVERRIDE-BLOCKED | The agent's own rendering differed from the TMS; the TMS was applied |
| TMS-DUPLICATE | The TMS maps one native term to two different English terms |
| TMS-PREPASS-MISSING | The batch arrived without its TMS HITS table |
| TERM-CONFLICT | A later variant would map differently from the locked rendering |
| JURISDICTION-MISMATCH | A country-scoped TMS entry met a file from another country |

### TMS CANDIDATES

After LOG 3, list every AI-TRANSLATED term of the session:

`| Native | English (AI proposal) |`

Formatted for review and pasting into the TMS Excel.

### Terminology line

One line summarising where every term came from:

`Terms: TMS n1 · termbase n2 · AI-translated n3 · TMS hits applied verbatim X/Y`

"TMS hits applied verbatim" is checked by the flow after the reply: every English
in the batch's TMS HITS table must appear in the output exactly as written. A
figure below Y/Y fails the batch — it means an approved term was paraphrased.

## 6. Closing line and gate

After the three logs: total pages, total tables, total checks, counts of
CRITICAL / MAJOR / ROUNDING flags, the terminology line, and the overall verdict.

The gate is **computed, not attested**. The agent's self-check is a first line
of defence and catches real errors, but release is governed by the computed gate
in Fidelity_and_Validation_Log_TEMPLATE.xlsx and by a human sign-off on the
items that cannot be computed. A model's report about its own reliability is not
evidence of its reliability. Report what you did; do not certify it.
