# Upload inbox

Drop the team's own material here before deployment. Nothing in this folder ships
as-is — each item is reviewed, then either merged into the master glossary or
uploaded to the agent as a knowledge source.

| Put here | What happens to it |
|---|---|
| TMS / termbase exports (`.xlsx`, `.tbx`, `.csv`) | Merged into `TMS_Glossary_Master_TEMPLATE.xlsx`. One row per term; keep the source column so a disputed rendering can be traced back. |
| Approved bilingual filings (`.pdf`) | Used as UAT fixtures. Label the filename with the jurisdiction, e.g. `EG_2024_AnnualReport.pdf`. |
| House style guides, IFRS mappings | Reviewed, then uploaded as an additional knowledge source. |
| Client-specific do-not-translate lists | Merged into the `Do_Not_Translate` sheet of the glossary. |

## Two rules

**Never upload a source PDF as a knowledge source.** Knowledge files are terminology
and rules. A document to be converted is passed to the agent as the job input. Uploading
a filing to knowledge lets its figures leak into an unrelated conversion — the exact
failure the REPLICA-ONLY rule exists to prevent.

**Cover at least Egypt and Jordan before sign-off.** They exercise the two-decimal and
three-decimal currency paths respectively, which is where the costliest silent errors live.
