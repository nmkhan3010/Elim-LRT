# Number Format Rules — the deterministic contract

> **Scope note.** The normative statement of numeric rules is
> MDR-02_Numbers_Currency_QC.md. This file exists for a different purpose: it maps
> those rules onto the code that enforces them, so an engineer can find the
> function behind a rule. The worked examples below are test vectors, not a second
> rulebook. If this file and MDR-02 diverge, MDR-02 is the rule and the code is the
> enforcement; this file is the one to correct.

These rules are implemented in `03_Validation_QC/validators/mirrordoc_core.py`
(`parse_number`). The agent's prompt describes them; the code enforces them. Where the two
ever disagree, **the code is authoritative** and the prompt is the defect.

## Conversion order (order is not optional)

1. Repair bidi-mirrored brackets `﴾ ﴿` → `( )`.
2. Strip zero-width and directional control characters.
3. Convert Arabic-Indic and Extended Arabic-Indic digits to Western.
4. Convert `٫` → `.` **before** `٬` → `,` — once both are ASCII they are indistinguishable.
5. Detect and normalise the sign.
6. Resolve separators using the declared currency precision.
7. Validate precision against the currency.

## Sign handling

| Source form | Interpretation | Flag |
|---|---|---|
| `(1,234)` | −1,234 | none |
| `1,234-` | −1,234 | `TRAILING-MINUS-MOVED` (MAJOR) |
| `-1,234` | −1,234 | none |
| `(1,234` | −1,234, brackets unbalanced | `UNBALANCED-PARENTHESIS` (CRITICAL) |

## Separator resolution

| Source | Currency | Result | Flag |
|---|---|---|---|
| `12,345` | any | 12345 | none |
| `1 234 567` | any | 1234567 | `SPACE-THOUSANDS-SEPARATOR-PRESERVED` |
| `46 3` | any | 463, magnitude at risk | `INTERNAL-SPACE-REPAIRED` (CRITICAL) |
| `1,234.567` | JOD/KWD/BHD/OMR | 1234.567 | none |
| `1234.567` | SAR/EGP | 1234.567 | `PRECISION-EXCEEDS-2DP` (MAJOR) |
| `1.234,56` | any | 1234.56 | `SWAPPED-SEPARATORS-EU-STYLE` (CRITICAL) |
| `53,698,612,325,77` | any | flagged | `MALFORMED-THOUSANDS-GROUPING` (CRITICAL) |
| `1.234.56` | any | flagged | `MULTIPLE-DECIMAL-POINTS` (CRITICAL) |

Only groups of **exactly three digits** count as space-separated thousands. Any other internal
space is OCR damage and is CRITICAL, because repairing it may change the magnitude.

## Cells that are not numbers

A dash, an em-dash or a blank cell is **not zero**. Reproduce the placeholder exactly as
printed. Turning a dash into 0 changes every total that cell feeds and produces a table that
foots perfectly while being wrong.

## Severity

- **CRITICAL** — magnitude, sign or identity of the value is in doubt. Must be resolved before
  delivery.
- **MAJOR** — presentation is wrong but the value is recoverable. May ship with a logged note.
- **ROUNDING** — a total differs from its recomputed value by no more than the declared
  tolerance. Published statements legitimately round; this is a warning, not a defect.
