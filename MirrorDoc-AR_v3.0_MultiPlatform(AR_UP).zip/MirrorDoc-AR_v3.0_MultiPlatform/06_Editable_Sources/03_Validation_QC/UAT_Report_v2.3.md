# UAT Report — MirrorDoc-AR v2.1

**Executed:** 13 August 2026 · **Harness:** `validators/run_uat.py` · **Engine under test:** `validators/mirrordoc_core.py`

**Result: 170 of 170 cases passed, 0 failed. Gate: ALL-PASS.**


## 1. What this UAT does and does not prove

Each case below encodes one rule from the agent instructions. The harness runs the
deterministic engine — not the language model — because the engine is the layer that
*enforces* these rules. A model asked to be deterministic is not a control; code is.

**This UAT proves:** every deterministic rule behaves as the instructions describe, on
adversarial inputs constructed to break it.

**This UAT does not prove:** translation quality, OCR accuracy on a given scan, or that the
model follows its prompt. Those need real filings and human review — see §5.

## 2. Results by group

| Group | Cases | Passed | What it covers |
|---|---|---|---|
| A. Normalisation | 12 | **12** | Diacritics, alef/ta-marbuta/alef-maqsura unification, tatweel, bidi controls, Arabic-Indic and Extended digits, U+066B/066C/066A separators |
| B. Glossary-first | 12 | **12** | Five-tier resolution order, normalised matching, jurisdiction scoping, one-term-to-one-English ledger, unmapped flagging |
| C. Number-QC | 20 | **20** | Signs, separators, three-decimal currencies, space thousands, EU-swapped separators, mojibake, bidi brackets, placeholders |
| D. Umbrella headers | 11 | **11** | Multi-level folding, rowspan pass-down, leaf-count parity, joiner uniqueness and round-trip safety |
| E. Side-by-side | 6 | **6** | RTL-logical block ordering, LTR override, row banding, gutter detection |
| F. Totals validation | 17 | **17** | Vertical, horizontal, cross-foot and balance checks; tolerance states; missing rows; no-value-alteration |
| G. Fidelity log | 7 | **7** | Per-page line/table/row/column parity, orientation recording, rendered log integrity |
| H. Batching | 7 | **7** | Weight budget, hard page cap, full page coverage, never splitting a table |
| **Total** | **92** | **92** | |

## 3. Defects found and closed during the run

Four defects surfaced while building and running this UAT. All four are closed. They are
recorded because a UAT that reports only successes is not evidence that it was run.

| ID | Where | Defect | Resolution |
|---|---|---|---|
| UAT-DEF-001 | `run_uat.py` case H-02 | The test asserted that four wide/nested pages fit one batch. Four pages at weight 4 is 16, which exceeds the 15-unit budget; the engine correctly capped at three. | Expectation corrected. **The engine was right and the test was wrong** — worth stating plainly, because the opposite assumption would have loosened a working control. Case H-07 was added to prove the same eight pages batch differently when classified as narrative. |
| UAT-DEF-002 | `Fidelity_and_Validation_Log_TEMPLATE.xlsx`, LOG 2 | "Checks run" reported 200 on a sheet containing 5 checks. `COUNTIF(range,"<>")` counts formula cells returning an empty string. | Replaced with the sum of the three status counts. Now reports 5. |
| UAT-DEF-003 | Release gate sheet | The LOG 1 rollup pointed at row 70 (parity rate) instead of row 71 (gate), displaying `1` where PASS/BLOCKED was expected. | Reference corrected to B71. |
| UAT-DEF-004 | Release gate sheet | The LOG 2 rollup pointed at row 210 (mismatch count) instead of row 212 (gate), displaying `2`. | Reference corrected to B212. |

DEF-002 through DEF-004 are worth a note beyond their individual fixes. The workbook
recalculated with **zero formula errors** in all three states. A clean recalculation proves
formulas *evaluate*; it does not prove they compute the *right* thing. The defects were found
only by reading the computed values against hand-worked expectations — which is the same
discipline this whole package asks of the agent's output, and the reason the release gate
requires a human to sign the items that cannot be computed.

## 4. Notable cases

These are the ones that would have shipped a wrong number.

| Case | Input | Wrong behaviour it prevents |
|---|---|---|
| C-07 / C-08 | `1,234.567` in a **JOD** table | A last-two-digits decimal heuristic rescales this by 1,000 or truncates a fils. The result looks entirely plausible. |
| A-09 / A-10 | `١٢٣٤٫٥٦` with U+066B | Stripping the separator instead of converting it yields 123456 — a hundred-fold error with every digit still correct. |
| C-11 / C-12 | `1.234,56` | EU-style separators read as a thousands group give 123456 rather than 1234.56. |
| C-05 vs C-06 | `1 234 567` vs `46 3` | The first is a legitimate Egyptian/Levantine thousands separator; the second is OCR damage. Treating them alike destroys one or the other. |
| E-01 | Two blocks on an RTL page | Left-first ordering inverts the source's own reading order on every side-by-side page. |
| F-14 | Vertical total 1,450 vs horizontal 1,000 | A whole dropped row. Vertical footing alone passes this, because the total was recomputed from what survived. |
| D-08 / D-09 | `Non-current assets` under a year header | A naive `" - "` split would read three header levels where there are two. |
| C-19 | A dash placeholder | Reading it as zero produces a table that foots perfectly and is wrong. |

## 5. What still needs human validation before go-live

The automated suite cannot reach these. They are the acceptance criteria for the pilot.

1. **Translation quality** on a real filing, reviewed by a native Arabic financial translator.
2. **OCR accuracy** on your actual scan quality — particularly stamped, faint or annotated pages.
3. **Glossary coverage**: run a real document and count `[TERM-UNMAPPED]` flags. A high count is
   not a system failure; it is the termbase telling you what it is missing.
4. **Prompt adherence**: does the model actually follow the instructions? Verify on at least one
   Egyptian and one Jordanian filing, since those exercise the two-decimal and three-decimal
   paths.
5. **Rounding tolerance calibration**: start at zero, observe warning volume on real filings,
   raise deliberately with a recorded rationale.
6. **End-to-end timing** at your largest expected document size.

## 6. Engine-rendered sample logs

Produced by the engine during the run, not hand-written.

### LOG 1 — page fidelity


| Page | Lines src/out | Tables src/out | Rows src/out | Cols src/out | Orientation | Page verdict |
|---|---|---|---|---|---|---|
| 1 | 42/42 ✅ | 1/1 ✅ | 18/18 ✅ | 7/7 ✅ | portrait->portrait | ✅ |
| 2 | 55/55 ✅ | 2/2 ✅ | 30/30 ✅ | 13/13 ✅ | portrait->portrait | ✅ |
| 3 | 40/39 ❌ | 1/1 ✅ | 20/20 ✅ | 7/6 ❌ | landscape->portrait | ❌ |
| **TOTAL** | | | | | | **2/3 pages ❌** |

Page 3 fails on two dimensions: one line and one column lost, on a page that was also
rotated from landscape to portrait — which is exactly the correlation the log exists to expose.

### LOG 2 — table validation

| Scope | Label | Expected | Reported | Delta | Status | |
|---|---|---|---|---|---|---|
| VERTICAL | Total current assets [col 1] | 7,000 | 7,000 | 0 | MATCH | ✅ |
| VERTICAL | Total current assets [col 2] | 6,300 | 6,400 | 100 | MISMATCH | ❌ |
| HORIZONTAL | Revenue | 1,000 | 1,000 | 0 | MATCH | ✅ |
| HORIZONTAL | Expenses | 450 | 450 | 0 | MATCH | ✅ |
| CROSS-FOOT | Grand total | 1,450 | 1,000 | -450 | MISMATCH | ❌ |
| BALANCE | Assets = Liabilities + Equity | 10,000 | 10,000 | 0 | MATCH | ✅ |
| **TOTAL** | 6 checks | | | | **2 failed** | ❌ |

The cross-foot mismatch of −450 is the signature of a dropped row: the vertical total is
reachable and correct, the horizontal total is not, and the difference is the missing row's
value. No value was altered to reconcile them.

## 7. Reproducing this run

```
cd 03_Validation_QC/validators
python3 run_uat.py            # human-readable report
python3 run_uat.py --json     # machine-readable, exit code 1 on any failure
```

Wire `run_uat.py` into CI as a merge gate on `mirrordoc_core.py`. A change to the engine that
breaks a case is a change to a rule the agent instructions depend on, and should not merge
silently.


---

# Appendix — v2.1 addendum (44 cases added)

Version 2.1 added five groups, all of them encoding the replica-discipline rules. Each case is
written so that it **fails if the agent is allowed to be helpful** — that is the property being
protected.

| Group | Cases | What it protects |
|---|---|---|
| I. Span headers | 12 | A label printed once in the source is printed once in every delivered layer. Asserts the merged form (.docx), the blank-continuation form (screen) and the folded `" - "` form (LOG 1 only) all resolve to the same leaf count, and that the folded form is **not** what the mirror renders. |
| J. Zero annotation | 9 | The mirror rejects highlights, HTML styling, ticks, crosses, severity words, translator notes and every bracketed marker. J-09 asserts Arabic body text is not mistaken for an annotation, so the guard cannot be satisfied by refusing to emit Arabic. |
| K. Blank preservation | 9 | A blank cell filled with `0` is INVENTED, not a courtesy. A dash is not zero. An empty source line stays empty. Dropped content and invented content are reported as equally serious. |
| L. No synthesised totals | 5 | L-04 is the important one: an **arithmetically correct** total inserted into a row the source leaves empty is still a release blocker. L-05 asserts the validator still *reports* on totals that do exist — reporting is not writing. |
| M. Headers and footers | 9 | Dropped, invented and inline-placed running furniture all fail. An automatic page-number field fails, because a field regenerates and can diverge from the number the PDF prints. A page with no header or footer passes. |

## Defect found during the v2.1 run

`L-05` initially failed against a mis-remembered `validate_vertical` signature — the test passed
a list of total rows where the function takes a `subtotal_map`. The test was wrong, not the
engine, and it was corrected. Worth recording because it is the failure mode this harness exists
to catch in the opposite direction: a test written against an assumed interface proves nothing
about the real one.

## Still not proven by any of this

The harness exercises deterministic code. It cannot prove the model obeys the instructions that
call that code. Two things must be checked by hand on the first real documents:

1. Open the produced .docx and confirm the running header is in the Word header, not the body.
2. Find a page where the source leaves a total cell empty, and confirm the output leaves it empty.


---

# Appendix — v2.3 addendum (34 cases added, group N)

Group N encodes the terminology priority: **TMS first, termbase second, AI last**. Every
case is written to fail if the model's own preference can beat the TMS.

| Area | Cases | What it proves |
|---|---|---|
| Two-column TMS | N-01 – N-07 | A Native/English sheet loads; columns are found by **label** not position; Arabic header labels work; headerless two-column sheets work; blank rows are skipped and counted; a native term mapped to two different English terms is **reported, not guessed**. |
| Priority | N-08 – N-11 | TMS beats the termbase for the same term. TMS beats the AI — the AI proposal is discarded and the attempt logged AI-OVERRIDE-BLOCKED. The termbase beats the AI for terms the TMS lacks. |
| AI tier | N-12 – N-16 | A term in neither file gets the AI translation, flagged AI-TRANSLATED, locked for the session so page 190 matches page 3, and listed as a TMS candidate. No AI rendering → unmapped, never blank. |
| Pre-pass | N-17 – N-25 | Longest match wins. A term mid-sentence is found. و+ال / ب+ال prefixed forms resolve to the TMS term; a bare leading waw is **not** stripped (ودائع = deposits). A paraphrased or re-cased TMS term fails the verbatim check. |
| Residual Arabic | N-26 – N-27 | Arabic left in the English mirror is detected. |
| Excel | N-28 | A real two-column .xlsx loads end to end. |
| Punctuation | N-29 – N-34 | A TMS term followed by Arabic ، ؛ ؟ or ۔ is still found; a paraphrase of it is then caught; Arabic-Indic digits are not absorbed into a term. |

## Defect found by the worked example

Running the engine on a realistic sentence returned three TMS hits instead of four. The
Arabic comma sits inside the Arabic Unicode block, and the tokeniser covered the whole
block, so "والمخزون،" carried its comma and never matched the TMS entry "المخزون". Every
TMS term followed by Arabic punctuation was falling through to AI translation, silently.

None of the preceding 164 cases put punctuation after a term, which is why all of them
passed. The tokeniser now matches letters and marks only. N-29 to N-34 were each confirmed
to fail against the old code before being accepted. See Worked_Example_TMS_First.docx.

## Negative control

The priority test was checked against a deliberately broken engine in which the AI
rendering always wins. N-09 failed against it, as it should. A test that passes against
the defect it guards against proves nothing; this one does not.

## Still not proven

The harness tests the deterministic pre-pass and resolver. It cannot prove the model
applies the TMS HITS table — only that the flow can detect when it did not. Run question 5
in PASTE_03 §D on the live agent: offer it a "better" alternative to a TMS term and
confirm it refuses.
