# Worked example — TMS first, then termbase, then AI

This is a real run of the v2.3 engine on a glossary in the business's own format: an Excel
sheet with **two columns, Native and English**. Nothing below is illustrative — it is the
engine's actual output, reproduced so the team can see what each stage produces.

## 1. The glossary

| Native | English |
|---|---|
| الأصول المتداولة | Current assets |
| النقد وما في حكمه | Cash and cash equivalents |
| الذمم المدينة التجارية | Trade receivables |
| المخزون | Inventories |
| الأصول | Assets |

Loaded: **5 terms**, header on row 1, Native = column 1,
English = column 2, duplicates 0.

## 2. The source sentence

`تتضمن الأصول المتداولة النقد وما في حكمه والذمم المدينة التجارية والمخزون، إضافة إلى الصكوك ومخصص الخسائر الائتمانية المتوقعة.`

## 3. Tier 1 — the TMS pre-pass

The flow scans the sentence against the Excel and sends the agent this table:

| # | Native (source) | English -- insert VERBATIM | Tier |
|---|---|---|---|
| 1 | الأصول المتداولة | Current assets | TMS-EXACT |
| 2 | النقد وما في حكمه | Cash and cash equivalents | TMS-EXACT |
| 3 | والذمم المدينة التجارية | Trade receivables | TMS-DIALECT-VARIANT |
| 4 | والمخزون | Inventories | TMS-DIALECT-VARIANT |

Note three things. "الأصول المتداولة" matched as **Current assets**, not as "Assets" plus a
leftover word — longest match wins. "والذمم" matched through its attached **و + ال** prefix.
And "والمخزون،" matched despite the Arabic comma glued to it — see section 7.

## 4. Tier 2 — the termbase

`الصكوك` is not in the TMS. The termbase has it as **Sukuk**. The model proposed
"Islamic bonds"; the proposal was discarded because the termbase outranks the AI.

## 5. Tier 3 — AI translation

`مخصص الخسائر الائتمانية المتوقعة` is in neither file. The model translated it in IFRS 9
register as **Provision for expected credit losses**, flagged **AI-TRANSLATED**, and locked it for the session.

## 6. The mirror, and the checks on it

**Output:** Current assets include Cash and cash equivalents, Trade receivables and Inventories, in addition to Sukuk and the Provision for expected credit losses.

- Verbatim check: **4/4** TMS hits applied — **PASS**
- Residual Arabic: **none**

**A paraphrased reply,** for contrast: Current assets include cash and equivalents, Trade receivables and Stock, in addition to Sukuk and the Provision for expected credit losses.

- Verbatim check: **2/4** — **FAIL**. Missing: Cash and cash equivalents, Inventories

"cash and equivalents" and "Stock" are both reasonable English. Both are wrong here, because
the glossary says otherwise, and the check catches both. This is the difference between an
instruction to follow the TMS and a test that the TMS was followed.

## 7. The bug this example found

The first run of this example returned **three** TMS hits, not four. *Inventories* was
missing, and so the paraphrase "Stock" passed unnoticed.

The source reads "والمخزون،". The Arabic comma ، (U+060C) sits inside the Arabic Unicode
block, and the tokeniser's character class covered the whole block, so the comma was glued
onto the word and "المخزون،" never matched "المخزون". Every TMS term followed by Arabic
punctuation — comma, semicolon, question mark, full stop — was silently falling through to
AI translation. In a real financial statement that is a large share of all terms.

The tokeniser now matches Arabic letters and marks only. Six regression tests (N-29 to N-34)
cover the four punctuation marks, the paraphrase case, and digits; each was confirmed to fail
against the old code before being accepted. None of the 164 tests before it would have caught
this, because none of them put punctuation after a term.

## 8. What goes to the glossary owner

TMS CANDIDATES (AI-translated this session -- review, then add to the TMS)
| Native | English (AI proposal) |
|---|---|
| مخصص الخسائر الائتمانية المتوقعة | Provision for expected credit losses |
