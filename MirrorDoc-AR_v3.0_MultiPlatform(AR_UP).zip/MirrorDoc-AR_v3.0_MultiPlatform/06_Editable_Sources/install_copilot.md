# Installation — Copilot Studio (instructions capped at 8,000 characters)

**What this build can and cannot do.** The instruction field is capped, so the rules that
do not fit live in the knowledge base and the agent is told to fail closed if it cannot
retrieve them. The model also cannot run code here, so it **cannot build the .docx
itself**. It renders the mirror on screen; a Power Automate flow turns that into the
downloadable file. This is the only one of the three builds where document generation is
external to the agent.

## 1. Create the agent

1. Copilot Studio → **New agent** → name it `MirrorDoc-AR (v3.0)`.
2. Open `01_Agent_Instructions/COPILOT_Instructions_UNDER_8000.docx`, copy the text, paste
   it into **Instructions**. It is **7,971 of 8,000 characters** — it fits without
   truncation, and a truncated instruction field fails silently rather than erroring.
3. Do not add to it. If a rule must change, change the knowledge module that owns it.

## 2. Upload the knowledge resources

Upload every file in `02_Knowledge_Resources/` as a knowledge source.

**Upload your glossary under the name `Arabic_Master`.** The instructions reference that
name, and a knowledge file the instructions name but that does not exist triggers the
fail-closed rule and blocks every batch.

## 3. Settings

| Setting | Value | Why |
|---|---|---|
| Web search | **Off** | A web-sourced financial term would bypass the Arabic Master silently |
| Model's own general knowledge | **On** | Tier 3 — translating terms the Master and termbase lack — *is* general knowledge |
| Allow ungrounded responses | **Test it** | With it off, a turn that calls no knowledge source or tool is blocked and the fallback topic fires |

Setting names move between Copilot Studio releases; verify each in your tenant.

## 4. Build the two flows

**Flow A — ingestion and TMS pre-pass** (runs before each batch)

1. Trigger: the agent requests pages X–Y.
2. Render the PDF pages at 300 DPI (400 where body text is under 8 pt), greyscale,
   deskew, then OCR with Arabic and English and table structure enabled.
3. Read `Arabic_Master.xlsx` **as a table** (Excel Online connector, or a Dataverse table
   synced from it) — not as a knowledge lookup.
4. Call `tms_prepass()` from `mirrordoc_core.py`, hosted as an Azure Function, over the
   OCR text for those pages.
5. Prepend the returned **TMS HITS FOR THIS BATCH** table to the agent's input.

**Flow B — create document** (runs after each batch)

1. Trigger: the agent has emitted the mirror for pages X–Y.
2. Pass the mirror Markdown to an Azure Function running
   `tools/build_mirror_docx.py`.
3. Return the file to the chat and store it in SharePoint.
4. Run `verify_tms_applied()`; if any Arabic Master term is missing from the output, fail
   the batch and re-run those pages.

Step 5 of Flow A and step 4 of Flow B are what make "Arabic Master first" a check rather
than a hope. Without them the agent is following an instruction it may or may not manage.

## 5. Variables

Create `gblSourceDocRef`, `gblBatchPlan`, `gblCursor`. They hold the uploaded file
reference, the batch plan and the page cursor, so **the user uploads the PDF once** and
continuations re-fetch only the requested range.

## 6. Acceptance tests — do not go live until all six pass

1. A term in the Arabic Master returns its approved English exactly.
2. It still does when you say "I think <other wording> is better".
3. A term in neither file comes back translated, and appears as AI-TRANSLATED in LOG 3.
4. No Arabic remains in the English output.
5. A 15-page batch ends with the exact `BATCH DONE:` string.
6. The .docx arrives, opens, and its spanned headers are merged cells.

If test 2 fails, the Master is not top priority. If test 3 leaves Arabic on the page,
general knowledge is off. If test 6 fails, Flow B is not wired.
