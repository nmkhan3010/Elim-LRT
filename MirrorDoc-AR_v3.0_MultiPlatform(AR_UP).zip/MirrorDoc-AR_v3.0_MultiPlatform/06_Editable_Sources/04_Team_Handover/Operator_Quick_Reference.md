# MirrorDoc-AR — Operator Quick Reference

One page. Keep it open while you run a document.

---

## Running a document

1. Upload the Arabic PDF **once**. The agent binds it to the session.
2. Read the **inventory contract** it returns: page count, jurisdiction, currency, per-page
   manifest, batch plan. **Check the currency and jurisdiction before you continue** — they
   drive decimal precision, and a wrong currency is the fastest route to a wrong number.
3. Confirm or amend the plan.
4. For each batch, reply `next`. For a specific range, `continue 16-30`.
5. At the end, save the .docx and the three logs.

**Never re-upload the PDF mid-session.** If the agent asks you to, the session lost its file
handle — start over rather than uploading again, or the batch plan and term ledger reset
silently.

---

## What the agent's replies should look like

| Situation | Expected ending |
|---|---|
| More pages remain | `BATCH DONE: pages X-Y of N delivered. To continue: reply 'next'…` |
| Finished | `ALL PAGES 1-N DELIVERED. Compare source pages X-Y…` |

If a reply ends any other way, or ends mid-table, treat the batch as incomplete and re-request
that range. A truncated table is the failure mode that looks most like success.

---

## Flags you will see, and what to do

| Flag | Means | Do |
|---|---|---|
| `AI-TRANSLATED` in LOG 3 | Term was in neither the TMS nor the termbase | Review the TMS CANDIDATES table; add approved terms to the TMS. **Do not** fill it in yourself in the .docx |
| `[ILLEGIBLE - page X, loc]` | OCR could not read it | Check the source page; if legible to you, re-scan at higher DPI |
| `[PREPROCESS-MISSING - page X]` | Page arrived without OCR structure | Ingestion problem — raise with AI Engineering |
| `TERM-CONFLICT` | A term mapped two ways; first rendering locked | Log it; the glossary has a duplicate |
| `JURISDICTION-MISMATCH` | A country-scoped term used outside its country | Verify the jurisdiction set at inventory |
| Number-QC `CRITICAL` | Magnitude, sign or identity in doubt | **Must be resolved before delivery** |
| Number-QC `MAJOR` | Presentation wrong, value recoverable | May ship with a logged note |
| `ROUNDING` on a total | Within declared tolerance | Normal for published statements — not a defect |
| `MISMATCH` on a total | Outside tolerance | Escalate. **Never edit the value to make it foot** |

---

## The rule that matters most

**Never correct the source.** If the issuer's table does not foot, ours does not foot either,
and the log records the difference. Silently fixing it turns a mirror into a fabrication and
hides a finding the client may need.

---

## Before you release

Open `Fidelity_and_Validation_Log_TEMPLATE.xlsx` → **RELEASE GATE** sheet.

- All three log gates must read **PASS**.
- Tick every manual sign-off item.
- Spot-check 5% of pages against the source PDF.
- Sign and date.

A computed PASS is not a release. Your signature is.

---

## Escalation

| Problem | Owner |
|---|---|
| Missing or wrong terminology | Translations Lead |
| OCR quality, agent behaviour, flow failures | AI Engineering |
| Tolerance settings, gate policy, sign-off disputes | QC Lead |


---

## v2.3 — what you should now see, and what you should never see

**In the .docx you send on:**

- Running headers and footers in the Word header and footer, matching the source page.
- Spanned headers as merged cells — a label the PDF prints once appears once.
- Blank cells, blank rows and blank lines exactly where the source has them.
- No total on a row where the source prints no total.

**If you see any of these, reject the output and raise it — the agent has edited the document:**

| Symptom | What it means |
|---|---|
| A highlighted or coloured cell | Annotation leaked into the mirror |
| `[TERM-UNMAPPED]`, `[ILLEGIBLE]` or any bracketed marker | Same — these belong in LOG 3 |
| A tick, cross or the word MISMATCH in the body | The QC report leaked into the deliverable |
| A total where the source page shows an empty cell | A figure was computed and inserted |
| A parent header repeated across its columns | The span was folded instead of merged |
| "continued" on a long table | Added text, unless the source prints it |
| The running header repeated in the body text | Header placed inline instead of in the Word header |

## v2.3 — where every English term comes from

1. **Your TMS Excel first, always.** A TMS term appears exactly as written in the glossary —
   same words, same capitalisation — even in the middle of a sentence.
2. **The IFRS termbase** for terms your TMS does not have.
3. **AI translation last**, in IFRS / Arabic-GAAP financial-reporting English, for anything left.

There should be **no Arabic** left in the English output, except terms your TMS marks
Do-Not-Translate.

**What to check on every batch:**

| Look at | Healthy | Act if |
|---|---|---|
| Terminology line in the logs | `TMS hits applied verbatim 42/42` | Anything below full — an approved term was paraphrased; reject the batch |
| TMS CANDIDATES table | Short, and shrinking over time | Long — send it to the glossary owner; these are terms to add |
| Any Arabic in the English output | None | A term was missed — report it with the page |
| AI-OVERRIDE-BLOCKED | Occasional | Frequent — review whether those TMS entries are still correct |
