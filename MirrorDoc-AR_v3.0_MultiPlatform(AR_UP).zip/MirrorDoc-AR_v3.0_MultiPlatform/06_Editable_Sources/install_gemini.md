# Installation — Gemini

**What this build does.** No practical instruction-length limit, so all rules are stated
inline. The agent uses code execution (or a declared function) to read the Arabic Master
as a table and to **build the downloadable .docx** itself.

## 1. Create the Gem / agent

1. Create a new Gem named `MirrorDoc-AR v3.0`.
2. Paste the text of `01_Agent_Instructions/GEMINI_Instructions_FULL.docx` into the
   instructions field.
3. Attach as knowledge files: `Arabic_Master.xlsx`, `IFRS_Fallback_Termbase.xlsx`, the
   five MDR modules, and `Dialect_Variant_Map`.
4. Attach `mirrordoc_core.py` and `build_mirror_docx.py` so code execution can import
   them.

## 2. Turn on the tools

- **Code execution** — required. Without it the agent cannot read the glossary as a table
  or produce the .docx.
- **File upload** — required, for the source PDF.
- **Web browsing** — off. A web-sourced financial term would bypass the Arabic Master.

If your deployment uses function calling instead, register `build_mirror_docx` using the
declaration in the instruction file.

## 3. Per-session flow

1. Upload the source PDF **and** `Arabic_Master.xlsx`.
2. The agent emits the inventory contract; confirm it.
3. For each batch it runs the pre-pass, prints TMS HITS, renders the mirror, verifies the
   terms, builds the .docx and attaches it.
4. Reply `next` until it prints `ALL PAGES 1-N DELIVERED`.

## 4. The one failure mode to watch

If code execution is unavailable in the session, the agent must say so and output the
mirror on screen only. It must **never** claim to have produced a file it did not
produce, and never invent a download link. Test this deliberately: disable code execution
and confirm it says so rather than fabricating a file.

## 5. Acceptance tests

The same eight as the GitHub Copilot build. Add:

9. Disable code execution and confirm the agent reports it instead of claiming a file.
