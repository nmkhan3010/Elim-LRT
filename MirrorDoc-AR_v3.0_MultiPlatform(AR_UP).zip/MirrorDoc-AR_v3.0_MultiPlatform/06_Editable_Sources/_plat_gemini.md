# Platform: Gemini — generating the downloadable .docx

## The Arabic Master

Upload `Arabic_Master.xlsx` (column A Arabic, column B English) as a file in the chat or
as a Gem knowledge file. **Read it with code, not by eye.** A model reading a glossary as
prose will miss rows; a table lookup does not.

At the start of every batch, run this in the code-execution tool:

```python
import openpyxl, re, unicodedata
wb = openpyxl.load_workbook("Arabic_Master.xlsx"); ws = wb.worksheets[0]
rows = list(ws.iter_rows(values_only=True))
# ... load, clean edge noise, and scan the batch text (see mirrordoc_core.py)
```

Ship `mirrordoc_core.py` alongside and import it where the environment allows; it
contains the tested loader, the pre-pass and the verbatim check.

Apply every term the pre-pass returns **verbatim**. Then the termbase. Then your own
translation, logged AI-TRANSLATED.

## Producing the file

Use code execution with `python-docx`:

```python
from build_mirror_docx import build
build("mirror.md", "Mirror_p1-15.docx", header="Alpha Company", footer="Page 3")
```

Then attach the generated file to your reply so the user can download it. If the
environment cannot attach a file, say so plainly and output the mirror on screen only —
**never claim a file exists that you did not produce.**

## Function declaration (if you are wired with function calling)

```json
{
  "name": "build_mirror_docx",
  "description": "Convert the English mirror (Markdown) into a downloadable .docx, preserving merged span headers, blank cells and running headers/footers.",
  "parameters": {
    "type": "object",
    "properties": {
      "mirror_markdown": {"type": "string", "description": "The mirror exactly as shown on screen"},
      "filename":        {"type": "string"},
      "header":          {"type": "string", "description": "Translated running header, or empty if the page has none"},
      "footer":          {"type": "string", "description": "The page number the source prints, as static text"},
      "landscape":       {"type": "boolean"}
    },
    "required": ["mirror_markdown", "filename"]
  }
}
```

## Order of work per batch

1. run the pre-pass, print the TMS HITS table;
2. produce the mirror on screen;
3. verify every TMS English appears verbatim; fix any miss;
4. build and attach the .docx;
5. emit LOG 1, LOG 2, LOG 3 and the batch footer.
