// Team briefing deck: how MirrorDoc-AR works across the three platforms.
const PptxGenJS = require("pptxgenjs");

const NAVY = "1E2761", INK = "1A1A2E", MID = "5A6079", LIGHT = "F2F4F8",
      GREEN = "1B7F4B", AMBER = "8A6400", RED = "A32020", W = 13.333, M = 0.65;

const pres = new PptxGenJS();
pres.defineLayout({ name: "W16", width: W, height: 7.5 });
pres.layout = "W16";

const head = (s, t, sub) => {
  s.addText(t, { x: M, y: 0.45, w: W - 2 * M, h: 0.62, fontSize: 30, bold: true,
    color: NAVY, fontFace: "Georgia", margin: 0 });
  if (sub) s.addText(sub, { x: M, y: 1.12, w: W - 2 * M, h: 0.34, fontSize: 14,
    italic: true, color: MID, fontFace: "Calibri", margin: 0 });
};
const card = () => ({ fill: { color: LIGHT }, line: { color: "E3E7EF", width: 1 } });

// ---------------------------------------------------------------- 1 title
let s = pres.addSlide();
s.background = { color: NAVY };
s.addText("S&P GLOBAL TRANSLATIONS  ·  AI ENGINEERING", { x: M, y: 1.6, w: 9, h: 0.3,
  fontSize: 12, color: "9FB0D0", fontFace: "Calibri", charSpacing: 2, margin: 0 });
s.addText("MirrorDoc-AR v3.0", { x: M, y: 2.0, w: 10, h: 0.9, fontSize: 42, bold: true,
  color: "FFFFFF", fontFace: "Georgia", margin: 0 });
s.addText("Arabic → English financial statements, mirrored exactly\nOne rule set · three platforms · the Arabic Master always first",
  { x: M, y: 3.05, w: 10, h: 0.8, fontSize: 15, color: "D6DEEE", fontFace: "Calibri",
    lineSpacing: 24, margin: 0 });
s.addShape(pres.ShapeType.ellipse, { x: 10.6, y: 4.1, w: 1.9, h: 1.9,
  fill: { color: "2E4585" } });
s.addText("v3.0", { x: 10.6, y: 4.75, w: 1.9, h: 0.6, align: "center", fontSize: 22,
  bold: true, color: "FFFFFF", fontFace: "Georgia", margin: 0 });
s.addNotes("Same rules everywhere. The only differences are where the instructions live and who builds the Word file.");

// ---------------------------------------------------------------- 2 the job
s = pres.addSlide();
head(s, "What it produces", "Two things, every batch — and they must never mix");
s.addShape(pres.ShapeType.roundRect, { x: M, y: 1.7, w: 5.9, h: 3.0, rectRadius: 0.06,
  fill: { color: LIGHT }, line: { color: NAVY, width: 1.5 } });
s.addText("ARTIFACT A — THE MIRROR", { x: 1.0, y: 1.92, w: 5.2, h: 0.3, fontSize: 12,
  bold: true, color: NAVY, fontFace: "Calibri", charSpacing: 1, margin: 0 });
s.addText("On screen, and as a downloadable .docx", { x: 1.0, y: 2.26, w: 5.2, h: 0.3,
  fontSize: 15, bold: true, color: INK, fontFace: "Calibri", margin: 0 });
s.addText([
  { text: "The document, translated. Nothing else.", options: { breakLine: true } },
  { text: "No highlight. No tick. No marker. No note.", options: { breakLine: true } },
  { text: "No total the source does not print.", options: { breakLine: true } },
  { text: "No text on a line the source leaves empty.", options: {} },
], { x: 1.0, y: 2.7, w: 5.2, h: 1.8, fontSize: 13, color: INK, fontFace: "Calibri",
     lineSpacing: 22, margin: 0 });

s.addShape(pres.ShapeType.roundRect, { x: 6.85, y: 1.7, w: 5.8, h: 3.0, rectRadius: 0.06, ...card() });
s.addText("ARTIFACT B — THE LOGS", { x: 7.15, y: 1.92, w: 5.2, h: 0.3, fontSize: 12,
  bold: true, color: MID, fontFace: "Calibri", charSpacing: 1, margin: 0 });
s.addText("Everything the agent noticed", { x: 7.15, y: 2.26, w: 5.2, h: 0.3, fontSize: 15,
  bold: true, color: INK, fontFace: "Calibri", margin: 0 });
s.addText([
  { text: "LOG 1  page, line, table, row, column, header/footer parity", options: { breakLine: true } },
  { text: "LOG 2  every total re-computed, with the delta", options: { breakLine: true } },
  { text: "LOG 3  flags, AI-TRANSLATED terms, illegible regions", options: {} },
], { x: 7.15, y: 2.7, w: 5.2, h: 1.8, fontSize: 13, color: INK, fontFace: "Calibri",
     lineSpacing: 22, margin: 0 });
s.addShape(pres.ShapeType.roundRect, { x: M, y: 4.95, w: 11.95, h: 1.1, rectRadius: 0.06,
  fill: { color: "EAF3EC" }, line: { color: GREEN, width: 1 } });
s.addText([
  { text: "The reviewer's job changes.  ", options: { bold: true, color: GREEN } },
  { text: "Instead of re-adding every column by hand, they read a list of exceptions and spot-check. The gate is computed from the data, not attested by the model.", options: { color: INK } },
], { x: 1.0, y: 5.15, w: 11.2, h: 0.75, fontSize: 13.5, fontFace: "Calibri", margin: 0 });
s.addNotes("If a highlight or a marker ever appears in the .docx, reject the batch: the QC report has leaked into the deliverable.");

// ---------------------------------------------------------------- 3 priority
s = pres.addSlide();
head(s, "The Arabic Master always wins", "Your linguists' file outranks the AI — by design, and by test");
const tiers = [
  ["1", "Arabic Master (your TMS)", "Used VERBATIM, even mid-sentence. The AI cannot override it.", NAVY],
  ["2", "IFRS fallback termbase", "Only for terms the Master does not contain.", "3B5BA5"],
  ["3", "AI translation", "Arabic-GAAP / IFRS register. Logged AI-TRANSLATED, listed for your glossary owner.", MID],
];
tiers.forEach((t, i) => {
  const y = 1.75 + i * 1.12;
  s.addShape(pres.ShapeType.roundRect, { x: M, y, w: 8.6, h: 0.98, rectRadius: 0.05,
    fill: { color: i === 0 ? LIGHT : "FFFFFF" }, line: { color: i === 0 ? NAVY : "E3E7EF", width: i === 0 ? 1.5 : 1 } });
  s.addShape(pres.ShapeType.ellipse, { x: M + 0.22, y: y + 0.26, w: 0.46, h: 0.46, fill: { color: t[3] } });
  s.addText(t[0], { x: M + 0.22, y: y + 0.32, w: 0.46, h: 0.34, align: "center", fontSize: 13,
    bold: true, color: "FFFFFF", fontFace: "Calibri", margin: 0 });
  s.addText(t[1], { x: M + 0.85, y: y + 0.16, w: 3.1, h: 0.32, fontSize: 14, bold: true,
    color: t[3], fontFace: "Calibri", margin: 0 });
  s.addText(t[2], { x: M + 0.85, y: y + 0.48, w: 7.5, h: 0.4, fontSize: 12, color: INK,
    fontFace: "Calibri", margin: 0 });
});
s.addShape(pres.ShapeType.roundRect, { x: 9.5, y: 1.75, w: 3.18, h: 3.45, rectRadius: 0.06,
  fill: { color: NAVY } });
s.addText("No Arabic\nremains", { x: 9.75, y: 2.1, w: 2.7, h: 0.8, fontSize: 19, bold: true,
  color: "FFFFFF", fontFace: "Georgia", lineSpacing: 25, margin: 0 });
s.addText("in the English output, except terms the Master marks Do-Not-Translate.\n\nThe AI share shrinks every time the glossary owner accepts a TMS candidate.",
  { x: 9.75, y: 3.1, w: 2.7, h: 1.9, fontSize: 12, color: "D6DEEE", fontFace: "Calibri",
    lineSpacing: 19, margin: 0 });
s.addText("Tested both ways: the AI is offered a \"better\" rendering and must still return the Master's English.",
  { x: M, y: 5.35, w: 11.95, h: 0.3, fontSize: 12.5, italic: true, color: MID, fontFace: "Calibri", margin: 0 });
s.addNotes("Tier 3 is real translation, not a placeholder. It is logged so nothing unvetted is invisible.");

// ---------------------------------------------------------------- 4 pre-pass
s = pres.addSlide();
head(s, "Why uploading the glossary is not enough", "A knowledge file is searched. A glossary must be looked up.");
s.addShape(pres.ShapeType.roundRect, { x: M, y: 1.75, w: 5.9, h: 2.3, rectRadius: 0.06,
  fill: { color: "FBEDED" }, line: { color: RED, width: 1 } });
s.addText("Upload alone", { x: 1.0, y: 1.95, w: 5.2, h: 0.3, fontSize: 13, bold: true,
  color: RED, fontFace: "Calibri", margin: 0 });
s.addText("Knowledge files are indexed as semantic search. On a large glossary some rows are simply not retrieved — and a missed term becomes an AI translation that still reads as good English. Nobody notices.",
  { x: 1.0, y: 2.32, w: 5.2, h: 1.5, fontSize: 13, color: INK, fontFace: "Calibri", lineSpacing: 20, margin: 0 });
s.addShape(pres.ShapeType.roundRect, { x: 6.85, y: 1.75, w: 5.8, h: 2.3, rectRadius: 0.06,
  fill: { color: "EAF3EC" }, line: { color: GREEN, width: 1 } });
s.addText("Upload + pre-pass", { x: 7.15, y: 1.95, w: 5.2, h: 0.3, fontSize: 13, bold: true,
  color: GREEN, fontFace: "Calibri", margin: 0 });
s.addText("The Master is read as a TABLE. Every term in the batch is found deterministically and handed to the agent as a TMS HITS list. Afterwards each one is checked to appear verbatim. A paraphrase fails the batch.",
  { x: 7.15, y: 2.32, w: 5.2, h: 1.5, fontSize: 13, color: INK, fontFace: "Calibri", lineSpacing: 20, margin: 0 });
s.addShape(pres.ShapeType.roundRect, { x: M, y: 4.35, w: 11.95, h: 1.75, rectRadius: 0.06,
  fill: { color: "FDF3E3" }, line: { color: AMBER, width: 1 } });
s.addText([
  { text: "Found in your sample file.  ", options: { bold: true, color: AMBER } },
  { text: "Of 34 rows, 21 were usable. Most genuine entries carried the document's own bullet — ", options: { color: INK } },
  { text: "\"قروض عقارية -\"", options: { color: NAVY, bold: true } },
  { text: " — while the page prints the term without it. Every one of those approved terms failed to match until the loader was taught to strip edge noise. Others were garbled or reversed and can never match anything: those need a clean re-export.", options: { color: INK } },
], { x: 1.0, y: 4.58, w: 11.2, h: 1.35, fontSize: 13.5, fontFace: "Calibri", lineSpacing: 21, margin: 0 });
s.addNotes("Run the health check before the first conversion. It takes seconds and tells you exactly which rows will never fire.");

// ---------------------------------------------------------------- 5 platforms
s = pres.addSlide();
head(s, "Three builds, one rule set", "The difference is where the rules live and who writes the Word file");
const rows = [
  ["", "Copilot Studio", "GitHub Copilot", "Gemini"],
  ["Instruction limit", "8,000 chars (uses 7,991)", "None — all rules inline", "None — all rules inline"],
  ["Rules not inline", "5 knowledge modules,\nfail-closed if unreachable", "None", "None"],
  ["Reads the Master", "Flow reads it as a table", "Agent runs the loader", "Code execution"],
  ["Builds the .docx", "NO — Power Automate does", "YES — agent runs the script", "YES — code execution"],
  ["Best for", "Business users in Teams", "Engineers, bulk runs", "Analysts, ad-hoc files"],
];
const colw = [2.45, 3.2, 3.2, 3.1];
rows.forEach((r, ri) => {
  let x = M;
  r.forEach((c, ci) => {
    const isH = ri === 0, isL = ci === 0;
    s.addShape(pres.ShapeType.rect, { x, y: 1.72 + ri * 0.72, w: colw[ci], h: 0.72,
      fill: { color: isH ? NAVY : (ri % 2 ? "FFFFFF" : LIGHT) },
      line: { color: "E3E7EF", width: 1 } });
    s.addText(c, { x: x + 0.12, y: 1.78 + ri * 0.72, w: colw[ci] - 0.24, h: 0.6,
      fontSize: 11.5, bold: isH || isL,
      color: isH ? "FFFFFF" : (ri === 4 && ci === 1 ? RED : (ri === 4 && ci > 1 ? GREEN : INK)),
      fontFace: "Calibri", margin: 0, valign: "middle", lineSpacing: 15 });
    x += colw[ci];
  });
});
s.addText("Every build produces the same mirror, the same three logs and the same footer. A document converted on one platform and re-converted on another should be identical.",
  { x: M, y: 6.15, w: 11.95, h: 0.4, fontSize: 12.5, italic: true, color: MID, fontFace: "Calibri", margin: 0 });
s.addNotes("The 8,000-character cap is the only reason the Copilot Studio build differs. It cannot run code, so the flow builds the file.");

// ---------------------------------------------------------------- 6 run
s = pres.addSlide();
head(s, "What a run looks like", "Same five steps on every platform");
const steps = [
  ["1", "Upload once", "The PDF and the Arabic Master. The file reference is held for the session — no re-uploading per batch."],
  ["2", "Inventory contract", "Pages, jurisdiction, currency and decimal precision, per-page manifest, batch plan. You confirm before anything converts."],
  ["3", "Pre-pass", "The Master is read as a table; every term in the batch comes back as a TMS HITS list to apply verbatim."],
  ["4", "Mirror + .docx", "Up to 15 pages or 15 complexity units per reply, never splitting a table. The file is built and handed over."],
  ["5", "Logs + gate", "LOG 1–3, the verbatim check, the totals checks, then the exact footer. Reply 'next'."],
];
steps.forEach((t, i) => {
  const y = 1.7 + i * 0.95;
  s.addShape(pres.ShapeType.roundRect, { x: M, y, w: 11.95, h: 0.83, rectRadius: 0.05, ...card() });
  s.addShape(pres.ShapeType.ellipse, { x: M + 0.2, y: y + 0.2, w: 0.42, h: 0.42, fill: { color: NAVY } });
  s.addText(t[0], { x: M + 0.2, y: y + 0.25, w: 0.42, h: 0.32, align: "center", fontSize: 12,
    bold: true, color: "FFFFFF", fontFace: "Calibri", margin: 0 });
  s.addText(t[1], { x: M + 0.8, y: y + 0.12, w: 2.3, h: 0.3, fontSize: 13.5, bold: true,
    color: NAVY, fontFace: "Calibri", margin: 0 });
  s.addText(t[2], { x: M + 3.2, y: y + 0.12, w: 8.5, h: 0.62, fontSize: 12, color: INK,
    fontFace: "Calibri", margin: 0, lineSpacing: 16 });
});
s.addNotes("Batching is by complexity, not page count: one wide nested balance sheet costs more output than fifteen narrative pages.");

// ---------------------------------------------------------------- 7 checks
s = pres.addSlide();
head(s, "Before you trust any of it", "Six acceptance tests on the live agent — the harness cannot do these for you");
const t7 = [
  ["A term in the Master returns its approved English exactly", GREEN],
  ["It still does when you insist another wording is better", GREEN],
  ["A term in neither file is translated and logged AI-TRANSLATED", GREEN],
  ["No Arabic remains anywhere in the English output", GREEN],
  ["A 15-page batch ends with the exact BATCH DONE string", GREEN],
  ["The .docx opens, and spanned headers are merged cells", GREEN],
];
t7.forEach((t, i) => {
  const y = 1.75 + i * 0.6;
  s.addShape(pres.ShapeType.roundRect, { x: M, y, w: 7.9, h: 0.5, rectRadius: 0.04, ...card() });
  s.addText(String(i + 1), { x: M + 0.18, y: y + 0.11, w: 0.3, h: 0.3, fontSize: 12,
    bold: true, color: t[1], fontFace: "Calibri", margin: 0 });
  s.addText(t[0], { x: M + 0.6, y: y + 0.11, w: 7.1, h: 0.3, fontSize: 12.5, color: INK,
    fontFace: "Calibri", margin: 0 });
});
s.addShape(pres.ShapeType.roundRect, { x: 8.75, y: 1.75, w: 3.95, h: 3.35, rectRadius: 0.06,
  fill: { color: NAVY } });
s.addText("208", { x: 8.95, y: 2.1, w: 3.5, h: 0.8, fontSize: 46, bold: true, color: "FFFFFF",
  fontFace: "Georgia", align: "center", margin: 0 });
s.addText("automated checks\non the engine", { x: 8.95, y: 2.95, w: 3.5, h: 0.6, fontSize: 13,
  color: "D6DEEE", fontFace: "Calibri", align: "center", lineSpacing: 18, margin: 0 });
s.addText("They prove the loader, the pre-pass, the number rules and the totals checks behave. They cannot prove the model obeys its prompt — that is what the six tests on the left are for.",
  { x: 8.95, y: 3.7, w: 3.5, h: 1.3, fontSize: 11.5, color: "9FB0D0", fontFace: "Calibri",
    lineSpacing: 17, margin: 0 });
s.addText("Run one Egyptian and one Jordanian filing end to end before go-live: they exercise the two-decimal and three-decimal currency paths, where the costliest silent errors live.",
  { x: M, y: 5.5, w: 11.95, h: 0.45, fontSize: 12.5, italic: true, color: MID, fontFace: "Calibri", margin: 0 });
s.addNotes("Test 2 is the important one. If the agent adopts your suggestion over the Master, terminology control is not working.");

pres.writeFile({ fileName: process.argv[2] }).then(f => console.log("wrote", f));
