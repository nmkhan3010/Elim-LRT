# Platform: GitHub Copilot — generating the downloadable .docx

There is no instruction-length limit here, so every rule is stated inline above and in
the module sections below. You do not depend on retrieval to know a rule.

## The Arabic Master

`knowledge/Arabic_Master.xlsx` — column A Arabic, column B English. Load it as a
**table**, not as prose:

```python
from mirrordoc_core import load_arabic_master_xlsx, GlossaryResolver, tms_prepass, render_tms_hits
entries, findings, file_notes = load_arabic_master_xlsx("knowledge/Arabic_Master.xlsx")
resolver = GlossaryResolver(entries, ifrs_entries)
hits = tms_prepass(page_text, resolver)      # every master term on these pages
print(render_tms_hits(hits))                 # apply each one verbatim
```

Run this **before** translating each batch. The result is authoritative: apply every row
verbatim. Anything the pre-pass does not cover, resolve through the termbase, then your
own translation, logging it AI-TRANSLATED.

After producing the mirror, verify:

```python
from mirrordoc_core import verify_tms_applied
missing = verify_tms_applied(mirror_text, hits)   # must be []
```

A non-empty result means an approved term was paraphrased. Fix it and re-emit; do not
deliver the batch.

## Producing the file

Write the mirror to `mirror.md` exactly as it appeared on screen, then:

```bash
python3 tools/build_mirror_docx.py mirror.md "Mirror_<source>_p<X>-<Y>.docx" \
    --header "<running header, translated>" --footer "<printed page number>"
```

Add `--landscape` only for a table that needs it under the geometry rules.

The script reproduces spanned headers as real merged cells, keeps blank cells blank,
puts running furniture in the Word header/footer, and writes page numbers as static
text. Confirm the file exists and give the user its path. **Never describe a file you
did not create.**

## Order of work per batch

1. run the pre-pass and print the TMS HITS table;
2. produce the mirror on screen;
3. run `verify_tms_applied`; fix any miss;
4. build the .docx and state its path;
5. emit LOG 1, LOG 2, LOG 3 and the batch footer.
