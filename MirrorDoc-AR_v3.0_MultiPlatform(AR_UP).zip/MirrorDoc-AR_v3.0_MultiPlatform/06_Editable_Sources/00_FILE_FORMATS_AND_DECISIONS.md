# File formats in this package — what is .docx, what is not, and why

Every document in this package is now a Word file. Three things are deliberately
**not**, and converting them would break them. This page records those decisions so
nobody has to rediscover them.

## Now .docx (15 files)

Start Here, the three PASTE files, all five MDR knowledge modules, the dialect map,
the number-format map, both READMEs, the UAT report and the operator quick reference.
Markdown tables are rendered as real Word tables, code blocks are preserved verbatim
in a monospaced font, and Arabic runs are set in a font that carries the glyphs.

The editable Markdown and text originals are kept in `06_Editable_Sources/`. Edit
those, regenerate, and re-run the audit — that is the maintenance path.

## Deliberately not .docx

| File | Format kept | Why converting would break it |
|---|---|---|
| `Fidelity_and_Validation_Log_TEMPLATE.xlsx` | .xlsx | It contains **1,039 live formulas** and a computed release gate. In Word they become dead text, and the gate — the thing that decides whether output ships — stops computing. |
| `TMS_Glossary_Master_TEMPLATE.xlsx`, `IFRS_Fallback_Termbase.xlsx` | .xlsx | Structured termbases the agent looks terms up in, and that you will filter, sort and bulk-edit. A Word table cannot be queried that way. |
| `MirrorDoc-AR_v2_Team_Briefing.pptx` | .pptx | A slide deck. |
| `mirrordoc_core.py`, `run_uat.py`, `coverage_audit.py` | .py | Executable code. A .docx copy could not be run, and a listing that drifts from the code it documents is worse than no listing. |

## The one risk to know about when pasting from Word

`PASTE_01_CORE_INSTRUCTIONS.docx` is rendered verbatim in a monospaced font
specifically so the exact strings survive. Two of them must be reproduced character
for character, because the flow matches on them:

```
BATCH DONE: pages X-Y of N delivered. To continue: reply 'next',
ALL PAGES 1-N DELIVERED. Compare source pages X-Y;
```

Word's autocorrect turns straight quotes into curly quotes and hyphens into en-dashes
**as you type**, not on paste, so copying out of the .docx is safe. But if anyone
edits the text inside Word before pasting, `'next'` can silently become `'next'` with
typographic quotes, and the trigger stops matching. Nothing errors; the loop just
stops continuing.

If you edit the instructions, edit
`06_Editable_Sources/01_Agent_Instructions/PASTE_01_CORE_INSTRUCTIONS.txt` and
regenerate. Then run:

```
python3 03_Validation_QC/validators/coverage_audit.py
```

It re-checks the 8,000-character ceiling, all 121 rule atoms and single-source
ownership — and it reads the **.docx** files, not the Markdown, so it verifies what
you will actually upload rather than what you meant to.

## Naming

The instructions refer to knowledge files by name without an extension
(`MDR-02_Numbers_Currency_QC`, not `...md`), so the same instruction text works
whether a module is uploaded as .docx, .md or .xlsx. Keep the names exactly as
shipped. A knowledge file the instructions name but that does not exist triggers the
fail-closed rule and blocks every batch — which is the intended behaviour, but an
avoidable way to spend an afternoon.
