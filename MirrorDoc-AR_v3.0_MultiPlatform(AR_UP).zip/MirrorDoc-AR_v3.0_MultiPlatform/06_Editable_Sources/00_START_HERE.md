# MirrorDoc-AR v2.3 — Start here

Arabic → English financial document converter for Copilot Studio.
Issued 14 August 2026. Supersedes v2.2, v2.1, v2.0 and the v1.x single-block instructions.

---

**Everything is Word format.** The 16 documents in this package are .docx. Three file
types are deliberately not — the validation workbook (1,039 live formulas), the two
termbases, and the deck — because converting them would destroy what they do. See
`00_FILE_FORMATS_AND_DECISIONS.docx`. Editable Markdown and text originals are in
`06_Editable_Sources/`.

> Each .docx contains a Word contents field where applicable — open it, press
> `Ctrl+A` then `F9`, and choose "update entire table".

---

## Read this first, by role

| You are | Read | Time |
|---|---|---|
| **Deciding whether to approve this** | `04_Team_Handover/MirrorDoc-AR_v2_Team_Briefing.pptx` | 15 min |
| **Building the agent** | `01_Agent_Instructions/…Build_and_Deployment_Guide.docx` §11, then paste the three files in that folder | 1 hr |
| **Owning the terminology** | `02_Knowledge_Resources/README_Knowledge_Resources.docx`, then the glossary template | 30 min |
| **Reviewing output** | `03_Validation_QC/Fidelity_and_Validation_Log_TEMPLATE.xlsx`, RELEASE GATE sheet | 10 min |
| **Operating it daily** | `04_Team_Handover/Operator_Quick_Reference.docx` | 5 min |
| **Auditing the engineering** | `03_Validation_QC/UAT_Report_v2.2.docx`, then `validators/` | 45 min |

---

## What is in the box

```
MirrorDoc-AR_v2.2_Release/
├── 00_START_HERE.md                      ← you are here
├── 01_Agent_Instructions/
│   ├── PASTE_01_CORE_INSTRUCTIONS.txt        → Copilot Studio "Instructions"
│   ├── PASTE_02_AGENT_DESCRIPTION.txt        → Copilot Studio "Description"
│   ├── PASTE_03_STARTER_PROMPTS_AND_TRIGGERS.txt → prompts, triggers, variables, flow
│   └── MirrorDoc-AR_v2_Build_and_Deployment_Guide.docx  (21 pp: spec, gap register, RCA, runbook)
├── 02_Knowledge_Resources/               → upload all nine as agent Knowledge sources
│   ├── MDR-01_Tables_and_Headers.docx        tables, spans, side-by-side
│   ├── MDR-02_Numbers_Currency_QC.docx       numerals, precision, flags
│   ├── MDR-03_Translation_Glossary.docx      resolution order, normalisation
│   ├── MDR-04_Logs_Gate_Validation.docx      totals, LOG 1–3, gate
│   ├── MDR-05_Pages_Batching_HeadersFooters.docx
│   ├── UPLOAD_INBOX/                         drop your TMS exports + sample PDFs here
│   ├── TMS_Glossary_Master_TEMPLATE.xlsx     → upload AS TMS_Glossary_Master.xlsx
│   ├── IFRS_Fallback_Termbase.xlsx
│   ├── Dialect_Variant_Map.docx
│   ├── Number_Format_Rules.docx
│   └── README_Knowledge_Resources.docx
├── 03_Validation_QC/
│   ├── Fidelity_and_Validation_Log_TEMPLATE.xlsx   (LOG 1–3 + computed release gate)
│   ├── UAT_Report_v2.1.md
│   └── validators/
│       ├── mirrordoc_core.py              deterministic engine
│       ├── coverage_audit.py              121 rule atoms + 8k limit + single-source
│       ├── run_uat.py                     136-case harness
│       └── uat_results.json               recorded run
└── 04_Team_Handover/
    ├── MirrorDoc-AR_v2_Team_Briefing.pptx (11 slides, with speaker notes)
    └── Operator_Quick_Reference.md
```

> **Opening the .docx:** its contents page is a Word field, so it renders empty until Word
> builds it. Open the file, press `Ctrl+A` then `F9`, and choose "update entire table". This
> is normal for a generated document and is not a fault in the file.

---

## The one-paragraph version

**v2.1 in one line:** the deliverable and the review of the deliverable are now two separate
objects, because v2.0 was quietly putting its own commentary inside the document it delivered.

v1 was a carefully written prompt. Its problem was that several of its rules could not be
enforced by the layer they were written for: a language model cannot control scanner DPI,
cannot deskew an image, cannot re-fetch a file it was not given, and cannot reliably foot a
two-hundred-row table. v2.0 keeps the intent of every rule and moves the enforcement to layers
that can honour it — image handling to the ingestion flow, arithmetic and lookup to
deterministic code, the batching loop to Power Automate. Twenty-four gaps were found and
rectified, nine of them capable of corrupting a delivered figure with no visible sign. The
deterministic layer ships with a 170-case UAT and a 134-atom coverage audit, all passing.

Version 2.1 then closed six further findings, four of them defects in v2.0 itself. They shared
one root cause: nothing separated the mirror from the QC report, so highlights, recomputed
totals, bracketed markers and repeated span labels were all reaching the client's document.
The mirror now carries the translated document and nothing else; every flag, delta and
computed figure lives in the logs. See the guide §5.

---

## What v2.3 changed — terminology priority restored

Your requirement: **TMS Excel first, then AI for whatever remains**, using Arabic GAAP,
IFRS and financial-reporting terminology. v2.1 and v2.2 did not do that. They applied
the TMS first, but left any term the TMS lacked **in Arabic**. That was a design change
made in v2.0 without being put to you as a decision. v2.3 restores your design:

| Tier | Source | Result |
|---|---|---|
| 1 | TMS Excel (Native → English) | Inserted verbatim, even mid-sentence. Never overridden. |
| 2 | IFRS termbase | For terms the TMS lacks |
| 3 | AI translation | IFRS / Arabic-GAAP register; logged AI-TRANSLATED |

No Arabic remains except Do-Not-Translate entries.

**Why a pre-pass was added.** An uploaded knowledge file is indexed for semantic search,
not queried as a table, so on a large glossary some TMS terms will not be retrieved — and
a missed TMS term quietly becomes an AI translation. The flow now reads the Excel as a
table, finds every TMS term in each batch itself, hands the agent a TMS HITS list to
apply first, and afterwards checks every one appears verbatim. That turns "TMS first"
from an instruction into a check.

**A bug found on the way.** Running the engine on a realistic sentence showed that any TMS
term followed by Arabic punctuation (، ؛ ؟) was being missed and passed to the AI. Fixed,
with regression tests. `03_Validation_QC/Worked_Example_TMS_First.docx` walks through a real
run on a two-column Native/English glossary.

**One setting reversed:** the model's own general knowledge must now be **on** — tier 3
depends on it. Web search stays **off**. See PASTE_03 §D.

---

## What v2.2 changed

The inline instruction field is now **7,983 characters against an 8,000 limit**, down
from 25,356. Nothing was dropped: the rules moved into five retrievable knowledge
modules, and `coverage_audit.py` proves it by checking 121 rule atoms are still homed.

The split is not "important inline, detail in the KB". Retrieval is probabilistic and
an instruction field is not, so the rule is:

- **Inline** — anything whose absence corrupts output *silently*, plus a fail-closed
  guard for each module. If a module cannot be retrieved, the agent stops and names it
  rather than falling back on memory.
- **Knowledge base** — reference data: tables, taxonomies, worked examples.

That is why the currency *rule* ("never infer precision; if unknown, stop") is inline
while the currency *table* is in MDR-02. A missed retrieval becomes loud instead of silent.

One flaw surfaced while testing this: currency precision was stated in three separate
files. Two copies of a rule eventually drift, and retrieval then surfaces the stale one
without saying so. MDR-02 is now the single normative owner, the other two defer to it
explicitly, and the audit fails the build if a normative table gains a second undeferred home.

---

## What v2.1 changed, in six lines

| ID | Was | Now |
|---|---|---|
| R-01 | Headers and footers unaddressed | Reproduced in the Word header/footer, never inline; printed page numbers static, not fields |
| R-02 | Spanned label folded into every leaf, printing it twice | Merged cell in the .docx, blank continuation on screen, folded form in LOG 1 only |
| R-03 | Agent highlighted suspect cells in the output | No annotation of any kind in the mirror; all of it in LOG 3 |
| R-04 | Totals recomputed with no rule against writing them in | If the source prints no total, the mirror has none — LOG 2 records the gap |
| R-05 | Blank rule covered numeric cells only | Blank cells, rows, labels and lines all preserved exactly |
| R-06 | Table classes unnamed | Standard, long, complex and nested all reproduced without simplification |

---

## Two decisions block go-live

1. **Side-by-side block order.** You asked for left-then-right. An Arabic page reads right to
   left, so the default ships as right-then-left, with left-first available as a per-document
   setting. Confirm which you want. See the guide §8.3, or slide 7 of the deck.
2. **Rounding tolerance.** Defaults to zero, which will surface legitimate rounding in
   published statements as mismatches. Calibrate on real filings before you widen it, and
   record the rationale.

---

## Before you trust any output

Run one Egyptian and one Jordanian filing end to end and reconcile LOG 1 by hand. Those two
exercise the two-decimal and three-decimal currency paths, which is where the most dangerous
class of error lives. Everything else in this package exists to make that reconciliation
shorter, not to make it unnecessary.
