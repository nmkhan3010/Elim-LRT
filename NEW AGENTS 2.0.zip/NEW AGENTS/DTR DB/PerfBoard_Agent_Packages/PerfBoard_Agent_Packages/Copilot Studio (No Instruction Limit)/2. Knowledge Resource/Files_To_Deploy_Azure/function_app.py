"""
Reference Azure Function (Python) used by the Copilot Studio agent flow "BuildDashboard".
POST /api/build   { "report_date": "2026-09-16", "file_name": "PerformanceReport_2026-09-16.xlsx",
                    "file_content_b64": "<base64 of the workbook>", "available_dates": ["2026-09-15", ...] }
Files that must sit next to this file: build_dashboard.py, dashboard_template.html
App settings: DASHBOARD_STORAGE_CONNECTION (storage account connection string), DASHBOARD_BASE_URL (static website URL)
"""
import base64, json, os, re, secrets, tempfile
from pathlib import Path

import azure.functions as func
from azure.storage.blob import BlobServiceClient, ContentSettings

import build_dashboard as bd

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)
TEMPLATE = Path(__file__).parent / "dashboard_template.html"


def _resp(obj, code=200):
    return func.HttpResponse(json.dumps(obj), status_code=code, mimetype="application/json")


def build_report(body: dict):
    """Pure logic (no Azure calls): returns (status_code, payload, html_or_None)."""
    try:
        iso = bd.norm_date(body.get("report_date", ""))
    except ValueError as e:
        return 400, {"status": "ERROR", "message": str(e)}, None
    b64 = body.get("file_content_b64")
    if not b64:
        return 200, {"status": "NOT_FOUND", "available": body.get("available_dates", [])}, None
    fname = os.path.basename(body.get("file_name") or f"PerformanceReport_{iso}.xlsx")
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / fname
        path.write_bytes(base64.b64decode(b64))
        try:
            report = bd.make_report(path, iso, iso, [])
        except Exception as e:  # unreadable file, missing column ...
            return 422, {"status": "ERROR", "message": str(e)[:300]}, None
    tok = re.search(r"(\d{2}-\d{2}-\d{4})", fname)
    if tok:
        report["label"] = tok.group(1)
    report["aliases"] = [d for d in bd.file_dates(fname, "both") if d != iso]
    rows = report["rows"]
    pres = [r for r in rows if (r.get("d") or 0) > 0 and r.get("a") is not None]
    warnings = []
    hi = sum(1 for r in pres if r["a"] / (450 * r["d"]) * 100 > 150)
    ng = sum(1 for r in pres if not (r.get("g") or 0) > 0)
    if hi:
        warnings.append(f"{hi} present analysts exceed 150% utilization")
    if ng:
        warnings.append(f"{ng} present analysts have no goal units")
    html = bd.build_html({iso: report}, TEMPLATE.read_text(encoding="utf-8"))
    return 200, {"status": "OK", "source_file": fname, "previous_date": "",
                 "summary": bd.summarize(rows), "warnings": warnings}, html


@app.route(route="build", methods=["POST"])
def build(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
    except ValueError:
        return _resp({"status": "ERROR", "message": "Body must be JSON"}, 400)
    code, payload, html = build_report(body)
    if html is None:
        return _resp(payload, code)
    iso = bd.norm_date(body["report_date"])
    name = f"Performance_Dashboard_{iso}_{secrets.token_hex(4)}.html"   # random suffix = hard-to-guess URL
    svc = BlobServiceClient.from_connection_string(os.environ["DASHBOARD_STORAGE_CONNECTION"])
    svc.get_blob_client("$web", name).upload_blob(
        html.encode("utf-8"), overwrite=True,
        content_settings=ContentSettings(content_type="text/html; charset=utf-8"))
    payload["file_name"] = name
    payload["url"] = os.environ["DASHBOARD_BASE_URL"].rstrip("/") + "/" + name
    return _resp(payload, 200)
