#!/usr/bin/env python3
"""
build_dashboard.py - turn a daily Performance Report workbook into a self-contained
interactive HTML dashboard.

Usage
  python build_dashboard.py --date 2026-09-16 --reports-dir ./knowledge --out dashboard_2026-09-16.html
  python build_dashboard.py --input PerformanceReport_02-10-2026.xlsm --date 2026-02-10 --out out.html

How the date lookup works
  1. Normalise the requested date to YYYY-MM-DD (accepts YYYY-MM-DD, YYYYMMDD, YYMMDD).
  2. Scan --reports-dir for workbooks whose file name contains that date in any of the
     supported patterns (see DATE_PATTERNS). No match -> exit code 2 and list of available dates.
  3. The previous available date (if any) is embedded too, so the dashboard can show
     day-over-day deltas on the KPI cards.
"""
import argparse, datetime as dt, json, re, sys
from pathlib import Path

try:
    from openpyxl import load_workbook
except ImportError:
    sys.exit("openpyxl is required: pip install openpyxl")

HERE = Path(__file__).parent
EXTS = {".xlsx", ".xlsm", ".xls"}

# header text (first line, lower-cased) -> short key used by the dashboard
COLMAP = {
    "analyst name": "n", "report to": "m", "location": "l", "title": "t",
    "tenure (y)": "y", "no of jobs": "j", "actual time": "a", "standard time": "s",
    "core time": "c", "core support time": "cs", "working days": "d",
    "goal units(1unit=1 min)": "g", "tenure wise goal %": "gp", "domain": "dom",
}
NUMERIC = {"j", "a", "s", "c", "cs", "d", "g"}

# File-name date patterns. Each entry: (regex, order of groups)
DATE_PATTERNS = [
    (re.compile(r"(\d{4})-(\d{2})-(\d{2})"), "ymd"),        # 2026-09-16
    (re.compile(r"(?<!\d)(\d{4})(\d{2})(\d{2})(?!\d)"), "ymd"),  # 20260916
    (re.compile(r"(\d{2})-(\d{2})-(\d{4})"), "AMBIG"),      # 02-10-2026  (DD-MM or MM-DD)
]


def norm_date(s: str) -> str:
    s = s.strip().replace("/", "-").replace(".", "-")
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        y, mo, d = m.groups()
    elif re.fullmatch(r"\d{8}", s):
        y, mo, d = s[:4], s[4:6], s[6:]
    elif re.fullmatch(r"\d{6}", s):
        y, mo, d = "20" + s[:2], s[2:4], s[4:]
    else:
        raise ValueError(f"'{s}' is not a valid date. Use YYYY-MM-DD.")
    return dt.date(int(y), int(mo), int(d)).isoformat()


def file_dates(name: str, ambiguous_order: str):
    """Return every ISO date a file name could represent."""
    out = []
    for rx, order in DATE_PATTERNS:
        m = rx.search(name)
        if not m:
            continue
        a, b, c = m.groups()
        try:
            if order == "ymd":
                out.append(dt.date(int(a), int(b), int(c)).isoformat())
            else:  # two-digit / two-digit / year
                for o in ([ambiguous_order] if ambiguous_order != "both" else ["dmy", "mdy"]):
                    d_, m_ = (int(a), int(b)) if o == "dmy" else (int(b), int(a))
                    try:
                        out.append(dt.date(int(c), m_, d_).isoformat())
                    except ValueError:
                        pass
        except ValueError:
            pass
        if out:
            break
    return out


def num(v):
    if v is None or v == "":
        return None
    try:
        return round(float(v), 4)
    except (TypeError, ValueError):
        return None


def read_workbook(path: Path):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    header, cols, rows_out, blank = None, {}, [], 0
    for row in ws.iter_rows(values_only=True):
        if header is None:
            heads = [str(c).split("\n")[0].strip().lower() if c is not None else "" for c in row]
            if "analyst name" in heads:
                header = heads
                cols = {i: COLMAP[h] for i, h in enumerate(heads) if h in COLMAP}
            continue
        rec = {k: row[i] if i < len(row) else None for i, k in cols.items()}
        if not rec.get("n") or not str(rec["n"]).strip():
            blank += 1
            continue
        for k in NUMERIC:
            rec[k] = num(rec.get(k))
        gp = rec.get("gp")
        if isinstance(gp, str) and gp.endswith("%"):
            gp = num(gp[:-1])
        rec["gp"] = gp if isinstance(gp, (int, float)) else num(gp)
        for k in ("n", "m", "l", "t", "y", "dom"):
            rec[k] = (str(rec[k]).strip() if rec.get(k) not in (None, "") else "")
        rows_out.append(rec)
    if header is None:
        raise ValueError(f"{path.name}: could not find the header row containing 'Analyst Name'.")
    missing = [n for n in ("analyst name", "location", "actual time", "standard time", "working days") if n not in header]
    if missing:
        raise ValueError(f"{path.name}: missing required columns: {', '.join(missing)}")
    return rows_out, blank


def find_report(reports_dir: Path, iso: str, ambiguous_order: str):
    hits = []
    for p in sorted(reports_dir.iterdir()):
        if p.suffix.lower() in EXTS and not p.name.startswith("~$"):
            if iso in file_dates(p.name, ambiguous_order):
                hits.append(p)
    return hits


def list_available(reports_dir: Path, ambiguous_order: str):
    seen = {}
    for p in sorted(reports_dir.iterdir()):
        if p.suffix.lower() in EXTS and not p.name.startswith("~$"):
            for d in file_dates(p.name, ambiguous_order)[:1]:
                seen[d] = p
    return seen


def make_report(path: Path, iso: str, label: str, aliases):
    rows, blank = read_workbook(path)
    return {
        "file": path.name,
        "label": label,
        "aliases": aliases,
        "quality": {"blank_rows_dropped": blank},
        "rows": rows,
    }


def summarize(rows, threshold=100.0):
    """Headline numbers used by the agent's hand-off message (same definitions as the dashboard)."""
    pres = [r for r in rows if (r.get("d") or 0) > 0 and r.get("a") is not None]
    def avg(vals):
        vals = [v for v in vals if v is not None]
        return round(sum(vals) / len(vals), 1) if vals else None
    util = [r["a"] / (450 * r["d"]) * 100 for r in pres]
    prod = [(r.get("s") or 0) / (450 * r["d"]) * 100 for r in pres]
    goal = [(r.get("s") or 0) / r["g"] * 100 for r in pres if (r.get("g") or 0) > 0]
    return {
        "total": len(rows), "present": len(pres), "absent": len(rows) - len(pres),
        "avg_utilization": avg(util), "avg_productivity": avg(prod), "avg_goal_based": avg(goal),
        "goal_attainment": round(sum(1 for g in goal if g >= threshold) / len(goal) * 100, 1) if goal else None,
        "jobs": int(sum((r.get("j") or 0) for r in pres)),
    }


def build_html(reports: dict, template_text: str) -> str:
    """Fill the dashboard template with one or more reports ({iso_date: report_dict})."""
    payload = json.dumps(reports, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    meta = json.dumps({"generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M")})
    out = re.sub(r"/\*@@REPORTS@@\*/.*?/\*@@END@@\*/", lambda m: payload, template_text, count=1, flags=re.S)
    out = re.sub(r"/\*@@META@@\*/.*?/\*@@END@@\*/", lambda m: meta, out, count=1, flags=re.S)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True, help="Report date, YYYY-MM-DD (YYYYMMDD / YYMMDD also accepted)")
    ap.add_argument("--reports-dir", help="Folder that holds the daily workbooks (the knowledge resource)")
    ap.add_argument("--input", help="Use one specific workbook instead of scanning a folder")
    ap.add_argument("--template", default=str(HERE / "dashboard_template.html"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--file-date-order", default="both", choices=["dmy", "mdy", "both"],
                    help="How to read NN-NN-YYYY in file names (default both: either reading matches)")
    a = ap.parse_args()

    try:
        iso = norm_date(a.date)
    except ValueError as e:
        print(f"ERROR: {e}")
        sys.exit(1)

    reports = {}
    if a.input:
        p = Path(a.input)
        reports[iso] = make_report(p, iso, iso, [])
        # keep the original file-name token as the display label when it differs
        m = re.search(r"(\d{2}-\d{2}-\d{4})", p.name)
        if m:
            reports[iso]["label"] = m.group(1)
        for alt in file_dates(p.name, a.file_date_order):
            if alt != iso:
                reports[iso]["aliases"].append(alt)
    else:
        if not a.reports_dir:
            print("ERROR: give --reports-dir or --input"); sys.exit(1)
        d = Path(a.reports_dir)
        hits = find_report(d, iso, a.file_date_order)
        if not hits:
            avail = sorted(list_available(d, a.file_date_order))
            print(f"NOT_FOUND: no report for {iso}. Available dates: {', '.join(avail) if avail else 'none'}")
            sys.exit(2)
        if len(hits) > 1:
            print(f"WARNING: {len(hits)} files match {iso}; using {hits[0].name}", file=sys.stderr)
        reports[iso] = make_report(hits[0], iso, iso, [])
        earlier = [k for k in list_available(d, a.file_date_order) if k < iso]
        if earlier:
            pk = max(earlier)
            pp = list_available(d, a.file_date_order)[pk]
            reports[pk] = make_report(pp, pk, pk, [])

    tpl = build_html(reports, Path(a.template).read_text(encoding="utf-8"))
    Path(a.out).write_text(tpl, encoding="utf-8")
    r = reports[iso]
    present = sum(1 for x in r["rows"] if (x.get("d") or 0) > 0)
    print(f"OK: {a.out}  | date={iso} file={r['file']} analysts={len(r['rows'])} present={present} absent={len(r['rows'])-present}")


if __name__ == "__main__":
    main()
