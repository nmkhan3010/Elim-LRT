#!/usr/bin/env python3
"""
update_register.py - maintain the dashboard register that feeds
  * Option D: the landing page (index.html reads register.json)
  * Option C: the viewer agent (Dashboard_Register_Agent.txt, for knowledge-file agents)

Commands (all take --register register.json)
  add          upsert one dashboard; an earlier Published row for the same date becomes Superseded
  from-xlsx    rebuild the register from Dashboard_Register.xlsx (sheet "Register")
  check        validate the register (exit code 1 if there are errors)
  embed        write a copy of the register into index.html (works without a web server)
  export-agent-txt   write the plain-text register used by knowledge-file agents

Examples
  python update_register.py --register register.json add --date 2026-09-16 \
      --url https://contoso.z13.web.core.windows.net/Performance_Dashboard_2026-09-16_a1b2c3d4.html \
      --source-file PerformanceReport_2026-09-16.xlsx --total 180 --present 127 --absent 53
  python update_register.py --register register.json from-xlsx Dashboard_Register.xlsx
  python update_register.py --register register.json embed index.html --out index.html
  python update_register.py --register register.json export-agent-txt Dashboard_Register_Agent.txt
"""
import argparse, datetime as dt, json, re, sys
from pathlib import Path

STATUSES = ("Published", "Superseded", "Withdrawn")
SUMMARY_KEYS = ("total", "present", "absent", "avg_utilization", "avg_goal_based", "goal_attainment", "jobs")
XLSX_MAP = {"date": "date", "dashboard link": "url", "status": "status", "source file": "source_file",
            "built at": "built_at", "built by": "built_by", "total analysts": "total", "present": "present",
            "absent": "absent", "avg utilization %": "avg_utilization", "goal-based %": "avg_goal_based",
            "goal attainment %": "goal_attainment", "total jobs": "jobs", "notes": "notes"}


def now():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def norm_date(s):
    s = str(s).strip().replace("/", "-").replace(".", "-")
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", s) or re.fullmatch(r"(\d{4})(\d{2})(\d{2})", s)
    if not m:
        raise ValueError(f"'{s}' is not a valid date. Use YYYY-MM-DD.")
    return dt.date(*map(int, m.groups())).isoformat()


def load(path):
    p = Path(path)
    if not p.exists():
        return {"updated": "", "dashboards": []}
    return json.loads(p.read_text(encoding="utf-8"))


def save(path, reg):
    reg["updated"] = now()
    reg["dashboards"].sort(key=lambda e: (e["date"], e.get("built_at", "")), reverse=True)
    Path(path).write_text(json.dumps(reg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def make_entry(**k):
    summ = {key: k[key] for key in SUMMARY_KEYS if k.get(key) not in (None, "")}
    return {"date": norm_date(k["date"]), "url": (k.get("url") or "").strip(), "status": k.get("status") or "Published",
            "source_file": k.get("source_file") or "", "built_at": k.get("built_at") or now(),
            "built_by": k.get("built_by") or "", "summary": summ, "notes": k.get("notes") or ""}


def upsert(reg, e):
    if e["status"] == "Published":
        for old in reg["dashboards"]:
            if old["date"] == e["date"] and old["status"] == "Published" and old["url"] != e["url"]:
                old["status"] = "Superseded"
    reg["dashboards"] = [o for o in reg["dashboards"] if not (o["date"] == e["date"] and o["url"] == e["url"])]
    reg["dashboards"].append(e)


def validate(reg):
    errs, warns, pub = [], [], {}
    for i, e in enumerate(reg["dashboards"], 1):
        tag = f"row {i} ({e.get('date')})"
        try:
            norm_date(e.get("date", ""))
        except ValueError:
            errs.append(f"{tag}: invalid date")
        if e.get("status") not in STATUSES:
            errs.append(f"{tag}: status must be one of {', '.join(STATUSES)}")
        u = e.get("url", "")
        if e.get("status") == "Published":
            if not u:
                errs.append(f"{tag}: Published row has no link")
            pub[e["date"]] = pub.get(e["date"], 0) + 1
        if u and not re.match(r"https?://", u) and re.match(r"[a-z][a-z0-9+.-]*:", u, re.I):
            errs.append(f"{tag}: link scheme not allowed")
        if u.startswith("http://"):
            warns.append(f"{tag}: link is http, not https")
        if re.search(r"\s", u):
            errs.append(f"{tag}: link contains spaces")
    for d, n in pub.items():
        if n > 1:
            errs.append(f"{d}: {n} Published rows (only one allowed; mark the others Superseded)")
    return errs, warns


def from_xlsx(path):
    from openpyxl import load_workbook
    ws = load_workbook(path, data_only=True)["Register"]
    rows = list(ws.iter_rows(values_only=True))
    head = [str(c).strip().lower() if c is not None else "" for c in rows[0]]
    idx = {XLSX_MAP[h]: i for i, h in enumerate(head) if h in XLSX_MAP}
    if "date" not in idx or "url" not in idx:
        raise ValueError("Sheet 'Register' needs the columns 'Date' and 'Dashboard link'")
    out = []
    for r in rows[1:]:
        g = lambda k: (r[idx[k]] if k in idx and idx[k] < len(r) else None)
        if g("date") in (None, ""):
            continue
        d = g("date")
        d = d.date().isoformat() if hasattr(d, "date") else d
        ba = g("built_at")
        ba = ba.strftime("%Y-%m-%d %H:%M") if hasattr(ba, "strftime") else (str(ba) if ba else "")
        num = lambda k: (float(g(k)) if isinstance(g(k), (int, float)) else None)
        out.append(make_entry(date=d, url=g("url"), status=g("status"), source_file=g("source_file"), built_at=ba or now(),
                              built_by=g("built_by"), notes=g("notes"), total=num("total"), present=num("present"),
                              absent=num("absent"), avg_utilization=num("avg_utilization"), avg_goal_based=num("avg_goal_based"),
                              goal_attainment=num("goal_attainment"), jobs=num("jobs")))
    return {"updated": now(), "dashboards": out}


def agent_txt(reg):
    pub = sorted([e for e in reg["dashboards"] if e["status"] == "Published"], key=lambda e: (e["date"], e["built_at"]), reverse=True)
    seen, lines = set(), []
    for e in pub:
        if e["date"] in seen:
            continue
        seen.add(e["date"])
        s = e.get("summary", {})
        extra = f" | analysts {int(s['total'])} present {int(s['present'])} absent {int(s['absent'])}" if all(k in s for k in ("total", "present", "absent")) else ""
        lines.append(f"{e['date']} | {e['url']} | Published | source {e['source_file'] or '-'} | built {e['built_at']}{extra}")
    head = f"# PerfBoard dashboard register | updated {reg.get('updated') or now()} | latest {lines[0].split(' | ')[0] if lines else 'none'} | published {len(lines)}"
    return head + "\n" + "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--register", default="register.json")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("add")
    a.add_argument("--date", required=True); a.add_argument("--url", required=True)
    a.add_argument("--status", default="Published", choices=STATUSES)
    for k in ("source-file", "built-at", "built-by", "notes"):
        a.add_argument("--" + k)
    for k in SUMMARY_KEYS:
        a.add_argument("--" + k.replace("_", "-"), type=float)
    x = sub.add_parser("from-xlsx"); x.add_argument("xlsx")
    sub.add_parser("check")
    e = sub.add_parser("embed"); e.add_argument("html"); e.add_argument("--out")
    t = sub.add_parser("export-agent-txt"); t.add_argument("out")
    args = ap.parse_args()

    if args.cmd == "from-xlsx":
        reg = from_xlsx(args.xlsx)
    else:
        reg = load(args.register)
    if args.cmd == "add":
        try:
            ent = make_entry(date=args.date, url=args.url, status=args.status, source_file=args.source_file, built_at=args.built_at,
                             built_by=args.built_by, notes=args.notes, **{k: getattr(args, k) for k in SUMMARY_KEYS})
        except ValueError as ex:
            print("ERROR:", ex); sys.exit(1)
        upsert(reg, ent)
    errs, warns = validate(reg)
    for w in warns:
        print("WARNING:", w)
    if errs:
        for er in errs:
            print("ERROR:", er)
        if args.cmd != "check":
            print("Nothing was written."); 
        sys.exit(1)
    if args.cmd in ("add", "from-xlsx"):
        save(args.register, reg)
        print(f"OK: {args.register} now has {len(reg['dashboards'])} rows ({sum(1 for d in reg['dashboards'] if d['status']=='Published')} published)")
    elif args.cmd == "check":
        print(f"OK: {len(reg['dashboards'])} rows, no errors")
    elif args.cmd == "embed":
        src = Path(args.html).read_text(encoding="utf-8")
        payload = json.dumps(reg, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
        new, n = re.subn(r"/\*@@REGISTER@@\*/.*?/\*@@END@@\*/", lambda m: "/*@@REGISTER@@*/" + payload + "/*@@END@@*/", src, count=1, flags=re.S)
        if not n:
            print("ERROR: placeholder /*@@REGISTER@@*/ not found in", args.html); sys.exit(1)
        Path(args.out or args.html).write_text(new, encoding="utf-8")
        print("OK: embedded", len(reg["dashboards"]), "rows into", args.out or args.html)
    elif args.cmd == "export-agent-txt":
        Path(args.out).write_text(agent_txt(reg), encoding="utf-8")
        print("OK: wrote", args.out)


if __name__ == "__main__":
    main()
