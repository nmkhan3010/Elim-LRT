@echo off
setlocal
cd /d "%~dp0"
echo.
echo  PerfBoard - update the dashboard register
echo  ------------------------------------------
set PY=python
python --version >nul 2>nul
if errorlevel 1 set PY=py
%PY% --version >nul 2>nul
if errorlevel 1 goto :nopython
echo Step 1 of 3: reading Dashboard_Register.xlsx and checking every row ...
%PY% update_register.py --register register.json from-xlsx Dashboard_Register.xlsx
if errorlevel 1 goto :fail
echo Step 2 of 3: putting a copy of the register inside index.html ...
%PY% update_register.py --register register.json embed index.html --out index.html
if errorlevel 1 goto :fail
echo Step 3 of 3: creating Dashboard_Register_Agent.txt for the chat agent ...
%PY% update_register.py --register register.json export-agent-txt Dashboard_Register_Agent.txt
if errorlevel 1 goto :fail
echo.
echo  DONE. Now upload register.json and index.html to your website.
echo  (Chat agent users: also replace Dashboard_Register_Agent.txt in the agent.)
echo.
pause
exit /b 0
:nopython
echo.
echo  Python was not found. Install it first (see Part 1 of the guide), then try again.
echo.
pause
exit /b 1
:fail
echo.
echo  SOMETHING IS WRONG. Read the message above the line. Nothing was published.
echo  Fix the row it names in Dashboard_Register.xlsx and double-click this file again.
echo.
pause
exit /b 1
