PERFBOARD WORKING FOLDER

What this folder is
  Your everyday workspace for the dashboard register. Keep all of these files together in one folder,
  for example C:\PerfBoard\Register

Every day (5 minutes)
  1. Open Dashboard_Register.xlsx and add ONE row for today's dashboard (date, link, status Published, ...).
  2. Make sure the Check column says OK on every row. Save and close the file.
  3. Double-click Update_Register.bat.
  4. Upload register.json (and index.html) to your website.
  5. Chat agent only: replace Dashboard_Register_Agent.txt in the agent.

Files
  Dashboard_Register.xlsx        The master list. Only edit this file.
  Update_Register.bat            Double-click to refresh everything else.
  update_register.py             The engine used by the .bat file. Do not edit.
  register.json                  Created for you. The landing page reads this. (Starts as a demo.)
  index.html                     The landing page (Option D).
  Dashboard_Register_Agent.txt   Created for you. The chat agent (Option C2) reads this. (Starts as a demo.)

Important
  - Paste links; never retype them.
  - Only one Published row per date. If you rebuild a date, change the old row to Superseded first.
  - Withdrawn = never shown to anyone.
