"""
Convert every Markdown (.md) file in ./input into an editable Word (.docx)
file in ./output.

Usage:
    pip install -r requirements.txt
    python main.py
"""
from pathlib import Path

import markdown
import pypandoc
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / "input"
OUTPUT_DIR = BASE_DIR / "output"


def add_table_borders(docx_path: Path) -> None:
    """Pandoc tables have no borders by default; add simple grid borders."""
    doc = Document(str(docx_path))
    for table in doc.tables:
        tbl_pr = table._tbl.tblPr
        old = tbl_pr.find(qn("w:tblBorders"))
        if old is not None:
            tbl_pr.remove(old)
        borders = OxmlElement("w:tblBorders")
        for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
            el = OxmlElement(f"w:{edge}")
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), "4")
            el.set(qn("w:space"), "0")
            el.set(qn("w:color"), "808080")
            borders.append(el)
        tbl_pr.append(borders)
    doc.save(str(docx_path))


def convert_file(md_path: Path, docx_path: Path) -> None:
    text = md_path.read_text(encoding="utf-8")

    # Markdown -> HTML first. This handles both pipe tables and the raw
    # <table> HTML that Azure Content Understanding often emits, and Pandoc
    # then turns the HTML into real, editable Word tables.
    html = markdown.markdown(text, extensions=["tables", "fenced_code", "sane_lists"])

    pypandoc.convert_text(
        html,
        to="docx",
        format="html",
        outputfile=str(docx_path),
        extra_args=["--standalone"],
    )
    add_table_borders(docx_path)


def main() -> None:
    INPUT_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

    md_files = sorted(INPUT_DIR.glob("*.md")) + sorted(INPUT_DIR.glob("*.markdown"))
    if not md_files:
        print(f"No .md files found in: {INPUT_DIR}\nPut your Markdown file there and run again.")
        return

    for md_path in md_files:
        docx_path = OUTPUT_DIR / f"{md_path.stem}.docx"
        try:
            convert_file(md_path, docx_path)
            print(f"OK   {md_path.name}  ->  output/{docx_path.name}")
        except Exception as exc:
            print(f"FAIL {md_path.name}: {exc}")


if __name__ == "__main__":
    main()
