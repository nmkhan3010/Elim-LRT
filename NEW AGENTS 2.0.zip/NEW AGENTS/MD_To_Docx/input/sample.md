# Financial Report

Some paragraph text with **bold** and *italic*.

## Table (HTML style, like Content Understanding)

<table>
<tr><th></th><th>September 30, 2010</th><th>September 30, 2009</th></tr>
<tr><td>Vendor rebates</td><td>$34,538</td><td>$38,857</td></tr>
<tr><td>Refundable income taxes</td><td>3,846</td><td>3,545</td></tr>
<tr><td>Other.</td><td>4,731</td><td>10,312</td></tr>
<tr><td></td><td>$43,115</td><td>$52,714</td></tr>
</table>

## Table (pipe style)

| Item | 2010 | 2009 |
|------|------|------|
| A | 1 | 2 |
| B | 3 | 4 |

- bullet one
- bullet two
