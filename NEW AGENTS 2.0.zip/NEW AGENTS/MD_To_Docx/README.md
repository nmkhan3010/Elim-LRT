# Markdown to DOCX

1. Put your `.md` file (or Content Understanding `.json` result) in the `input` folder.
2. Install requirements (once):  `pip install -r requirements.txt`
3. Run:  `python main.py`
4. Find the editable Word file in the `output` folder (same name, `.docx`).
